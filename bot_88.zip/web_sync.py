"""
web_sync.py  -  bridge between bot.py and the Web Admin Panel (Netlify + Firestore)

bot.py calls:  web_sync.init(globals())  and  web_sync.start()  once (see main()).
Everything the web panel edits lives in Firestore:
  web_texts/{id}          message + button text overrides (kind msg / btn)
  web_config/main         premium emoji, emoji swaps, DXA settings, welcome msgs, broadcast template
  web_commands/{id}       jobs from the panel (add_numbers, clear_country, delete_country, broadcast)
  web_stats/main          numbers the bot publishes (users, today, stock ...)
  otp_log / otp_counts    OTP history + leaderboard data written by the bot
"""
import re, time, threading, html

HIDE_BOT_EMOJI_EDITOR = True   # emoji editing lives in the web panel only

_ns = None
_db = None
_keep = []                     # keeps Firestore watchers alive
_texts = {}                    # id -> doc
_rules = []                    # [(compiled regex, new template)]
_btn = {}                      # original button text -> {"text":..., "icon":...}
_cfg = {}
_PH = re.compile(r"\{(\w+)\}")

DEFAULT_BC_TEMPLATE = (
    "➖➖➖➖➖➖➖➖\n《 <b>NEW NUMBERS</b> 》\n➖➖➖➖➖➖➖➖\n"
    "{flag} <b>{country}</b> {svc_emoji} <b>{service}</b>\n➖➖➖➖➖➖➖➖\n"
    "📤 Total Added: <b>{added}</b>\n💰 Per OTP: <b>{rate} ৳</b> (~${usd})\n➖➖➖➖➖➖➖➖\n"
    "Use /start to get your numbers!"
)

# settings the panel may change (key -> bot_settings key); anything else is ignored
ALLOWED_SETTINGS = {
    "withdraw_on", "min_withdraw", "cooldown", "num_req", "otp_default_rate", "otp_format",
    "tm_enabled", "usdt_rate", "refer_reward", "broadcast_pin", "auto_br_on", "auto_br_interval",
    "support_link", "main_channel_link", "proof_group", "w_group",
    "tm_batch", "tm_cooldown_min",      # Temp Mail limit (e.g. 3 mails per round, wait 8 min) - editable from web + support bot
}
GLOBAL_SWITCHES = {"voltx_enabled", "zenex_enabled", "force_join_status"}


def init(ns):
    global _ns
    _ns = ns


# ---------------------------------------------------------------- text / button overrides
def _compile(orig):
    parts, seen, rx = _PH.split(orig), set(), "^"
    for i, p in enumerate(parts):
        if i % 2 == 0:
            rx += re.escape(p)
        else:
            g = "g_" + p
            if g in seen: rx += f"(?P={g})"
            else: seen.add(g); rx += f"(?P<{g}>.*?)"
    return re.compile(rx + "$", re.S)


def _rebuild():
    global _rules, _btn
    rules, btn = [], {}
    for d in _texts.values():
        try:
            orig, new = str(d.get("orig", "")), str(d.get("text", ""))
            if d.get("enabled", True) is False: continue
            if d.get("kind") == "btn":
                if (new and new != orig) or d.get("icon"):
                    btn[orig] = {"text": new if new != orig else "", "icon": str(d.get("icon") or "")}
            elif new.strip() and new != orig:
                rules.append((len(orig), _compile(orig), new))
        except Exception as e:
            print("[WebSync] bad override skipped:", e)
    rules.sort(key=lambda r: -r[0])
    _rules = [(r[1], r[2]) for r in rules]
    _btn = btn
    try: _ns["emoji_changed"]()
    except Exception: pass


def apply_overrides(text):
    t = str(text)
    if not _rules: return t
    for rx, new in _rules:
        m = rx.match(t)
        if m:
            d = m.groupdict()
            return _PH.sub(lambda x: d.get("g_" + x.group(1), x.group(0)), new)
    return t


def button_override(orig):
    return _btn.get(orig) or {}


def _on_texts(col_snapshot, changes, read_time):
    for ch in changes:
        if ch.type.name == "REMOVED": _texts.pop(ch.document.id, None)
        else: _texts[ch.document.id] = ch.document.to_dict() or {}
    _rebuild()


# ---------------------------------------------------------------- config (emoji, settings, welcome ...)
def _on_cfg(doc_snapshot, changes, read_time):
    global _cfg
    try:
        for d in doc_snapshot:
            _cfg = d.to_dict() or {}
        _apply_cfg(_cfg)
    except Exception as e:
        print("[WebSync] config error:", e)


def _apply_cfg(c):
    bs = _ns["bot_settings"]
    if "premium_emoji" in c: bs["premium_emoji"] = bool(c["premium_emoji"])
    if "emoji_premium" in c:
        bs["emoji_premium"] = {x["ch"]: str(x["id"]) for x in c["emoji_premium"] if x.get("ch") and x.get("id")}
    if "emoji_swap" in c:
        bs["emoji_swap"] = {x["from"]: x["to"] for x in c["emoji_swap"] if x.get("from") and x.get("to")}
    for k, v in (c.get("settings") or {}).items():
        if k in GLOBAL_SWITCHES:
            _ns[k] = bool(v); continue
        if k not in ALLOWED_SETTINGS: continue
        old = bs.get(k)
        try:
            if isinstance(old, bool): v = bool(v)
            elif isinstance(old, int): v = int(float(v))
            elif isinstance(old, float): v = float(v)
            else: v = v if isinstance(v, (bool, int, float)) else str(v)
        except Exception: continue
        bs[k] = v
    if isinstance(c.get("method_videos"), list):      # METHOD VIDEO list (title / link / description) edited from the web panel
        bs["method_videos"] = [{"id": str(m.get("id") or ""), "title": str(m.get("title", ""))[:60], "link": str(m.get("link", "")),
                                "desc": str(m.get("desc", ""))[:600]} for m in c["method_videos"][:20] if isinstance(m, dict) and str(m.get("title", "")).strip()]
    if c.get("welcome"):
        slots = []
        for w in list(c["welcome"])[:3]:
            slots.append({"text": str(w.get("text", "")),
                          "buttons": [{"text": b["text"], "url": b["url"]} for b in (w.get("buttons") or []) if b.get("text") and b.get("url")]})
        while len(slots) < 3: slots.append({"text": "", "buttons": []})
        bs["welcome_msgs"] = slots
    _ns["emoji_changed"]()
    try: _ns["save_local_data"]()
    except Exception: pass


# ---------------------------------------------------------------- numbers: add + auto broadcast + /prf
def _svc_slug(name):
    first = (str(name).split() or ["x"])[0]
    return re.sub(r"[^a-z0-9]", "", first.lower()) or "x"


def on_numbers_added(service, c_code, cname, added):
    if added <= 0: return
    try:
        from firebase_admin import firestore
        _db.collection("web_stats").document("main").set({"added_total": firestore.Increment(added)}, merge=True)
    except Exception: pass
    if _cfg.get("auto_broadcast", True) is False: return
    threading.Thread(target=_broadcast_new, args=(service, c_code, cname, added), daemon=True).start()


def _broadcast_new(service, c_code, cname, added):
    ns = _ns
    try:
        flag, _, country = str(cname).partition(" ")
        if not country: flag, country = "🏳️", str(cname)
        sname = ns["detect_service"]("", service)
        rate = float(ns["get_otp_reward"](sname))
        usd = rate / max(float(ns["bot_settings"].get("usdt_rate", 120.0) or 120.0), 0.0001)
        emo = (ns["PREMIUM_APPS"].get(sname) or ns["PREMIUM_APPS"]["Other"])["emoji"]
        vals = {"flag": flag, "country": html.escape(country.upper()), "service": html.escape(str(service).upper()),
                "svc_emoji": emo, "added": added, "rate": f"{rate:.2f}", "usd": f"{usd:.4f}", "bot": ns.get("BOT_USERNAME", "")}
        tpl = _cfg.get("bc_template") or DEFAULT_BC_TEMPLATE
        text = _PH.sub(lambda m: str(vals.get(m.group(1), m.group(0))), tpl)
        link = f"https://t.me/{ns['BOT_USERNAME']}?start=alloc_{c_code}_{_svc_slug(service)}"
        markup = {"inline_keyboard": [[{"text": _cfg.get("bc_button") or "Get Number", "url": link, "style": "success"}]]}
        target = _cfg.get("bc_target", "both")
        if target in ("both", "groups"):
            for gid in list(ns.get("otp_forward_groups") or []):
                res = ns["send_message"](gid, text, reply_markup=markup)
                try:
                    if ns["bot_settings"].get("broadcast_pin") and res and res.get("ok"): ns["pin_message"](gid, res["result"]["message_id"])
                except Exception: pass
        if target in ("both", "users"):
            for uid in ns["get_all_user_ids"]():
                ns["send_message"](uid, text, reply_markup=markup); time.sleep(0.05)
    except Exception as e:
        print("[WebSync] broadcast error:", e)


def handle_prf(chat_id, user_id, text):
    ns = _ns
    send, edit = ns["send_message"], ns["edit_message"]
    parts = text.split(maxsplit=1)
    digits = re.sub(r"\D", "", parts[1].upper().replace("X", "")) if len(parts) > 1 else ""
    if len(digits) < 3:
        send(chat_id, "ℹ️ <b>Usage:</b> <code>/prf 23234XXX</code>"); return
    last = ns["user_cooldowns"].get(user_id, 0); now = time.time(); cd = ns["bot_settings"].get("cooldown", 0)
    if now - last < cd:
        send(chat_id, f"⌛ <b>Please wait {int(cd - (now - last))} seconds before requesting again.</b>"); return
    hits = []
    for sid, data in ns["get_merged_dynamic_data"]().items():
        for r in data["ranges"]:
            rc = str(r).replace("X", "")
            if rc and (rc.startswith(digits) or digits.startswith(rc)): hits.append(sid); break
    if not hits:
        send(chat_id, f"❌ <b>No range found for</b> <code>{digits}</code>"); return
    if len(hits) > 1:
        rows, row = [], []
        for sid in hits:
            row.append({"text": str(sid), "url": f"https://t.me/{ns['BOT_USERNAME']}?start=alloc_{digits}_{_svc_slug(sid)}", "style": "primary"})
            if len(row) == 2: rows.append(row); row = []
        if row: rows.append(row)
        send(chat_id, f"✅ <b>Select Service for</b> <code>{digits}</code>", reply_markup={"inline_keyboard": rows}); return
    ns["user_cooldowns"][user_id] = now
    wait = send(chat_id, f"⏳ <b>Fetching number for {html.escape(str(hits[0]))}...</b>")
    msg, markup = ns["get_number_allocation_content"](str(hits[0])[:15], digits, user_id=user_id)
    if wait and "result" in wait: edit(chat_id, wait["result"]["message_id"], msg, reply_markup=markup)
    else: send(chat_id, msg, reply_markup=markup)


# ---------------------------------------------------------------- commands queue from the panel
def _on_cmds(col_snapshot, changes, read_time):
    for ch in changes:
        if ch.type.name == "ADDED":
            threading.Thread(target=_run_cmd, args=(ch.document.reference, ch.document.to_dict() or {}), daemon=True).start()


def _run_cmd(ref, c):
    ns = _ns
    try:
        t = c.get("type"); res = {}
        if t == "add_numbers":
            digits = re.sub(r"\D", "", str(c.get("code", "")))
            svc_in = str(c.get("service", "")).strip()
            if not digits or not svc_in: raise ValueError("service and country code required")
            with ns["manual_lock"]:
                svc = next((k for k in ns["manual_stock"] if k.lower() == svc_in.lower()), None)
                if not svc:
                    svc = ns["manual_service_key"](svc_in)
                    if not svc: raise ValueError("bad service name")
                    ns["manual_stock"][svc] = {}
                code, cname = ns["get_country_info"](digits)
                slot = ns["manual_stock"][svc].setdefault(code, {"name": cname, "numbers": []})
                pool = slot["numbers"]; existing = set(pool); added = dup = bad = 0
                for tok in re.split(r"[\s,;]+", str(c.get("numbers", ""))):
                    if not tok: continue
                    n = ns["normalize_number"](tok)
                    if not n: bad += 1
                    elif n in existing or n in ns["manual_used"]: dup += 1
                    else: pool.append(n); existing.add(n); added += 1
            ns["save_manual_data"]()
            res = {"added": added, "duplicate": dup, "invalid": bad}
            if added and c.get("broadcast", True): on_numbers_added(svc, code, slot.get("name", cname), added)
            elif added: on_numbers_added_silent(added)
        elif t in ("clear_country", "delete_country"):
            with ns["manual_lock"]:
                cs = ns["manual_stock"].get(c.get("service"), {})
                if str(c.get("code")) in cs:
                    if t == "clear_country": cs[str(c["code"])]["numbers"] = []
                    else: cs.pop(str(c["code"]))
            ns["save_manual_data"](); res = {"ok": True}
        elif t == "broadcast":
            txt = str(c.get("text", "")).strip()
            if not txt: raise ValueError("empty text")
            n = 0
            for uid in ns["get_all_user_ids"]():
                r = ns["send_message"](uid, txt)
                if r and r.get("ok"): n += 1
                time.sleep(0.05)
            res = {"sent": n}
        else:
            raise ValueError("unknown command")
        ref.update({"status": "done", "result": res})
    except Exception as e:
        try: ref.update({"status": "error", "error": str(e)[:200]})
        except Exception: pass


def on_numbers_added_silent(added):
    try:
        from firebase_admin import firestore
        _db.collection("web_stats").document("main").set({"added_total": firestore.Increment(added)}, merge=True)
    except Exception: pass


# ---------------------------------------------------------------- OTP log + stats
def log_otp(uid, service, number, otp, reward):
    if not _db: return
    def w():
        try:
            from firebase_admin import firestore
            n = str(number).lstrip("+"); masked = n[:4] + "•" * max(len(n) - 7, 2) + n[-3:]
            u = {}
            try: u = _ns["get_user"](uid) or {}
            except Exception: pass
            name = str(u.get("first_name") or u.get("name") or "")
            _db.collection("otp_log").add({"ts": firestore.SERVER_TIMESTAMP, "uid": str(uid), "name": name, "service": str(service),
                                           "number": masked, "otp": str(otp), "reward": float(reward)})
            _db.collection("otp_counts").document(str(uid)).set({"uid": str(uid), "name": name, "total": firestore.Increment(1),
                                                                 "earned": firestore.Increment(float(reward)), "last": firestore.SERVER_TIMESTAMP}, merge=True)
        except Exception as e:
            print("[WebSync] log_otp:", e)
    threading.Thread(target=w, daemon=True).start()


def _stats_loop():
    from firebase_admin import firestore
    while True:
        try:
            ns = _ns; stock = []; total = 0
            with ns["manual_lock"]:
                for s, cs in ns["manual_stock"].items():
                    for code, c in cs.items():
                        n = len(c.get("numbers", [])); total += n
                        stock.append({"service": s, "code": str(code), "country": c.get("name", ""), "count": n})
            ds = ns["daily_stats"]; today = time.strftime("%Y-%m-%d"); same = ds.get("date") == today
            _db.collection("web_stats").document("main").set({
                "users": len(ns["get_all_user_ids"]()), "numbers_today": ds.get("numbers", 0) if same else 0,
                "otps_today": ds.get("otps", 0) if same else 0, "stock_total": total, "stock": stock,
                "settings": {**{k: ns["bot_settings"].get(k) for k in ALLOWED_SETTINGS}, **{k: bool(ns.get(k)) for k in GLOBAL_SWITCHES}},
                "welcome": ns["bot_settings"].get("welcome_msgs", []),
                "method_videos": ns["bot_settings"].get("method_videos", []),
                "updated": firestore.SERVER_TIMESTAMP}, merge=True)
        except Exception as e:
            print("[WebSync] stats:", e)
        time.sleep(30)


def start():
    global _db
    _db = _ns.get("db_firebase")
    if not _db:
        print("[WebSync] Firebase not connected (temp_firebase.json missing?) - web panel sync is OFF"); return
    _keep.append(_db.collection("web_texts").on_snapshot(_on_texts))
    _keep.append(_db.collection("web_config").document("main").on_snapshot(_on_cfg))
    _keep.append(_db.collection("web_commands").where("status", "==", "pending").on_snapshot(_on_cmds))
    threading.Thread(target=_stats_loop, daemon=True).start()
    print("[WebSync] connected to web admin panel data")

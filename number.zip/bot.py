import requests
import time
import json
import random
import string
import sqlite3
import os
import re
import html
import base64
import hmac
import hashlib
import struct
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import firebase_admin
from firebase_admin import credentials, firestore
import web_sync  # Web Admin Panel bridge (Firestore)

# ==========================================
# Configuration
# ==========================================
BOT_TOKEN = "8748828601:AAGEafKICbdqwpd6vfiUVijXOxpw9uPOLmk"
ADMIN_ID = 8688468372
BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/"
BOT_USERNAME = ""

# 2oo9 API Configuration
API_2OO9_BASE = "https://api.2oo9.cloud/MXS47FLFX0U/tnevs/@public/api"
API_2OO9_KEY_DEFAULT = "MHF5UTYD3L7"

# Zenex Core API Configuration (new panel)
ZENEX_CORE_BASE = "https://api.zenexnetwork.com"
ZENEX_WEB_BASE = "https://www.zenexnetwork.com"

# Global states
current_db_mode = "sqlite"
db_firebase = None 
waiting_for_firebase = False
user_states = {}

# User & Cooldown States
user_cache = {} 
user_active_sessions = {} # format: {"number": user_id}
user_cooldowns = {} 

# Voltx Auto System States
voltx_auto_mode = True 
voltx_keys = [API_2OO9_KEY_DEFAULT]
force_join_status = False
force_join_channels = []

# OTP Forwarding States
otp_forward_groups = []
otp_button_link = "https://t.me/your_default_bot"
recent_success_otps = set()

voltx_dynamic_data = {} 
recent_traffic = []

# ---- Panel switches (Voltx + Zenex can run together) ----
voltx_enabled = True      # Voltx panel on/off
zenex_keys = []           # Zenex API keys (add from Owner Panel > ZENEX SETTINGS)
zenex_enabled = True      # Zenex panel on/off (only works when at least 1 key exists)
zenex_dynamic_data = {}   # Same structure as voltx_dynamic_data, filled from Zenex /v1/active-ranges
zenex_traffic = []        # Live traffic from Zenex global-broadcast feed
group_sent_otps = set()   # OTPs already forwarded to groups (shared by both panels)

# ---- Manual number pool (admin uploads .txt) + AugesTel API (OTP source) ----
AUGESTEL_BASE = "https://augestel.com/api/v1/iprn"
MANUAL_FILE = "manual_numbers.json"
manual_stock = {}          # {service: {country_code: {"name": "🇬🇧 United Kingdom", "numbers": [...]}}}
manual_used = set()        # numbers already given to a user (never given again)
manual_lock = threading.Lock()
augestel_key = ""
augestel_enabled = True
augestel_range_meta = {}   # {range_name: {"service": "Facebook", "enabled": True}}
augestel_cache = {"t": 0, "numbers": []}   # last /numbers fetch (cached to save the 5 req/min limit)
augestel_range_index = []  # range names in the order shown in the admin list (used by callbacks)

# ---- LAMIX SMS REST API (OTP source + number source for the manual panel) ----
LAMIX_BASE = "https://panel.lamix.org"      # <- change to your panel address if different
lamix_key = ""
lamix_enabled = True
lamix_range_meta = {}      # {range_name: {"service": "Facebook", "enabled": True}}
lamix_cache = {"t": 0, "numbers": []}       # last /numbers fetch (cached 2 min)
lamix_range_index = []     # range names in admin-list order (used by callbacks)
lamix_page_cursors = {0: None}              # {page_no: cursor} for the "My Numbers" pager
lamix_last_call = {}       # {endpoint: monotonic time} -> keeps 1 req/sec per endpoint
lamix_call_lock = threading.Lock()
otp_process_lock = threading.Lock()
daily_stats = {"date": "", "numbers": 0, "otps": 0} # 🌟 Daily Stats Tracker
daily_user_otps = {"date": "", "users": {}}

# 🌟 Caching Variables for Rocket Speed!
cached_services_kb = None
cached_countries_kb = {}
cached_leaderboard_text = ""
last_alloc = {}   # {user_id: last allocated numbers} (for Remove/Add Country Code toggle)

def build_country_keyboard(safe_sid_short, sid, top_countries):
    """2-column country buttons: flag + 2-letter code + price (reference style)."""
    cnt_kb = {"inline_keyboard": []}
    rate = get_otp_reward(detect_service("", sid))
    price_txt = PRICE_FMT.format(rate=float(rate))
    row = []
    for c_code, c_data in top_countries:
        flag = str(c_data["name"]).split(" ", 1)[0]
        iso = flag_to_iso(flag) or f"+{c_code}"
        row.append({"text": f"{flag} {iso} • {price_txt} ⚡", "callback_data": f"cc_{safe_sid_short}_{c_code}", "style": "success"})
        if len(row) == 2: cnt_kb["inline_keyboard"].append(row); row = []
    if row: cnt_kb["inline_keyboard"].append(row)
    cnt_kb["inline_keyboard"].append([
        {"text": "Refresh", "callback_data": f"srv_{safe_sid_short}", "icon_custom_emoji_id": "5229111790842952353", "style": "primary"},
        {"text": "❌ Back", "callback_data": "back_to_services", "style": "primary"}
    ])
    return cnt_kb

def auto_cache_menu_thread():
    global cached_services_kb, cached_countries_kb, voltx_auto_mode, voltx_dynamic_data
    while True:
        try:
            merged_dyn = get_merged_dynamic_data()
            if merged_dyn:
                service_hits = [(sid, s_data, sum(r["hits"] for r in s_data["ranges"].values())) for sid, s_data in merged_dyn.items()]
                top_services = sorted(service_hits, key=lambda x: x[2], reverse=True)[:15] # 🌟 Top 15 Services
                
                new_srv_kb = {"inline_keyboard": []}
                row = []; styles = ["primary", "success", "danger"]; style_idx = 0
                for sid, data, hits in top_services:
                    safe_sid = html.escape(str(sid))
                    row.append({"text": safe_sid, "callback_data": f"srv_{safe_sid[:15]}", "style": "primary", "icon_custom_emoji_id": data["emoji_id"]})
                    style_idx += 1
                    if len(row) == 2: new_srv_kb["inline_keyboard"].append(row); row = []
                if row: new_srv_kb["inline_keyboard"].append(row)
                
                cached_services_kb = new_srv_kb

                new_cnt_kb = {}
                for sid, data, hits in top_services:
                    safe_sid_short = html.escape(str(sid))[:15]
                    country_map = {}
                    for r, r_data in data["ranges"].items():
                        clean_r = str(r).replace("X", "")
                        if not re.match(r'^\d+$', clean_r): continue
                        c_code, c_name = get_country_info(clean_r)
                        if c_code not in country_map: country_map[c_code] = {"name": c_name, "hits": 0}
                        country_map[c_code]["hits"] += r_data["hits"]
                    
                    top_countries = sorted(country_map.items(), key=lambda x: x[1]["hits"], reverse=True)[:15] # 🌟 Top 15 Countries
                    
                    cnt_kb = build_country_keyboard(safe_sid_short, sid, top_countries)
                    new_cnt_kb[safe_sid_short] = cnt_kb
                    
                cached_countries_kb = new_cnt_kb
                
            # --- 🌟 Leaderboard Caching ---
            global cached_leaderboard_text, daily_user_otps
            today = time.strftime("%Y-%m-%d")
            if daily_user_otps.get("date") != today:
                daily_user_otps["date"] = today
                daily_user_otps["users"] = {}
                
            top_users = sorted(daily_user_otps["users"].items(), key=lambda x: x[1], reverse=True)[:5]
            lb_msg = "<blockquote><tg-emoji emoji-id=\"5240021484516185513\">🏆</tg-emoji> <b>𝗧𝗢𝗣 𝟱 𝗟𝗘𝗔𝗗𝗘𝗥𝗕𝗢𝗔𝗥𝗗 (TODAY)</b></blockquote>\n━━━━━━━━━━━━━━━━━\n"
            emoji_map = [("1️⃣", "5238176680098440792"), ("2️⃣", "5237806896299157399"), ("3️⃣", "5239965456667812809"), ("4️⃣", "5237911487342751418"), ("5️⃣", "5240278297790686165")]
            
            if not top_users: 
                lb_msg += "<i>No OTPs received today.</i>\n"
            else:
                for idx, (uid_str, otp_count) in enumerate(top_users):
                    u_data = get_user(int(uid_str))
                    fname = u_data["first_name"] if u_data else "User"
                    emoji_char, emoji_id = emoji_map[idx]
                    lb_msg += f"<blockquote><tg-emoji emoji-id=\"{emoji_id}\">{emoji_char}</tg-emoji> <a href='tg://user?id={uid_str}'>{html.escape(str(fname))}</a> - {otp_count} OTP</blockquote>\n"
            lb_msg += "━━━━━━━━━━━━━━━━━"
            cached_leaderboard_text = lb_msg
            
        except Exception as e:
            pass
        time.sleep(5) # 🌟 5 সেকেন্ড পরপর ব্যাকগ্রাউন্ডে ক্যাশ রেডি হবে

PRICE_FMT = "{rate:.2f} TK"   # country button / allocation price text (change to "${rate:.2f}" for dollar)

DEFAULT_WELCOME_TEXT = (
    "⚡  AR X Number\n"
    "┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n"
    "👋 Welcome, {name}!\n\n"
    "📱 Get instant virtual numbers\n"
    "✅ Free ᴏᴛᴘ ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ\n\n"
    "┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅\n"
    "⚡ Press Get Number to start!"
)

# Admin Settings (DXA Control)
bot_settings = {
    "withdraw_on": True,
    "min_withdraw": 10.0,
    "support_link": "",
    "w_group": "",
    "auto_br_on": False,
    "auto_br_interval": 60,
    "cooldown": 5, # Default 5 seconds
    "num_req": 1, # Default 1 number per request
    "w_methods": ["bKash", "Nagad", "USDT (BEP20)"],
    "tm_enabled": True,        # Temp Mail on/off
    "tm_batch": 4,             # mails a user can create in one round
    "tm_cooldown_min": 5,      # then wait this many minutes before the next round
    "usdt_added": False,       # one-time migration flag: adds "USDT (BEP20)" to old saved settings
    "proof_group": "",         # payment PROOF group/channel (public) - separate from w_group (admin payment group)
    "usdt_rate": 120.0,        # BDT per 1 USDT (balance is in BDT, USDT proof shows $)
    "wd_counter": 100000,      # proof number: #100001, #100002 ...
    "pending_withdrawals": {}, # {wid: {...}} waiting for admin approve/reject
    "otp_default_rate": 0.5,
    "otp_service_rates": {},
    "main_channel_link": "",
    "welcome_msgs": [{"text": DEFAULT_WELCOME_TEXT, "buttons": []}, {"text": "", "buttons": []}, {"text": "", "buttons": []}],
    "no_cc_users": [],
    "broadcast_pin": False,  # True = broadcast message is auto-pinned in the OTP group
    "otp_format": "mini",  # "mini" (old format) or "big" (new format) - switch from OTP GROUP MANAGEMENT
    "premium_emoji": False,  # False = normal emoji, True = Telegram premium (custom) emoji
    "emoji_premium": {},     # admin custom map: normal emoji -> premium emoji id
    "emoji_swap": {}         # admin swaps: normal emoji -> another normal emoji
}

PROOF_BRAND = "AR X Number"        # title in the proof post: "<brand> Pay Proof"
PROOF_SHOW_ACCOUNT = True          # True = proof shows the MASKED number/address, False = hide the line
PROOF_UTC_OFFSET = 6               # hours added to UTC for the proof date (6 = Bangladesh time)

BOT_DATA_FILE = "bot_data.json"
USERS_LIST_FILE = "users_list.json"

# ==========================================
# Helper: Get Active Voltx Key & Rates
# ==========================================
def get_api_key():
    return random.choice(voltx_keys) if voltx_keys else API_2OO9_KEY_DEFAULT

def get_zenex_key():
    return random.choice(zenex_keys) if zenex_keys else None

def voltx_active():
    return bool(voltx_enabled and voltx_keys)

def zenex_active():
    return bool(zenex_enabled and zenex_keys)

def manual_total_numbers():
    return sum(len(c["numbers"]) for s in manual_stock.values() for c in s.values())

def manual_active():
    return manual_total_numbers() > 0

def get_active_panels():
    panels = []
    if voltx_active(): panels.append("voltx")
    if zenex_active(): panels.append("zenex")
    if manual_active(): panels.append("manual")
    return panels

def save_manual_data():
    try:
        with open(MANUAL_FILE, "w", encoding="utf-8") as f:
            json.dump({"stock": manual_stock, "used": list(manual_used)[-200000:],
                       "augestel_key": augestel_key, "augestel_enabled": augestel_enabled,
                       "ranges": augestel_range_meta,
                       "lamix_key": lamix_key, "lamix_enabled": lamix_enabled,
                       "lamix_ranges": lamix_range_meta}, f, ensure_ascii=False)
    except Exception as e:
        print(f"[Manual] save error: {e}")

def load_manual_data():
    global manual_stock, manual_used, augestel_key, augestel_enabled, augestel_range_meta
    global lamix_key, lamix_enabled, lamix_range_meta
    if not os.path.exists(MANUAL_FILE): return
    try:
        with open(MANUAL_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        manual_stock = d.get("stock", {})
        manual_used = set(d.get("used", []))
        augestel_key = d.get("augestel_key", "")
        augestel_enabled = d.get("augestel_enabled", True)
        augestel_range_meta = d.get("ranges", {})
        lamix_key = d.get("lamix_key", "")
        lamix_enabled = d.get("lamix_enabled", True)
        lamix_range_meta = d.get("lamix_ranges", {})
    except Exception as e:
        print(f"[Manual] load error: {e}")

def manual_service_key(name):
    name = str(name or "").strip()
    std = detect_service("", name)
    return std if std != "Other" else name[:30]

def normalize_number(token):
    token = str(token or "").strip()
    if not re.fullmatch(r"\+?[\d\-()]+", token): return None
    digits = re.sub(r"\D", "", token)
    return digits if 7 <= len(digits) <= 15 else None

def build_manual_dynamic():
    """Manual stock in the same shape as panel range data (so menus work unchanged).
    +1,000,000 hits keeps admin-created services at the top of the menu."""
    now = int(time.time())
    out = {}
    for svc, countries in list(manual_stock.items()):
        app_info = PREMIUM_APPS.get(svc, PREMIUM_APPS["Other"])
        ranges = {}
        for code, c in list(countries.items()):
            if c["numbers"]:
                ranges[code] = {"last_seen": now, "hits": 1000000 + len(c["numbers"])}
        if ranges:
            out[svc] = {"emoji_id": app_info["id"], "normal_emoji": app_info["emoji"], "ranges": ranges}
    return out

def fetch_manual_number(service, rid):
    """Take ONE number out of the pool (it will never be given again)."""
    with manual_lock:
        for svc, countries in manual_stock.items():
            if svc.lower() != str(service).lower(): continue
            c = countries.get(rid)
            if c and c["numbers"]:
                num = c["numbers"].pop(0)
                manual_used.add(num)
                save_manual_data()
                return {"full_number": num, "country": c.get("name", "Unknown"), "operator": "Manual"}
    return None

def get_merged_dynamic_data():
    """Voltx (auto mode) + Zenex range data merged into one structure.
    Every range remembers which panel(s) it came from."""
    merged = {}
    sources = []
    if voltx_active() and voltx_auto_mode: sources.append(("voltx", voltx_dynamic_data))
    if zenex_active(): sources.append(("zenex", zenex_dynamic_data))
    if manual_active(): sources.append(("manual", build_manual_dynamic()))
    for panel, source in sources:
        for sid, s_data in list(source.items()):
            m = merged.setdefault(sid, {"emoji_id": s_data.get("emoji_id"), "normal_emoji": s_data.get("normal_emoji"), "ranges": {}})
            for r, r_data in list(s_data.get("ranges", {}).items()):
                if r not in m["ranges"]:
                    m["ranges"][r] = {"last_seen": r_data["last_seen"], "hits": r_data["hits"], "panels": [panel]}
                else:
                    m["ranges"][r]["hits"] += r_data["hits"]
                    m["ranges"][r]["last_seen"] = max(m["ranges"][r]["last_seen"], r_data["last_seen"])
                    if panel not in m["ranges"][r]["panels"]: m["ranges"][r]["panels"].append(panel)
    return merged

def get_otp_reward(service_name):
    rates = bot_settings.get("otp_service_rates", {})
    val = rates.get(service_name, bot_settings.get("otp_default_rate", 0.5))
    return float(val)

def update_daily_stat(key, amount=1):
    global daily_stats
    today = time.strftime("%Y-%m-%d")
    if daily_stats.get("date") != today:
        daily_stats = {"date": today, "numbers": 0, "otps": 0}
    daily_stats[key] = daily_stats.get(key, 0) + amount

# ==========================================
# Local Storage Managers
# ==========================================
def load_local_data():
    global voltx_enabled, zenex_keys, zenex_enabled
    global recent_traffic, voltx_dynamic_data, voltx_keys, force_join_status, force_join_channels, voltx_auto_mode, otp_forward_groups, otp_button_link, recent_success_otps, bot_settings, user_active_sessions, daily_stats, daily_user_otps
    if os.path.exists(BOT_DATA_FILE):
        try:
            with open(BOT_DATA_FILE, "r") as f:
                data = json.load(f)
                recent_traffic = data.get("recent_traffic", [])
                voltx_dynamic_data = data.get("voltx_dynamic_data", {})
                loaded_keys = data.get("voltx_keys", [])
                
                if not loaded_keys:
                    voltx_keys = [API_2OO9_KEY_DEFAULT]
                else:
                    voltx_keys = loaded_keys
                    
                force_join_status = data.get("force_join_status", False)
                force_join_channels = data.get("force_join_channels", [])
                voltx_auto_mode = data.get("voltx_auto_mode", True)
                voltx_enabled = data.get("voltx_enabled", True)
                zenex_keys = data.get("zenex_keys", [])
                zenex_enabled = data.get("zenex_enabled", True)
                otp_forward_groups = data.get("otp_forward_groups", [])
                otp_button_link = data.get("otp_button_link", "https://t.me/your_default_bot")
                recent_success_otps = set(data.get("recent_success_otps", []))
                
                loaded_settings = data.get("bot_settings", {})
                for k, v in loaded_settings.items(): bot_settings[k] = v
                
                daily_stats = data.get("daily_stats", {"date": "", "numbers": 0, "otps": 0})
                daily_user_otps = data.get("daily_user_otps", {"date": "", "users": {}})
                user_active_sessions = data.get("user_active_sessions", {})
        except Exception as e:
            print(f"Error loading local data: {e}")

def save_local_data():
    global voltx_enabled, zenex_keys, zenex_enabled
    global recent_traffic, voltx_dynamic_data, voltx_keys, force_join_status, force_join_channels, voltx_auto_mode, otp_forward_groups, otp_button_link, recent_success_otps, bot_settings, user_active_sessions, daily_stats
    try:
        with open(BOT_DATA_FILE, "w") as f:
            json.dump({
                "recent_traffic": recent_traffic, 
                "voltx_dynamic_data": voltx_dynamic_data,
                "voltx_keys": voltx_keys,
                "force_join_status": force_join_status,
                "force_join_channels": force_join_channels,
                "voltx_auto_mode": voltx_auto_mode,
                "voltx_enabled": voltx_enabled,
                "zenex_keys": zenex_keys,
                "zenex_enabled": zenex_enabled,
                "otp_forward_groups": otp_forward_groups,
                "otp_button_link": otp_button_link,
                "recent_success_otps": list(recent_success_otps),
                "bot_settings": bot_settings,
                "user_active_sessions": user_active_sessions,
                "daily_stats": daily_stats,
                "daily_user_otps": daily_user_otps
            }, f)
    except Exception as e:
        print(f"Error saving local data: {e}")
        
    # 🌟 Firebase এ লাইভ আপডেট পাঠানো
    if current_db_mode == "firebase" and db_firebase:
        try:
            db_firebase.collection('settings').document('bot_config').set({
                "bot_settings": bot_settings,
                "force_join_status": force_join_status,
                "force_join_channels": force_join_channels,
                "otp_forward_groups": otp_forward_groups,
                "otp_button_link": otp_button_link,
                "voltx_keys": voltx_keys,
                "voltx_auto_mode": voltx_auto_mode,
                "voltx_enabled": voltx_enabled,
                "zenex_keys": zenex_keys,
                "zenex_enabled": zenex_enabled
            }, merge=True)
        except: pass

# গ্লোবাল ভেরিয়েবলে ইউজার লিস্ট ক্যাশ করে রাখা হলো
cached_user_list = set()

def add_to_broadcast_list(user_id):
    global cached_user_list
    if not cached_user_list and os.path.exists(USERS_LIST_FILE):
        try:
            with open(USERS_LIST_FILE, "r") as f:
                cached_user_list = set(json.load(f))
        except: pass
        
    if user_id not in cached_user_list:
        cached_user_list.add(user_id)
        try:
            with open(USERS_LIST_FILE, "w") as f:
                json.dump(list(cached_user_list), f)
        except: pass

def get_all_user_ids():
    global user_cache
    users = set()
    
    # 🌟 ১. প্রথমে RAM Cache থেকে দ্রুত ইউজার নিবে
    for uid in user_cache.keys():
        users.add(int(uid))
        
    # 🌟 ২. এরপর লোকাল JSON ফাইল থেকে নিবে
    if os.path.exists(USERS_LIST_FILE):
        try:
            with open(USERS_LIST_FILE, "r") as f:
                for u in json.load(f): users.add(int(u))
        except: pass
        
    #RAM সবসময় আপডেটেড থাকে!
    return list(users)

# ==========================================
# Telegram APIs & Force Join Helpers
# ==========================================
def get_bot_info():
    try:
        res = requests.get(BASE_URL + "getMe").json()
        if res.get("ok"): return res["result"]["username"]
    except Exception: pass
    return ""

def set_bot_commands():
    commands = [{"command": "start", "description": "Start the bot or refresh menu"}]
    try: requests.post(BASE_URL + "setMyCommands", json={"commands": commands})
    except Exception: pass

# ---------- Premium emoji switch (Owner Panel > PREMIUM EMOJI) ----------
BUTTON_ICON_EMOJI = {
    "5240122519326860770": "🔑", "5296633779157243809": "📢", "5429353834881261942": "📣",
    "5429208347159077664": "💬", "5429274992166609833": "👤", "5240451569656308978": "⚙️",
    "5429362935916962442": "☁️", "5429591316507963112": "🗄", "5438541186539232243": "⬅️",
    "5267490665117275176": "⬅️", "5352694861990501856": "✅", "5420130255174145507": "❌",
    "5429501315468270290": "➕", "5438178416421544431": "🗑", "5422557736330106570": "🗑",
    "5420517437885943844": "🔗", "5429167978761461870": "📲", "5190576863226933563": "🎛",
    "5190899075968441286": "💳", "5226929552319594190": "📱", "5229111790842952353": "🔄",
    "5240021484516185513": "🏆", "5314366268898300483": "💬", "5337132498965010628": "🔢",
    "5337172996211648018": "⏳", "5352861489541714456": "👤", "5352877703043258544": "💰",
    "5379889727325350343": "📋", "5384394344859974865": "👥", "5395444784611480792": "💲",
    "5420396762189831222": "🎁", "5429105001655999635": "💰", "5429386648431405093": "🔄",
    "5429427051188756948": "👑", "5429571662737611814": "📈", "5429612421977253466": "💵",
    "5431783519355444455": "🏦", "5456259593082522998": "📱"
}
_icon_reverse = {}

def premium_emoji_on():
    return bool(bot_settings.get("premium_emoji", False))

def icon_to_emoji(eid):
    if not _icon_reverse:
        for char, i in GLOBAL_BODY_EMOJIS.items(): _icon_reverse[str(i)] = char
        for a in PREMIUM_APPS.values(): _icon_reverse[str(a["id"])] = a["emoji"]
        _icon_reverse.update(BUTTON_ICON_EMOJI)
    em = _icon_reverse.get(str(eid), "")
    if em: return em
    for ch, i in (bot_settings.get("emoji_premium") or {}).items():
        if str(i) == str(eid): return ch
    return ""

_TGE_RE = re.compile(r'(<tg-emoji[^>]*>.*?</tg-emoji>)', re.S)
_KB_UNMAP = {}   # text shown on a reply-keyboard button -> original text the handlers compare with

def _outside_tg_emoji(text, fn):
    parts = _TGE_RE.split(str(text))
    for i in range(0, len(parts), 2): parts[i] = fn(parts[i])
    return "".join(parts)

def _strip_tg_emoji(t):
    return re.sub(r'<tg-emoji[^>]*>(.*?)</tg-emoji>', r'\1', str(t), flags=re.S)

def prepare_text(text):
    text = web_sync.apply_overrides(str(text))   # texts edited from the Web Admin Panel
    if premium_emoji_on(): return apply_emojis(apply_swaps(text))
    return apply_swaps(_strip_tg_emoji(text))

def prepare_markup(markup, force_off=False):
    """Admin emoji swaps always apply to button labels.
    Premium ON : a leading mapped emoji in the label becomes the button's premium icon.
    Premium OFF: premium icons are turned back into normal emoji."""
    if not isinstance(markup, dict): return markup
    markup = json.loads(json.dumps(markup))
    on = premium_emoji_on() and not force_off
    c = _emj_build()
    for kind in ("inline_keyboard", "keyboard"):
        for row in markup.get(kind, []) or []:
            for btn in row:
                if not isinstance(btn, dict) or "text" not in btn: continue
                orig = str(btn.get("text", ""))
                _wb = web_sync.button_override(orig)          # button text/icon edited from the Web Admin Panel
                txt = apply_swaps(_wb.get("text") or orig)
                eid = btn.get("icon_custom_emoji_id")
                if _wb.get("icon") and on: btn["icon_custom_emoji_id"] = eid = str(_wb["icon"])
                if on:
                    if not eid and c.get("prem_re"):
                        lead = txt.lstrip()
                        m = c["prem_re"].match(lead)
                        if m and lead[m.end():].strip():
                            btn["icon_custom_emoji_id"] = c["prem"][m.group(0)]
                            txt = lead[m.end():].strip()
                elif eid:
                    btn.pop("icon_custom_emoji_id", None)
                    em = "✖️" if txt.strip().upper() == "CLOSE" else icon_to_emoji(eid)
                    if em and em not in txt: txt = f"{em} {txt}".strip()
                btn["text"] = txt
                if kind == "keyboard" and txt != orig: _KB_UNMAP[txt] = orig
    return markup

MAIN_BUTTON_LABELS = ["Get Number", "LIVE TRAFFIC", "INVITE FRIEND", "WALLET", "LEADERBOARD", "2FA Online", "Get Temp Mail", "OWNER PANEL"]

def normalize_button_text(text):
    """Reply-keyboard taps arrive as '📱 LIVE NUMBER' when premium is OFF; turn them back into 'LIVE NUMBER'."""
    t = str(text or "").strip()
    for label in MAIN_BUTTON_LABELS:
        if t != label and t.endswith(label) and len(t) - len(label) <= 6: return label
    return t

def _tg_text_call(method, payload):
    """Send/edit a text message. If Telegram rejects a premium emoji / button icon, retry once with normal emoji."""
    res = requests.post(BASE_URL + method, json=payload).json()
    if isinstance(res, dict) and not res.get("ok"):
        d = str(res.get("description", "")).lower()
        retry = False
        if "<tg-emoji" in str(payload.get("text", "")) and ("entit" in d or "emoji" in d):
            payload["text"] = _strip_tg_emoji(payload["text"]); retry = True
        if "icon_custom_emoji_id" in json.dumps(payload.get("reply_markup", {})) and ("button" in d or "emoji" in d or "icon" in d):
            payload["reply_markup"] = prepare_markup(payload["reply_markup"], force_off=True); retry = True
        if retry: res = requests.post(BASE_URL + method, json=payload).json()
    return res

def send_message(chat_id, text, reply_markup=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "text": prepare_text(text), "parse_mode": parse_mode}
    if reply_markup: payload["reply_markup"] = prepare_markup(reply_markup)
    try: return _tg_text_call("sendMessage", payload)
    except Exception: return None

def edit_message(chat_id, message_id, text, reply_markup=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "message_id": message_id, "text": prepare_text(text), "parse_mode": parse_mode}
    if reply_markup: payload["reply_markup"] = prepare_markup(reply_markup)
    try: _tg_text_call("editMessageText", payload)
    except Exception: pass

def answer_callback_query(callback_query_id, text="", show_alert=False):
    payload = {"callback_query_id": callback_query_id, "text": text, "show_alert": show_alert}
    requests.post(BASE_URL + "answerCallbackQuery", json=payload)

def delete_message(chat_id, message_id):
    payload = {"chat_id": chat_id, "message_id": message_id}
    requests.post(BASE_URL + "deleteMessage", json=payload)

def send_document(chat_id, filename, content, caption=""):
    try:
        return requests.post(BASE_URL + "sendDocument", data={"chat_id": chat_id, "caption": caption},
                             files={"document": (filename, content.encode("utf-8"), "text/plain")}, timeout=60).json()
    except Exception:
        return None

def copy_message(chat_id, from_chat_id, message_id, reply_markup=None):
    payload = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
    if reply_markup: payload["reply_markup"] = prepare_markup(reply_markup)
    try: return requests.post(BASE_URL + "copyMessage", json=payload).json()
    except Exception: return None

def get_chat_details(chat_identifier):
    chat_identifier = str(chat_identifier).strip()
    if chat_identifier.startswith("https://t.me/"):
        chat_identifier = "@" + chat_identifier.split("/")[-1]
    elif not chat_identifier.startswith("@") and not chat_identifier.startswith("-100"):
        chat_identifier = "@" + chat_identifier
        
    url = BASE_URL + "getChat"
    res = requests.get(url, params={"chat_id": chat_identifier}).json()
    if res.get("ok"):
        chat = res["result"]
        chat_data = {
            "id": chat["id"],
            "username": "@" + chat["username"] if "username" in chat else "",
            "title": chat.get("title", "Private Channel"),
            "invite_link": chat.get("invite_link", "")
        }
        if not chat_data["invite_link"]:
            inv_res = requests.post(BASE_URL + "exportChatInviteLink", json={"chat_id": chat["id"]}).json()
            if inv_res.get("ok"):
                chat_data["invite_link"] = inv_res["result"]
        return chat_data
    return None

def is_user_joined(user_id):
    if not force_join_status or not force_join_channels: return True
    if user_id == ADMIN_ID: return True
    
    for ch in force_join_channels:
        try:
            res = requests.get(BASE_URL + "getChatMember", params={"chat_id": ch["id"], "user_id": user_id}).json()
            if res.get("ok"):
                status = res["result"]["status"]
                if status in ["left", "kicked"]: return False
            else:
                return False
        except: return False
    return True

# ==========================================
# Global Emojis Map
# ==========================================
GLOBAL_BODY_EMOJIS = {
    "➖": "5870818207383686839", "🚫": "5334807341109908955", "😒": "5334763399299506604",
    "🖥": "5334880948259427772", "🌐": "5334590977837403844", "🌟": "5337102391244263212",
    "🕓": "5336983442125001376", "⌛": "5337172996211648018", "💬": "5337302974806922068",
    "🔐": "5337255927735163754", "🍏": "5337132498965010628", "❔": "5336850036145823599",
    "⚠️": "5336944168944047463", "🔥": "5337267511261960341", "💸": "5429612421977253466",
    "🥚": "5348390922507817684", "👨‍⚖": "5334763399299506604", "🐁": "5348494358205207761",
    "🧻": "5348486915026884464", "⚗": "5346311574221000149", "🛴": "5348075478634766440",
    "📊": "5353032893096567467", "🔢": "5226929552319594190", "👤": "5352861489541714456",
    "📁": "5352721946054268944", "🚀": "5352597830089347330", "💎": "5352838545826420397",
    "📍": "5352922460897452503", "👋": "5353027129250453493", "✅": "5352694861990501856",
    "1️⃣": "5352651766288652742", "2️⃣": "5355186458418257716", "3️⃣": "5352867219028091093",
    "4️⃣": "5352566657216714037", "5️⃣": "5353086880835474989", "6️⃣": "5354859211975071385",
    "7️⃣": "5352859127309707652", "8️⃣": "5352957533600389988", "9️⃣": "5353060913463204207",
    "🔤": "5352727417842606016", "📣": "5352980533150259581", "📤": "5353001161878182134",
    "✨": "5352552689983067014", "🔹": "5352638632278660622", "🎙": "5355102594886833928",
    "💴": "5352985330628730418", "📅": "5352585194295564660", "📴": "5352974971167611327",
    "✏️": "5395444784611480792", "📱": "5337132498965010628", "🔗": "5420517437885943844",
    "❌": "5420130255174145507", "⚙️": "5420155432272438703", "🫂": "5420145051336485498",
    "➕": "5420323438508155202", "🗑": "5422557736330106570", "🎁": "5420396762189831222",
    "➤": "5420618897898381296", "🏢": "5420156334215565595", "💳": "5190899075968441286",
    "📝": "5192739271886282680", "🛡": "5190447043545438788", "🤝": "5192805934073685937",
    "💰": "5190576863226933563", "👀": "5190645917711114179", "🕹": "5193100774988617665",
    "🟢": "5192812028632274956", "🧪": "5190781475468915802", "🎨": "5190751148704833975",
    "📂": "5257969839313526622", "🌍": "5780471598922337683", "📌": "5318986077455795572",
    "📢": "5789428375261023681", "🆔": "5226929552319594190", "📈": "5352877703043258544",
    "🔔": "5352980533150259581", "🏦": "5429612421977253466", "🧾": "5192739271886282680",
    "👨‍⚖️": "5334763399299506604", "🔍": "5463352748751753567", "🔑": "5197288647275071607",
    "🏆": "5240021484516185513", "🚦": "5429571662737611814", "👥": "5420145051336485498", 
    "🎯": "5352922460897452503", "📶": "5429353834881261942", "⏳": "5337172996211648018", 
    "🔸": "5429576112323732785", "🎉": "5420396762189831222", "💵": "5429612421977253466", 
    "👑": "5352838545826420397", "↳": "5420618897898381296",
    "🇺🇸": "5913463998522592692", "🇺🇦": "5911406692007941050", "🇵🇱": "5913550391789752571",
    "🇰🇿": "5913724621433082323", "🇨🇳": "5913779335021466780", "🇦🇿": "5911197578640233518",
    "🇪🇺": "5911106310585193018", "🇦🇲": "5913272455866093666", "🇷🇺": "5913274246867456342",
    "🇺🇿": "5911051846104912282", "🇩🇪": "5911096835887337583", "🇯🇵": "5913293711659241040",
    "🇹🇷": "5910995113881901195", "🇧🇾": "5911011185649521599", "🇬🇧": "5913443365499703513",
    "🇮🇳": "5913754823643107921", "🇧🇷": "5911148568768418614", "🇿🇲": "5913564754160389778",
    "🇾🇪": "5913346492512341993", "🏴󠁧󠁢󠁷󠁬󠁳󠁿": "5911297801702084799", "🇻🇳": "5913428887164949581",
    "🇻🇦": "5911211932420938860", "🇻🇺": "5913511535220625585", "🇺🇾": "5913623088406204470",
    "🇦🇪": "5913726554168365343", "🇺🇬": "5913488939397681980", "🇹🇲": "5913315521503170180",
    "🇹🇳": "5911332947419468671", "🇹🇹": "5911228635548750294", "🇹🇬": "5913423260757790970",
    "🇹🇭": "5913617968805187987", "🇹🇿": "5911418949844603556", "🇹🇯": "5911287639809463107",
    "🇨🇭": "5913271227505448072", "🇸🇪": "5911156510162949403", "🇸🇿": "5913374525763883286",
    "🇸🇷": "5913275539652611719", "🇸🇩": "5911387497799094470", "🇪🇸": "5911193287967904547",
    "🇱🇰": "5911293163137406640", "🇸🇸": "5911406262511211744", "🇿🇦": "5911203119148044594",
    "🇸🇴": "5911397852965244436", "🇸🇧": "5911482712929080608", "🇸🇮": "5913431983836368644",
    "🇸🇰": "5913751666842145020", "🇸🇬": "5911531460808051849", "🇸🇱": "5911210450657218661",
    "🇸🇨": "5911185183364616913", "🇷🇸": "5913592598433369871", "🇸🇳": "5910995302860461643",
    "🏴󠁧󠁢󠁳󠁣󠁴󠁿": "5911460091336331851", "🇸🇹": "5913574331937462345", "🇸🇲": "5913587968458625465",
    "🇼🇸": "5913325971158602854", "🇰🇳": "5913691898077253637", "🇻🇨": "5911318941531116255",
    "🇱🇨": "5911243659344351824", "🇵🇸": "5913684768431541668", "🇷🇼": "5911455229433352234",
    "🇷🇴": "5913460373570195273", "🇶🇦": "5911260864983339619", "🇵🇷": "5911504350974317480",
    "🇵🇹": "5911023653939581472", "🇵🇭": "5911268638874145162", "🇵🇪": "5911207993935925780",
    "🇵🇾": "5911014265141072316", "🇵🇬": "5911107251183030903", "🇵🇦": "5913428968769327174",
    "🇵🇼": "5911283903187915549", "🇵🇰": "5913705895375672082", "🇴🇲": "5913570801474343473",
    "🇳🇴": "5913617397574537046", "🇳🇬": "5911143844304393105", "🇳🇪": "5911270086278124251",
    "🇳🇿": "5913640044937089340", "🇳🇱": "5913367645226275100", "🇳🇵": "5913496520014958723",
    "🇳🇦": "5911108535378252443", "🇲🇿": "5911333419865871464", "🇲🇦": "5911482111633658301",
    "🇲🇪": "5913239436157522151", "🇲🇳": "5911041383564580038", "🇲🇨": "5911245347266500057",
    "🇲🇩": "5913456847402045950", "🇲🇻": "5913501399097806832", "🇲🇱": "5911305266355245916",
    "🇲🇹": "5911023714069123567", "🇧🇲": "5913680005312811090", "🇲🇶": "5911378005921370347",
    "🇲🇭": "5913235935759175692", "🇲🇺": "5913291113204027321", "🇲🇽": "5913687302462246518",
    "🇫🇲": "5911271104185373336", "🇲🇾": "5913654360063087453", "🇰🇪": "5911154710571651231",
    "🇲🇬": "5913766918271012920", "🇲🇰": "5913394029210374721", "🇱🇺": "5913390842344640293",
    "🇱🇹": "5911172315642597775", "🇱🇮": "5911166650580734660", "🇱🇾": "5911236989260140996",
    "🇱🇷": "5913324167272337727", "🇰🇮": "5911294443037660118", "🇽🇰": "5911433681582429010",
    "🇰🇼": "5913290705182134003", "🇰🇬": "5911202161370337549", "🇱🇦": "5913718526874489279",
    "🇱🇻": "5913738489882480243", "🇱🇧": "5911504273664905447", "🇱🇸": "5911059881988723711",
    "🇮🇩": "5913479361620611038", "🇮🇷": "5911308891307643032", "🇮🇶": "5911382442622587735",
    "🇮🇪": "5913440715504881532", "🇮🇱": "5911471936856134692", "🇮🇹": "5913688444923547525",
    "🇯🇲": "5913232280742006526", "🇯🇴": "5913234136167878475", "🇮🇸": "5911047899029967246",
    "🇭🇺": "5913767635530551104", "🇭🇳": "5911406889576436289", "🇭🇹": "5913459789454643194",
    "🇬🇾": "5913579412883771480", "🇬🇼": "5911398694778836149", "🇬🇳": "5913471858312744319",
    "🇬🇹": "5913324858762072330", "🇬🇩": "5913228063084121946", "🇬🇷": "5911210399117611448",
    "🇬🇭": "5913391155877252952", "🇬🇪": "5913434771270144023", "🇬🇲": "5913657267755945883",
    "🇬🇦": "5911037896051137264", "🇫🇷": "5913605586414473124", "🇫🇮": "5911041344909873378",
    "🇫🇯": "5911393832875856716", "🇪🇹": "5911078333168227043", "🇩🇴": "5911152099231536123",
    "🇹🇱": "5911141915864076479", "🇪🇨": "5911273865849347408", "🇪🇬": "5913694831539916769",
    "🇸🇻": "5913238624408703010", "🏴󠁧󠁢󠁥󠁮󠁧󠁿": "5913475719488344315", "🇪🇪": "5910986042910969906",
    "🇩🇲": "5911377121158107430", "🇩🇯": "5911407709915190157", "🇩🇰": "5911206009661034712",
    "🇨🇾": "5911023550860366409", "🇭🇷": "5913692684056269311", "🇨🇷": "5911261745451635030",
    "🇨🇬": "5911338788574990168", "🇨🇩": "5913770362834783827", "🇰🇲": "5911338582416560604",
    "🇰🇭": "5913699998385573485", "🇨🇲": "5911172109484167745", "🇨🇦": "5913623736946265914",
    "🇨🇻": "5913571501554012193", "🇨🇫": "5913443245240619222", "🇹🇩": "5913299849167507310",
    "🇨🇿": "5911198691036764307", "🇨🇱": "5911470957603592832", "🇨🇴": "5913773060074246009",
    "🇧🇮": "5913766441529642752", "🇧🇼": "5911513782722499475", "🇧🇦": "5913700002680541032",
    "🇧🇴": "5913638795101606133", "🇧🇹": "5913236734623093021", "🇧🇯": "5913735869952430547",
    "🇦🇷": "5913573356979884082", "🇦🇺": "5913632326880858455", "🇦🇹": "5911338831524664592",
    "🇧🇸": "5911451643135660214", "🇧🇭": "5913581663446634403", "🇧🇩": "5911365056594973179",
    "🇧🇧": "5911016996740272263", "🇧🇪": "5913529642802745141", "🇧🇿": "5913355005137522807",
    "🇦🇬": "5913389025573475085", "🇦🇴": "5913753316109586411", "🇦🇩": "5911314702398396902",
    "🇩🇿": "5913782968563800236", "🇦🇱": "5911357458797826163", "🇦🇫": "5913492040364068694",
    "🇿🇼": "5911092502265336396", "🇨🇺": "5431551436502611633", "🇰🇵": "5434142701941437163",
    "🇻🇪": "5434009132753499322", "🇸🇾": "5433910876786670092", "🇲🇲": "5433666360003540231",
    "🇳🇮": "5334807849418003620", "🇰🇷": "5913371673905598425", "🇬🇶": "5911306279967529251",
    "🇬🇱": "5292014752283774878", "🇫🇴": "5296469342039327674", "🇨🇮": "5222233374948602940",
    "🇧🇳": "5911336409163109113", "🇧🇬": "5294329219965272288", "🇧🇫": "5913407764515786948",
    "🇪🇷": "5433723401464198287", "🇲🇼": "5433968339154122439", "🇲🇷": "5433859405898594234",
    "🇳🇷": "5434131139889478358", "🇸🇦": "4985897134424328239", "🇹🇴": "5433640100573491806",
    "🇹🇻": "5433684690923961019", "🇹🇼": "5366187256937726720", "🇭🇰": "5292166459118606932",
    "🇲🇴": "6323557758096377611"
}

# ---------- Emoji engine: built-in map + admin custom premium + admin swaps ----------
_FE0F = "\ufe0f"
_emj_ver = 0
_emj_cache = {"ver": -1}

def emoji_changed():
    global _emj_ver
    _emj_ver += 1

def _emj_build():
    global _emj_cache
    if _emj_cache.get("ver") == _emj_ver: return _emj_cache
    prem = dict(GLOBAL_BODY_EMOJIS)
    for k, v in (bot_settings.get("emoji_premium") or {}).items():
        if k and v: prem[k] = str(v)
    swaps = {k: v for k, v in (bot_settings.get("emoji_swap") or {}).items() if k and v}
    def variants(d):
        out = dict(d)
        for k, v in d.items():
            s = k.replace(_FE0F, "")
            if s and s not in out: out[s] = v
        return out
    def comp(d):
        return re.compile("|".join(re.escape(k) for k in sorted(d, key=len, reverse=True))) if d else None
    prem, swaps = variants(prem), variants(swaps)
    _emj_cache = {"prem": prem, "swap": swaps, "prem_re": comp(prem), "swap_re": comp(swaps), "ver": _emj_ver}
    return _emj_cache

def apply_swaps(text):
    c = _emj_build(); rx = c["swap_re"]
    if not rx: return str(text)
    return _outside_tg_emoji(text, lambda t: rx.sub(lambda m: c["swap"][m.group(0)], t))

def apply_emojis(text):
    c = _emj_build(); rx = c["prem_re"]
    if not rx: return str(text)
    return _outside_tg_emoji(text, lambda t: rx.sub(
        lambda m: f'<tg-emoji emoji-id="{c["prem"][m.group(0)]}">{m.group(0)}</tg-emoji>', t))

def _emoji_ok(ch):
    if not ch or len(ch) > 20 or any(c.isspace() for c in ch): return False
    if re.fullmatch(r"[0-9#*]\ufe0f?\u20e3", ch): return True
    return not re.search(r"[A-Za-z0-9<>&{}=]", ch)

def validate_custom_emoji(eid):
    """True = Telegram knows this id, False = it does not, None = could not check."""
    try:
        r = requests.post(BASE_URL + "getCustomEmojiStickers", json={"custom_emoji_ids": [str(eid)]}, timeout=10).json()
        if r.get("ok"): return bool(r.get("result"))
    except Exception: pass
    return None

def emoji_set_premium(ch, eid, validate=True):
    ch = str(ch).strip(); eid = str(eid).strip()
    if not _emoji_ok(ch): return False, f"❌ <code>{html.escape(ch[:20])}</code> is not a valid emoji"
    if not re.fullmatch(r"\d{10,25}", eid): return False, "❌ Premium emoji ID must be digits only"
    note = ""
    if validate:
        v = validate_custom_emoji(eid)
        if v is False: return False, f"❌ ID <code>{eid}</code> does not exist on Telegram"
        if v is None: note = " (ID could not be checked)"
    bot_settings.setdefault("emoji_premium", {})[ch] = eid
    (bot_settings.get("emoji_swap") or {}).pop(ch, None)
    save_local_data(); emoji_changed()
    return True, f"✅ {ch} → premium <code>{eid}</code>{note}"

def emoji_set_swap(ch, new):
    ch = str(ch).strip(); new = str(new).strip()
    if not _emoji_ok(ch): return False, f"❌ <code>{html.escape(ch[:20])}</code> is not a valid emoji"
    if not new or len(new) > 20 or re.search(r"[<>&\s]", new): return False, "❌ New emoji is not valid"
    bot_settings.setdefault("emoji_swap", {})[ch] = new
    (bot_settings.get("emoji_premium") or {}).pop(ch, None)
    save_local_data(); emoji_changed()
    return True, f"✅ {ch} ➜ {new}"

def emoji_remove(ch):
    ch = str(ch).strip(); hit = False
    for key in ("emoji_premium", "emoji_swap"):
        d = bot_settings.get(key) or {}
        if ch in d: d.pop(ch); hit = True
    if hit:
        save_local_data(); emoji_changed()
        return True, f"🗑 {ch} removed"
    if ch in GLOBAL_BODY_EMOJIS or ch.replace(_FE0F, "") in GLOBAL_BODY_EMOJIS:
        return False, f"ℹ️ {ch} is a built-in emoji. Set a different ID or a swap instead."
    return False, f"⚠️ {ch} was not in the custom list"

def emoji_snapshot():
    return {"premium": dict(bot_settings.get("emoji_premium") or {}),
            "swap": dict(bot_settings.get("emoji_swap") or {}),
            "builtin": len(GLOBAL_BODY_EMOJIS)}

def _utf16_slice(s, off, ln):
    b = str(s).encode("utf-16-le")
    return b[off * 2:(off + ln) * 2].decode("utf-16-le", "ignore")

def emj_apply_input(text, entities=None):
    """Lines: 💌{ID} = premium | 💌=❤️ = swap | -💌 = remove | a real premium emoji = save its ID."""
    raw = str(text or ""); report = []
    for e in (entities or []):
        if e.get("type") == "custom_emoji" and e.get("custom_emoji_id"):
            ch = _utf16_slice(raw, e["offset"], e["length"]).strip()
            if ch:
                report.append(emoji_set_premium(ch, e["custom_emoji_id"], validate=False)[1])
                raw = raw.replace(ch, " ")
    for line in raw.splitlines():
        s = line.strip()
        if not s: continue
        m = re.fullmatch(r"(?:-|del\s+)\s*(\S+)", s, flags=re.I)
        if m: report.append(emoji_remove(m.group(1))[1]); continue
        found = list(re.finditer(r"(\S+?)\{(\d{10,25})\}", s))
        if found:
            for f in found: report.append(emoji_set_premium(f.group(1), f.group(2))[1])
            continue
        m = re.fullmatch(r"(\S+?)\s*(?:=>|->|=|→)\s*(\S+)", s)
        if m: report.append(emoji_set_swap(m.group(1), m.group(2))[1]); continue
        report.append(f"⚠️ Can't read: <code>{html.escape(s[:40])}</code>")
    return report or ["⚠️ Nothing to do"]

EMJ_HELP = ("Send one or more lines:\n"
            "<code>💌{97279228637383828}</code> → make 💌 premium\n"
            "<code>💌=❤️</code> → swap a normal emoji\n"
            "<code>-💌</code> → remove\n\n"
            "Or send a real premium emoji and I will read its ID.")

def emj_home_view(note=""):
    cust = bot_settings.get("emoji_premium") or {}; sw = bot_settings.get("emoji_swap") or {}
    txt = (note + "🎨 <b>EMOJI EDITOR</b>\n━━━━━━━━━━━━━━━━━━\n"
           f"Premium mode: <b>{'ON' if premium_emoji_on() else 'OFF'}</b>\n"
           f"Custom premium: <b>{len(cust)}</b> • Swaps: <b>{len(sw)}</b> • Built-in: <b>{len(GLOBAL_BODY_EMOJIS)}</b>\n\n"
           "A mapped emoji turns premium in all texts <i>and</i> button labels (one icon per button).")
    kb = {"inline_keyboard": [
        [{"text": "➕ ADD / CHANGE", "callback_data": "emj_add", "style": "success"},
         {"text": "🗑 REMOVE", "callback_data": "emj_del", "style": "danger"}],
        [{"text": "📋 LIST", "callback_data": "emj_list", "style": "primary"}],
        [{"text": "BACK", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5267490665117275176", "style": "danger"}]]}
    return txt, kb

def emj_list_view():
    cust = bot_settings.get("emoji_premium") or {}; sw = bot_settings.get("emoji_swap") or {}
    lines = ["📋 <b>CUSTOM EMOJI</b>", "━━━━━━━━━━━━━━━━━━"]
    for ch, i in list(cust.items())[:40]: lines.append(f"{ch} → <code>{i}</code>")
    for ch, n in list(sw.items())[:40]: lines.append(f"{ch} ➜ {n}")
    if not cust and not sw: lines.append("<i>No custom emoji yet.</i>")
    kb = {"inline_keyboard": [[{"text": "BACK", "callback_data": "emj_home", "icon_custom_emoji_id": "5267490665117275176", "style": "danger"}]]}
    return "\n".join(lines), kb

def emj_cancel_kb():
    return {"inline_keyboard": [[{"text": "CANCEL", "callback_data": "emj_home", "icon_custom_emoji_id": "5420130255174145507", "style": "danger"}]]}

def emj_owner_rows():
    rows = [] if web_sync.HIDE_BOT_EMOJI_EDITOR else [[{"text": "🎨 EMOJI EDITOR", "callback_data": "emj_home", "style": "primary"}]]
    if WEBAPP_URL.startswith("https://"):
        rows.append([{"text": "🌐 WEB PANEL", "web_app": {"url": WEBAPP_URL}, "style": "success"}])
    return rows

# ==========================================
# Premium Apps & Service Keywords Setup
# ==========================================
PREMIUM_APPS = {
    "Facebook": {"emoji": "📘", "id": "5429172110520003976"},
    "WhatsApp": {"emoji": "💬", "id": "5429612632430654504"},
    "Telegram": {"emoji": "✈️", "id": "5429136513831057777"},
    "Instagram": {"emoji": "📸", "id": "5429478178479447442"},
    "Google": {"emoji": "🔍", "id": "5429558795015593080"},
    "Microsoft": {"emoji": "🪟", "id": "5979047775470358891"},
    "TikTok": {"emoji": "🎵", "id": "5429132656950419591"},
    "Bkash": {"emoji": "🏦", "id": "5431552076452766597"},
    "Binance": {"emoji": "💱", "id": "5429438106434575354"},
    "Snapchat": {"emoji": "👻", "id": "5429398137468919845"},
    "Uber": {"emoji": "🚗", "id": "5298715455316303708"},
    "Discord": {"emoji": "🎬", "id": "5429594374524676604"},
    "Amazon": {"emoji": "🌟", "id": "5431358656895568355"},
    "Viber": {"emoji": "💜", "id": "5429470576387335368"},
    "Twitter": {"emoji": "🐦", "id": "5431899135580087595"},
    "Netflix": {"emoji": "🎥", "id": "5431641055290235797"},
    "Spotify": {"emoji": "🎵", "id": "5429235839244739644"},
    "Foodpanda": {"emoji": "🐼", "id": "5336879280578138635"},
    "Pathao": {"emoji": "🛵", "id": "5336879280578138635"},
    "ChatGPT": {"emoji": "🤖", "id": "5429503209548847635"},
    "Imo": {"emoji": "💭", "id": "5431378937731129128"},
    "Other": {"emoji": "📶", "id": "5429353834881261942"}
}

SERVICE_SMS_KEYWORDS = {
    "Facebook": ["facebook", "fb code", "fb", "meta"],
    "WhatsApp": ["whats", "whatsapp", "whatsapp code"],
    "Telegram": ["telegram", "tg code"],
    "Instagram": ["instagram", "ig code"],
    "Google": ["google", "Googl"],
    "Microsoft": ["microsoft", "micro", "Microsof", "xbox"],
    "TikTok": ["tiktok", "tik tok"],
    "Bkash": ["bkash"],
    "Binance": ["binance", "bnb"],
    "Snapchat": ["snapchat", "snap"],
    "Uber": ["uber"],
    "Discord": ["discord"],
    "Amazon": ["amazon", "aws"],
    "Viber": ["viber"],
    "Twitter": ["twitter", "x.com"],
    "Netflix": ["netflix"],
    "Spotify": ["spotify"],
    "Foodpanda": ["foodpanda", "panda"],
    "Pathao": ["pathao"],
    "ChatGPT": ["openai", "chatgpt"],
    "Imo": ["imo code", "imo"]
}

COUNTRY_CODES = {
    "1": "🇺🇸 USA/Canada", "380": "🇺🇦 Ukraine", "48": "🇵🇱 Poland", "7": "🇰🇿 Kazakhstan",
    "86": "🇨🇳 China", "994": "🇦🇿 Azerbaijan", "374": "🇦🇲 Armenia", "79": "🇷🇺 Russia",
    "998": "🇺🇿 Uzbekistan", "49": "🇩🇪 Germany", "81": "🇯🇵 Japan", "90": "🇹🇷 Turkey",
    "375": "🇧🇾 Belarus", "44": "🇬🇧 United Kingdom", "91": "🇮🇳 India", "55": "🇧🇷 Brazil",
    "260": "🇿🇲 Zambia", "967": "🇾🇪 Yemen", "84": "🇻🇳 Vietnam", "379": "🇻🇦 Vatican City",
    "678": "🇻🇺 Vanuatu", "598": "🇺🇾 Uruguay", "971": "🇦🇪 UAE", "256": "🇺🇬 Uganda",
    "993": "🇹🇲 Turkmenistan", "216": "🇹🇳 Tunisia", "228": "🇹🇬 Togo", "66": "🇹🇭 Thailand",
    "255": "🇹🇿 Tanzania", "992": "🇹🇯 Tajikistan", "41": "🇨🇭 Switzerland", "46": "🇸🇪 Sweden",
    "268": "🇸🇿 Eswatini", "597": "🇸🇷 Suriname", "249": "🇸🇩 Sudan", "34": "🇪🇸 Spain",
    "94": "🇱🇰 Sri Lanka", "211": "🇸🇸 South Sudan", "27": "🇿🇦 South Africa", "252": "🇸🇴 Somalia",
    "677": "🇸🇧 Solomon Islands", "386": "🇸🇮 Slovenia", "421": "🇸🇰 Slovakia", "65": "🇸🇬 Singapore",
    "232": "🇸🇱 Sierra Leone", "248": "🇸🇨 Seychelles", "381": "🇷🇸 Serbia", "221": "🇸🇳 Senegal",
    "239": "🇸🇹 Sao Tome", "378": "🇸🇲 San Marino", "685": "🇼🇸 Samoa", "970": "🇵🇸 Palestine",
    "250": "🇷🇼 Rwanda", "40": "🇷🇴 Romania", "974": "🇶🇦 Qatar", "351": "🇵🇹 Portugal",
    "63": "🇵🇭 Philippines", "51": "🇵🇪 Peru", "595": "🇵🇾 Paraguay", "675": "🇵🇬 Papua New Guinea",
    "507": "🇵🇦 Panama", "680": "🇵🇼 Palau", "92": "🇵🇰 Pakistan", "968": "🇴🇲 Oman",
    "47": "🇳🇴 Norway", "234": "🇳🇬 Nigeria", "227": "🇳🇪 Niger", "64": "🇳🇿 New Zealand",
    "31": "🇳🇱 Netherlands", "977": "🇳🇵 Nepal", "264": "🇳🇦 Namibia", "258": "🇲🇿 Mozambique",
    "212": "🇲🇦 Morocco", "382": "🇲🇪 Montenegro", "976": "🇲🇳 Mongolia", "377": "🇲🇨 Monaco",
    "373": "🇲🇩 Moldova", "960": "🇲🇻 Maldives", "223": "🇲🇱 Mali", "356": "🇲🇹 Malta",
    "596": "🇲🇶 Martinique", "692": "🇲🇭 Marshall Islands", "230": "🇲🇺 Mauritius", "52": "🇲🇽 Mexico",
    "691": "🇫🇲 Micronesia", "60": "🇲🇾 Malaysia", "254": "🇰🇪 Kenya", "261": "🇲🇬 Madagascar",
    "389": "🇲🇰 North Macedonia", "352": "🇱🇺 Luxembourg", "370": "🇱🇹 Lithuania", "423": "🇱🇮 Liechtenstein",
    "218": "🇱🇾 Libya", "231": "🇱🇷 Liberia", "686": "🇰🇮 Kiribati", "383": "🇽🇰 Kosovo",
    "965": "🇰🇼 Kuwait", "996": "🇰🇬 Kyrgyzstan", "856": "🇱🇦 Laos", "371": "🇱🇻 Latvia",
    "961": "🇱🇧 Lebanon", "266": "🇱🇸 Lesotho", "62": "🇮🇩 Indonesia", "98": "🇮🇷 Iran",
    "964": "🇮🇶 Iraq", "353": "🇮🇪 Ireland", "972": "🇮🇱 Israel", "39": "🇮🇹 Italy",
    "962": "🇯🇴 Jordan", "354": "🇮🇸 Iceland", "36": "🇭🇺 Hungary", "504": "🇭🇳 Honduras",
    "509": "🇭🇹 Haiti", "592": "🇬🇾 Guyana", "245": "🇬🇼 Guinea-Bissau", "224": "🇬🇳 Guinea",
    "502": "🇬🇹 Guatemala", "30": "🇬🇷 Greece", "233": "🇬🇭 Ghana", "995": "🇬🇪 Georgia",
    "220": "🇬🇲 Gambia", "241": "🇬🇦 Gabon", "33": "🇫🇷 France", "358": "🇫🇮 Finland",
    "679": "🇫🇯 Fiji", "251": "🇪🇹 Ethiopia", "670": "🇹🇱 Timor-Leste", "593": "🇪🇨 Ecuador",
    "20": "🇪🇬 Egypt", "503": "🇸🇻 El Salvador", "372": "🇪🇪 Estonia", "253": "🇩🇯 Djibouti",
    "45": "🇩🇰 Denmark", "357": "🇨🇾 Cyprus", "385": "🇭🇷 Croatia", "506": "🇨🇷 Costa Rica",
    "242": "🇨🇬 Congo", "243": "🇨🇩 DR Congo", "269": "🇰🇲 Comoros", "855": "🇰🇭 Cambodia",
    "237": "🇨🇲 Cameroon", "238": "🇨🇻 Cape Verde", "236": "🇨🇫 CAR", "235": "🇹🇩 Chad",
    "420": "🇨🇿 Czechia", "56": "🇨🇱 Chile", "57": "🇨🇴 Colombia", "257": "🇧🇮 Burundi",
    "267": "🇧🇼 Botswana", "387": "🇧🇦 Bosnia", "591": "🇧🇴 Bolivia", "975": "🇧🇹 Bhutan",
    "229": "🇧🇯 Benin", "54": "🇦🇷 Argentina", "61": "🇦🇺 Australia", "43": "🇦🇹 Austria",
    "973": "🇧🇭 Bahrain", "880": "🇧🇩 Bangladesh", "32": "🇧🇪 Belgium", "501": "🇧🇿 Belize",
    "244": "🇦🇴 Angola", "376": "🇦🇩 Andorra", "213": "🇩🇿 Algeria", "355": "🇦🇱 Albania",
    "93": "🇦🇫 Afghanistan", "263": "🇿🇼 Zimbabwe", "53": "🇨🇺 Cuba", "850": "🇰🇵 North Korea",
    "58": "🇻🇪 Venezuela", "963": "🇸🇾 Syria", "95": "🇲🇲 Myanmar", "505": "🇳🇮 Nicaragua",
    "82": "🇰🇷 South Korea", "240": "🇬🇶 Equatorial Guinea", "299": "🇬🇱 Greenland", "298": "🇫🇴 Faroe Islands",
    "225": "🇨🇮 Ivory Coast", "673": "🇧🇳 Brunei", "359": "🇧🇬 Bulgaria", "226": "🇧🇫 Burkina Faso",
    "291": "🇪🇷 Eritrea", "265": "🇲🇼 Malawi", "222": "🇲🇷 Mauritania", "674": "🇳🇷 Nauru",
    "966": "🇸🇦 Saudi Arabia", "676": "🇹🇴 Tonga", "688": "🇹🇻 Tuvalu", "886": "🇹🇼 Taiwan",
    "852": "🇭🇰 Hong Kong", "853": "🇲🇴 Macau", "297": "🇦🇼 Aruba", "599": "🇨🇼 Curacao",
    "500": "🇫🇰 Falkland Islands", "594": "🇬🇫 French Guiana", "590": "🇬🇵 Guadeloupe", "262": "🇷🇪 Reunion",
    "687": "🇳🇨 New Caledonia", "683": "🇳🇺 Niue", "672": "🇳🇫 Norfolk Island", "681": "🇼🇫 Wallis and Futuna",
    "682": "🇨🇰 Cook Islands", "689": "🇵🇫 French Polynesia", "350": "🇬🇮 Gibraltar", "508": "🇵🇲 Saint Pierre"
}

def get_country_info(range_str):
    clean_range = str(range_str or "").replace("X", "")
    for code, name in sorted(COUNTRY_CODES.items(), key=lambda x: len(x[0]), reverse=True):
        if clean_range.startswith(code): return code, name
    return clean_range[:3], f"🏳️ Other (+{clean_range[:3]})"

# ==========================================
# OTP Forwarding Pipeline 
# ==========================================

_SVC_ALIASES = {}
def _svc_norm(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())

def _svc_aliases():
    if not _SVC_ALIASES:
        for svc in PREMIUM_APPS:
            if svc == "Other": continue
            al = {_svc_norm(svc)}
            for kw in SERVICE_SMS_KEYWORDS.get(svc, []):
                k = _svc_norm(kw)
                if k: al.add(k)
            _SVC_ALIASES[svc] = al
    return _SVC_ALIASES

def detect_service(message_text, raw_sid=""):
    """1) trust the panel's own service name (exact, alias like FB/Meta, or truncated like 'Faceboo')
       2) otherwise look for the keyword in the SMS text as a WHOLE word (no random substring hits)."""
    msg_lower = str(message_text or "").lower()
    sid_norm = _svc_norm(raw_sid)
    if sid_norm and sid_norm not in ("unknown", "other", "none", "null"):
        aliases_map = _svc_aliases()
        for svc, aliases in aliases_map.items():
            if sid_norm in aliases: return svc
        if len(sid_norm) >= 4:
            for svc, aliases in aliases_map.items():
                if _svc_norm(svc).startswith(sid_norm): return svc          # truncated name
                if any(len(a) >= 5 and a in sid_norm for a in aliases): return svc  # e.g. facebooksms
    for svc, keywords in SERVICE_SMS_KEYWORDS.items():
        for kw in keywords:
            k = str(kw).lower()
            if k == "meta": continue   # too ambiguous in SMS text (banks etc.); still accepted as a panel sid
            if re.search(rf"(?<![a-z0-9]){re.escape(k)}(?![a-z0-9])", msg_lower): return svc
            if len(k) >= 6 and k in msg_lower: return svc
    return "Other"

def get_service_info_html(service_name):
    app_info = PREMIUM_APPS.get(service_name, PREMIUM_APPS["Other"])
    emoji_id = app_info["id"]
    normal_emoji = app_info["emoji"]
    short_name = service_name.upper()
    if short_name == "FACEBOOK": short_name = "FB"
    if short_name == "WHATSAPP": short_name = "WS"
    if short_name == "INSTAGRAM": short_name = "IG"
    
    return f'<tg-emoji emoji-id="{emoji_id}">{normal_emoji}</tg-emoji> <b>{html.escape(short_name)}</b>', emoji_id

def extract_otp_code(message_text):
    # 🌟 স্পেস বা হাইফেনসহ ৩-৮ ডিজিটের কোড ধরার লজিক
    match = re.search(r'\b(\d{3}[\s-]?\d{3,4}|\d{4,8})\b', str(message_text))
    if match: return match.group(1)
    return "COPY"

def deliver_to_inbox(user_id, service_name, raw_number, msg_text, current_balance, reward):
    c_code, c_name = get_country_info(raw_number)
    service_html, srv_eid = get_service_info_html(service_name)
    clean_raw_number = str(raw_number).lstrip('+') 
    
    text = (
        f"— — — — — — — — — —\n"
        f"<blockquote>{service_html} <code>+{clean_raw_number}</code></blockquote>\n"
        f"<blockquote><tg-emoji emoji-id=\"5420323438508155202\">➕</tg-emoji> <b>ADDED</b>  ➜ {reward:.2f} TK</blockquote>\n"
        f"<blockquote><tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>BALANCE</b> ➜ {current_balance:.2f} TK</blockquote>\n"
        f"— — — — — — — — — —"
    )
    otp = extract_otp_code(msg_text)
    markup = {"inline_keyboard": [[{"text": f"{otp}", "icon_custom_emoji_id": srv_eid, "copy_text": {"text": otp}, "style": "success"}]]}
    send_message(user_id, text, reply_markup=markup)

def generate_otp_display(service_name, raw_number, message_text):
    if bot_settings.get("otp_format", "mini") == "big":
        try:
            return generate_big_otp_display(service_name, raw_number, message_text)
        except Exception as e:
            print(f"Big OTP format error, using mini: {e}")
    c_code, c_name = get_country_info(raw_number)
    
    parts = c_name.split(" ", 1)
    country_emoji = parts[0]
    
    if len(raw_number) > 6:
        masked_number = f"{raw_number[:3]}DXA{raw_number[-3:]}"
    else:
        masked_number = raw_number
        
    service_html, srv_eid = get_service_info_html(service_name)
    
    text = (
        f"━━━━━━━━━━━━━━━━━\n"
        f"{service_html} ➜ {country_emoji} <code>{html.escape(masked_number)}</code>\n"
        f"━━━━━━━━━━━━━━━━━"
    )
    
    otp = extract_otp_code(message_text)
    
    # 🌟 রেঞ্জ বের করার লজিক (ডিফল্ট ৫ ডিজিট)
    clean_range = str(raw_number)[:5] if len(str(raw_number)) >= 5 else str(raw_number)
    deep_link = f"https://t.me/{BOT_USERNAME}?start=alloc_{clean_range}_{service_name.lower()}"
    
    markup = {"inline_keyboard": []}
    
    # 🌟 প্রথম লাইন (CHANNEL এবং OTP)
    row1 = []
    main_channel_link = bot_settings.get("main_channel_link", "")
    if main_channel_link:
        row1.append({"text": "𝗖𝗛𝗔𝗡𝗡𝗘𝗟", "url": main_channel_link, "icon_custom_emoji_id": "5429353834881261942", "style": "primary"})
        
    row1.append({"text": f"{otp}", "icon_custom_emoji_id": srv_eid, "copy_text": {"text": otp}, "style": "success"})
    
    markup["inline_keyboard"].append(row1)
    
    # 🌟 দ্বিতীয় লাইন (GET NUMBER)
    markup["inline_keyboard"].append([
        {"text": "GET NUMBER", "url": deep_link, "icon_custom_emoji_id": "5429167978761461870", "style": "danger"}
    ])
    
    return text, markup

# ==========================================
# BIG OTP FORMAT (admin panel theke MINI / BIG switch kora jay)
# ==========================================
BIG_MASK_TAG = "ARD"           # number mask: +2877ARD982  (first 4 + TAG + last 3)
SHOW_OTP_IN_BIG_TEXT = False   # False = code message e hide thake, shudhu copy button e thake

LANG_BY_CODE = {
    "1": "English", "7": "Russian", "20": "Arabic", "27": "English", "30": "Greek", "31": "Dutch", "32": "French",
    "33": "French", "34": "Spanish", "36": "Hungarian", "39": "Italian", "40": "Romanian", "41": "German",
    "43": "German", "44": "English", "45": "Danish", "46": "Swedish", "47": "Norwegian", "48": "Polish",
    "49": "German", "51": "Spanish", "52": "Spanish", "53": "Spanish", "54": "Spanish", "55": "Portuguese",
    "56": "Spanish", "57": "Spanish", "58": "Spanish", "60": "Malay", "61": "English", "62": "Indonesian",
    "63": "English", "64": "English", "65": "English", "66": "Thai", "81": "Japanese", "82": "Korean",
    "84": "Vietnamese", "86": "Chinese", "90": "Turkish", "91": "Hindi", "92": "Urdu", "93": "Pashto",
    "94": "Sinhala", "95": "Burmese", "98": "Persian", "211": "English", "212": "French", "213": "French",
    "216": "French", "218": "Arabic", "220": "English", "221": "French", "222": "French", "223": "French",
    "224": "French", "225": "French", "226": "French", "227": "French", "228": "French", "229": "French",
    "230": "English", "231": "English", "232": "English", "233": "English", "234": "English", "235": "French",
    "236": "French", "237": "French", "238": "Portuguese", "239": "Portuguese", "240": "Spanish",
    "241": "French", "242": "French", "243": "French", "244": "Portuguese", "245": "Portuguese",
    "249": "Arabic", "250": "Kinyarwanda", "251": "Amharic", "252": "Somali", "253": "French",
    "254": "English", "255": "Swahili", "256": "English", "257": "French", "258": "Portuguese",
    "260": "English", "261": "Malagasy", "262": "French", "263": "English", "264": "English",
    "265": "English", "266": "English", "267": "English", "351": "Portuguese", "353": "English",
    "355": "Albanian", "358": "Finnish", "359": "Bulgarian", "380": "Ukrainian", "381": "Serbian",
    "385": "Croatian", "420": "Czech", "421": "Slovak", "855": "Khmer", "856": "Lao", "880": "Bengali",
    "961": "Arabic", "962": "Arabic", "963": "Arabic", "964": "Arabic", "965": "Arabic", "966": "Arabic",
    "967": "Arabic", "968": "Arabic", "971": "Arabic", "972": "Hebrew", "973": "Arabic", "974": "Arabic",
    "977": "Nepali", "992": "Tajik", "993": "Turkmen", "994": "Azerbaijani", "995": "Georgian",
    "996": "Kyrgyz", "998": "Uzbek",
}

def flag_to_iso(flag):
    flag = str(flag or "")
    if len(flag) >= 2 and all(0x1F1E6 <= ord(c) <= 0x1F1FF for c in flag[:2]):
        return "".join(chr(ord(c) - 0x1F1E6 + 65) for c in flag[:2])
    return ""

def detect_sms_language(c_code, text):
    if str(c_code) in LANG_BY_CODE: return LANG_BY_CODE[str(c_code)]
    t = str(text or "")
    scripts = [("Arabic", "\u0600-\u06FF"), ("Russian", "\u0400-\u04FF"), ("Bengali", "\u0980-\u09FF"),
               ("Hindi", "\u0900-\u097F"), ("Thai", "\u0E00-\u0E7F"), ("Chinese", "\u4E00-\u9FFF"),
               ("Japanese", "\u3040-\u30FF"), ("Korean", "\uAC00-\uD7AF"), ("Hebrew", "\u0590-\u05FF"),
               ("Greek", "\u0370-\u03FF")]
    for name, rng in scripts:
        if re.search(f"[{rng}]", t): return name
    return "English"

def generate_big_otp_display(service_name, raw_number, message_text):
    digits = re.sub(r"\D", "", str(raw_number))
    c_code, c_name = get_country_info(digits)
    country_emoji = c_name.split(" ", 1)[0]
    iso = flag_to_iso(country_emoji)
    iso_tag = f" #{iso}" if iso else ""

    masked = f"{digits[:4]}{BIG_MASK_TAG}{digits[-3:]}" if len(digits) >= 8 else digits
    prefix = digits[:7] if len(digits) >= 7 else digits
    lang = detect_sms_language(c_code, message_text)

    app_info = PREMIUM_APPS.get(service_name, PREMIUM_APPS["Other"])
    svc_html = f'<tg-emoji emoji-id="{app_info["id"]}">{app_info["emoji"]}</tg-emoji>'
    srv_eid = app_info["id"]

    otp = extract_otp_code(message_text)
    body = re.sub(r"\s+", " ", str(message_text or "")).strip()
    if not SHOW_OTP_IN_BIG_TEXT and otp != "COPY":
        code_digits = re.sub(r"\D", "", otp)
        if len(code_digits) >= 3:
            body = re.sub(r"[\s-]?".join(code_digits), "••••••", body)
    if len(body) > 300: body = body[:300] + "..."

    text = (
        f"{country_emoji}{iso_tag} {svc_html} <b>+{html.escape(masked)}</b> |\n"
        f"🎙 {html.escape(lang)}\n"
        f"<blockquote>{html.escape(body)}</blockquote>\n"
        f"<blockquote>#️⃣ Prefix: /pre {html.escape(prefix)}</blockquote>"
    )

    clean_range = digits[:5] if len(digits) >= 5 else digits
    deep_link = f"https://t.me/{BOT_USERNAME}?start=alloc_{clean_range}_{str(service_name).lower()}"

    markup = {"inline_keyboard": [
        [{"text": str(service_name), "icon_custom_emoji_id": srv_eid, "copy_text": {"text": otp}, "style": "success"}]
    ]}
    row2 = []
    main_channel_link = bot_settings.get("main_channel_link", "")
    if main_channel_link:
        row2.append({"text": "Channel", "url": main_channel_link, "icon_custom_emoji_id": "5429353834881261942", "style": "primary"})
    row2.append({"text": "Number", "url": deep_link, "icon_custom_emoji_id": "5429167978761461870", "style": "success"})
    markup["inline_keyboard"].append(row2)
    return text, markup

def send_otp_to_groups(formatted_text, markup):
    global otp_forward_groups
    if not otp_forward_groups: return False
        
    sent_any = False
    for group_id in otp_forward_groups:
        resp = send_message(group_id, formatted_text, reply_markup=markup)
        if resp and resp.get("ok"): sent_any = True
        time.sleep(1) 
        
    return sent_any

# ==========================================
# 2oo9 API & Background Listeners
# ==========================================
def fetch_live_access():
    headers = {"mauthapi": get_api_key()}
    try:
        res = requests.get(f"{API_2OO9_BASE}/liveaccess", headers=headers, timeout=10)
        data = res.json()
        if data.get("meta", {}).get("code") == 200:
            return data.get("data", {}).get("services", [])
    except: pass
    return []

def fetch_live_number(rid):
    headers = {"mauthapi": get_api_key(), "Content-Type": "application/json"}
    payload = {"rid": str(rid)}
    try:
        res = requests.post(f"{API_2OO9_BASE}/getnum", headers=headers, json=payload, timeout=10)
        data = res.json()
        if data.get("meta", {}).get("code") == 200:
            return data.get("data", {})
    except: pass
    return None

_voltx_seen = {}   # sig -> first time seen, so one SMS hit is counted only once

def voltx_console_listener():
    global recent_traffic, voltx_dynamic_data
    cycle_count = 0
    while True:
        if not voltx_active():
            time.sleep(10)
            continue
        try:
            headers = {"mauthapi": get_api_key()}
            res = requests.get(f"{API_2OO9_BASE}/console", headers=headers, timeout=10)
            data = res.json()
            if data.get("meta", {}).get("code") == 200:
                hits = data.get("data", {}).get("hits", [])
                new_traffic, seen_signatures = [], set()
                current_time = int(time.time())
                old_times = {f"{o.get('time', 0)}_{o.get('range', '')}": o.get('local_receive_time', current_time) for o in recent_traffic}
                for _k in [k for k, v in _voltx_seen.items() if current_time - v > 3600]: _voltx_seen.pop(_k, None)
                
                for h in hits:
                    sig = f"{h.get('time', 0)}_{h.get('range', '')}"
                    if sig not in seen_signatures:
                        is_new_hit = sig not in old_times and sig not in _voltx_seen
                        _voltx_seen[sig] = current_time
                        h['local_receive_time'] = current_time if is_new_hit else old_times.get(sig, current_time) 
                        new_traffic.append(h)
                        seen_signatures.add(sig)
                        
                        raw_sid = h.get("sid") or "Unknown"
                        raw_msg = h.get("message") or ""
                        raw_range = str(h.get("range", "")).replace("X", "")
                        
                        if raw_range and is_new_hit:
                            detected_sid = detect_service(raw_msg, raw_sid)
                            app_info = PREMIUM_APPS.get(detected_sid, PREMIUM_APPS["Other"])
                            emoji_id, normal_emoji = app_info["id"], app_info["emoji"]
                            
                            if detected_sid not in voltx_dynamic_data:
                                voltx_dynamic_data[detected_sid] = {"emoji_id": emoji_id, "normal_emoji": normal_emoji, "ranges": {}}
                            if raw_range not in voltx_dynamic_data[detected_sid]["ranges"]:
                                voltx_dynamic_data[detected_sid]["ranges"][raw_range] = {"last_seen": current_time, "hits": 0, "times": []}
                            _rd = voltx_dynamic_data[detected_sid]["ranges"][raw_range]
                            _rd.setdefault("times", [])
                            _rd["times"].append(current_time)
                            _rd["last_seen"] = current_time
                            _rd["hits"] = len(_rd["times"])

                fifteen_mins_ago = current_time - 900
                for h in recent_traffic:
                    if h.get('local_receive_time', 0) >= fifteen_mins_ago:
                        sig = f"{h.get('time', 0)}_{h.get('range', '')}"
                        if sig not in seen_signatures:
                            new_traffic.append(h)
                            seen_signatures.add(sig)
                        
                new_traffic.sort(key=lambda x: x.get('local_receive_time', 0), reverse=True)
                recent_traffic = new_traffic

                services_to_delete = []
                for sid, s_data in voltx_dynamic_data.items():
                    ranges_to_delete = []
                    for r, r_data in s_data["ranges"].items():
                        # hits = only the SMS seen in the last 5 minutes (old traffic fades out)
                        if "times" in r_data:
                            r_data["times"] = [t for t in r_data["times"] if current_time - t <= 300]
                            r_data["hits"] = len(r_data["times"])
                        if current_time - r_data["last_seen"] > 300 or r_data.get("hits", 0) <= 0: ranges_to_delete.append(r)
                    for r in ranges_to_delete: del s_data["ranges"][r]
                    if not s_data["ranges"]: services_to_delete.append(sid)
                for sid in services_to_delete: del voltx_dynamic_data[sid]

                cycle_count += 1
                if cycle_count % 3 == 0: save_local_data()

        except Exception: pass
        time.sleep(10)

# ==========================================
# Shared OTP Processor (Voltx + Zenex both use this)
# ==========================================
manual_traffic = []
def record_manual_traffic(num, text, service):
    """Manual panels (AugesTel / LAMIX) have no public feed, so their OTPs count as LIVE TRAFFIC here."""
    global manual_traffic
    now = int(time.time())
    manual_traffic.append({"sid": service, "message": text, "range": str(num).lstrip("+"), "time": now, "local_receive_time": now})
    manual_traffic = [h for h in manual_traffic if now - h.get("local_receive_time", 0) <= 900][-300:]

def process_incoming_otp(raw_number, msg_text, raw_service="Unknown", sig=None, traffic=False):
    """Forward one OTP to groups, then credit the user who owns the number (if any)."""
    global recent_success_otps, user_active_sessions, daily_user_otps
    raw_number = str(raw_number or "").strip()
    msg_text = str(msg_text or "").strip()
    if not msg_text or not raw_number: return

    sig = sig or f"{raw_number}_{msg_text}"
    detected_service = detect_service(msg_text, raw_service)

    with otp_process_lock:
        send_to_groups = sig not in group_sent_otps
        if send_to_groups: group_sent_otps.add(sig)
        is_new = sig not in recent_success_otps
        if is_new: recent_success_otps.add(sig)
    if is_new and traffic:
        record_manual_traffic(raw_number, msg_text, detected_service)

    # 1. Forward to Groups
    if send_to_groups and otp_forward_groups:
        formatted_message, markup = generate_otp_display(detected_service, raw_number, msg_text)
        send_otp_to_groups(formatted_message, markup)

    # 2. Check Inbox Ownership
    if is_new:
        owner_id = None
        clean_number = raw_number.lstrip("+")
        last_8_digits = clean_number[-8:] if len(clean_number) > 8 else clean_number
        for active_num, uid in list(user_active_sessions.items()):
            if str(active_num).lstrip("+").endswith(last_8_digits):
                owner_id = uid
                user_active_sessions.pop(active_num, None)
                break

        if owner_id:
            reward = get_otp_reward(detected_service)
            update_user_stats(owner_id, reward, 0)
            user_balance = get_user(owner_id).get("balance", 0.0)
            deliver_to_inbox(owner_id, detected_service, clean_number, msg_text, user_balance, reward)
            web_sync.log_otp(owner_id, detected_service, clean_number, extract_otp_code(msg_text), reward)

            today_date = time.strftime("%Y-%m-%d")
            if daily_user_otps.get("date") != today_date:
                daily_user_otps["date"] = today_date
                daily_user_otps["users"] = {}
            uid_str = str(owner_id)
            daily_user_otps["users"][uid_str] = daily_user_otps["users"].get(uid_str, 0) + 1

        update_daily_stat("otps", 1)
        save_local_data()
        time.sleep(1)

def trim_otp_sets():
    global recent_success_otps, group_sent_otps
    if len(recent_success_otps) > 2000:
        recent_success_otps = set(list(recent_success_otps)[-1000:])
        save_local_data()
    if len(group_sent_otps) > 2000:
        group_sent_otps = set(list(group_sent_otps)[-1000:])

# ==========================================
# Voltx SMS Listener (same logic as before, now uses the shared processor)
# ==========================================
def voltx_sms_listener():
    while True:
        if not voltx_active():
            time.sleep(10)
            continue
        try:
            headers = {"mauthapi": get_api_key(), "Content-Type": "application/json"}
            res = requests.get(f"{API_2OO9_BASE}/success-otp", headers=headers, timeout=15)

            if res.status_code == 200:
                data = res.json()
                otps = []

                if isinstance(data, dict):
                    if "data" in data and isinstance(data["data"], list):
                        otps = data["data"]
                    elif "data" in data and isinstance(data["data"], dict):
                        if "otps" in data["data"]:
                            otps = data["data"]["otps"]
                        elif "hits" in data["data"]:
                            otps = data["data"]["hits"]
                    elif "otps" in data:
                        otps = data["otps"]
                    elif "hits" in data:
                        otps = data["hits"]
                elif isinstance(data, list):
                    otps = data

                for otp_data in reversed(otps):
                    msg_text = str(otp_data.get("message", otp_data.get("sms", otp_data.get("code", ""))))
                    raw_number = str(otp_data.get("number", otp_data.get("phone", "")))
                    raw_service = str(otp_data.get("sid", otp_data.get("service", "Unknown")))
                    process_incoming_otp(raw_number, msg_text, raw_service)

            trim_otp_sets()
        except Exception:
            pass
        time.sleep(10)

# ==========================================
# ZENEX Core API (new panel)  -  header: mapikey
# ==========================================
def zenex_range_payload(rid):
    """Zenex wants a pattern like 4473845XXX. Our internal ranges are stored without X."""
    rid = str(rid or "").strip().upper()
    return rid if "X" in rid else rid + "XXX"

def fetch_zenex_number(rid):
    """POST /v1/getnum  ->  returns dict with full_number / country / operator (same shape as Voltx)."""
    key = get_zenex_key()
    if not key: return None
    headers = {"mapikey": key, "Content-Type": "application/json"}
    payload = {"range": zenex_range_payload(rid), "is_national": False, "remove_plus": False}
    try:
        res = requests.post(f"{ZENEX_CORE_BASE}/v1/getnum", headers=headers, json=payload, timeout=15)
        data = res.json()
        if data.get("meta", {}).get("code") == 200:
            d = data.get("data", {}) or {}
            if not d.get("full_number") and d.get("number"):
                d["full_number"] = str(d["number"]).lstrip("+")
            return d if d.get("full_number") else None
        print(f"[Zenex] getnum failed ({rid}): {str(data)[:200]}")
    except Exception as e:
        print(f"[Zenex] getnum error: {e}")
    return None

def fetch_number_from_panel(panel, rid):
    if panel == "zenex": return fetch_zenex_number(rid)
    return fetch_live_number(rid)

def zenex_ranges_listener():
    """GET /v1/active-ranges (60s cached on their side) -> poll every 2 minutes."""
    global zenex_dynamic_data
    while True:
        if not zenex_active():
            time.sleep(15)
            continue
        try:
            res = requests.get(f"{ZENEX_CORE_BASE}/v1/active-ranges", headers={"mapikey": get_zenex_key()}, timeout=15)
            data = res.json()
            if data.get("success"):
                items = (data.get("data") or {}).get("active_ranges", []) or []
                now = int(time.time())
                new_data = {}
                for item in items:
                    raw_range = str(item.get("range", "")).upper().replace("X", "")
                    if not raw_range.isdigit(): continue
                    sid = detect_service("", str(item.get("service", "")))
                    app_info = PREMIUM_APPS.get(sid, PREMIUM_APPS["Other"])
                    entry = new_data.setdefault(sid, {"emoji_id": app_info["id"], "normal_emoji": app_info["emoji"], "ranges": {}})
                    r = entry["ranges"].setdefault(raw_range, {"last_seen": now, "hits": 0})
                    try: r["hits"] += max(int(item.get("hits", 1)), 1)
                    except Exception: r["hits"] += 1
                zenex_dynamic_data = new_data
        except Exception as e:
            print(f"[Zenex] active-ranges error: {e}")
        time.sleep(120)

def zenex_console_listener():
    """GET /v1/global-broadcast (public live feed, 10s cache) -> feeds LIVE TRAFFIC."""
    global zenex_traffic
    seen_ids = set()
    while True:
        if not zenex_active():
            time.sleep(15)
            continue
        try:
            res = requests.get(f"{ZENEX_WEB_BASE}/api/v1/global-broadcast", timeout=10)
            data = res.json()
            if data.get("success"):
                now = int(time.time())
                for item in (data.get("data") or []):
                    uid = str(item.get("id") or f"{item.get('time')}_{item.get('number')}")
                    if uid in seen_ids: continue
                    seen_ids.add(uid)
                    zenex_traffic.append({
                        "sid": item.get("service", "Unknown"),
                        "message": item.get("otp", ""),
                        "range": str(item.get("number", "")),
                        "time": item.get("time", now),
                        "local_receive_time": now
                    })
                cutoff = now - 900
                zenex_traffic = [h for h in zenex_traffic if h.get("local_receive_time", 0) >= cutoff][-300:]
                if len(seen_ids) > 2000: seen_ids = set(list(seen_ids)[-1000:])
        except Exception as e:
            print(f"[Zenex] global-broadcast error: {e}")
        time.sleep(8)

def zenex_sms_listener():
    """GET /v1/numsuccess/info -> poll every ~4s. Each key owns its own numbers, so every key is polled."""
    while True:
        if not zenex_active():
            time.sleep(10)
            continue
        try:
            for key in list(zenex_keys):
                try:
                    res = requests.get(f"{ZENEX_CORE_BASE}/v1/numsuccess/info", headers={"mapikey": key}, timeout=15)
                    if res.status_code != 200: continue
                    data = res.json()
                    otps = ((data.get("data") or {}).get("otps") or []) if isinstance(data, dict) else []
                    for o in reversed(otps):
                        raw_number = str(o.get("number", ""))
                        msg_text = str(o.get("otp", ""))
                        # nid is unique per OTP (_0, _1 ...) so Resend OTPs are processed too
                        sig = f"zx_{o.get('nid')}" if o.get("nid") else f"zx_{raw_number}_{msg_text}"
                        process_incoming_otp(raw_number, msg_text, "Unknown", sig=sig)
                except Exception as e:
                    print(f"[Zenex] numsuccess error: {e}")
            trim_otp_sets()
        except Exception:
            pass
        time.sleep(4)

# ==========================================
# AugesTel IPRN API (messages = OTP source for manual numbers)
# ==========================================
def augestel_request(path, params=None):
    """Returns (json, error_text). Limits: 5 req/min per key."""
    if not augestel_key: return None, "API key not set"
    headers = {"Authorization": f"Bearer {augestel_key}", "Accept": "application/json"}
    try:
        res = requests.get(f"{AUGESTEL_BASE}/{path}", headers=headers, params=params, timeout=20)
        if res.status_code == 200: return res.json(), None
        if res.status_code == 429: return None, f"Rate limit - retry after {res.headers.get('Retry-After', '?')}s"
        try: err = res.json().get("error", {}).get("message", res.text[:120])
        except Exception: err = res.text[:120]
        return None, f"HTTP {res.status_code}: {err}"
    except Exception as e:
        return None, str(e)

def augestel_fetch_numbers(force=False):
    """All numbers assigned to the account (/numbers, paginated, max 3 pages per call, cached 2 min).
    Returns (list_of_{number,range_name}, error_or_None)."""
    if not force and augestel_cache["numbers"] and time.time() - augestel_cache["t"] < 120:
        return augestel_cache["numbers"], None
    out, page, err = [], 1, None
    while page <= 3:
        d, err = augestel_request("numbers", {"page": page, "per_page": 100})
        if err or not d or not d.get("success"):
            err = err or "bad response"; break
        for n in d.get("data") or []:
            num = normalize_number(n.get("number"))
            if num: out.append({"number": num, "range_name": str(n.get("range_name") or "Unknown")})
        if page >= int((d.get("pagination") or {}).get("last_page", 1)): err = None; break
        page += 1
    if out:
        augestel_cache["numbers"], augestel_cache["t"] = out, time.time()
        return out, (err if err else None)
    return augestel_cache["numbers"], err

def augestel_groups(numbers):
    g = {}
    for n in numbers: g.setdefault(n["range_name"], []).append(n["number"])
    return g

def augestel_sync_ranges(groups):
    """Push ON ranges into the manual pool (under their service), pull OFF/unassigned ranges out.
    Numbers already given to users (manual_used) are never added again."""
    with manual_lock:
        for rname, nums in groups.items():
            meta = augestel_range_meta.get(rname)
            nset = set(nums)
            for svc, countries in manual_stock.items():          # remove this range's unused numbers everywhere
                for c in countries.values():
                    c["numbers"] = [x for x in c["numbers"] if x not in nset]
            if not meta or not meta.get("enabled") or not meta.get("service"): continue
            svc = meta["service"]
            for num in nums:
                if num in manual_used: continue
                code, cname = get_country_info(num)
                c = manual_stock.setdefault(svc, {}).setdefault(code, {"name": cname, "numbers": []})
                c["numbers"].append(num)
        for svc in list(manual_stock.keys()):                    # drop empty AugesTel-created services? keep admin ones
            pass
        save_manual_data()

def augestel_range_sync_loop():
    """Every 10 min pick up newly assigned numbers of ON ranges."""
    while True:
        time.sleep(600)
        try:
            if augestel_enabled and augestel_key and any(m.get("enabled") for m in augestel_range_meta.values()):
                nums, err = augestel_fetch_numbers(force=True)
                if nums: augestel_sync_ranges(augestel_groups(nums))
        except Exception as e:
            print(f"[AugesTel] range sync error: {e}")

def augestel_sms_listener():
    """Poll /messages every 20s (3 req/min, leaves room for admin info buttons)."""
    seen = set()
    first_run = True
    while True:
        wait = 20
        if augestel_enabled and augestel_key:
            try:
                today = time.strftime("%Y-%m-%d", time.gmtime())
                yesterday = time.strftime("%Y-%m-%d", time.gmtime(time.time() - 86400))
                data, err = augestel_request("messages", {"start_date": yesterday, "end_date": today, "per_page": 100, "page": 1})
                if data and data.get("success"):
                    for m in reversed(data.get("data") or []):
                        num = str(m.get("number", ""))
                        text = str(m.get("message", ""))
                        sig = f"ag_{num}_{m.get('received_at', '')}_{text}"
                        if sig in seen: continue
                        seen.add(sig)
                        if first_run: continue                  # old messages at startup: just mark as seen
                        if extract_otp_code(text) == "COPY": continue   # skip promo SMS without a code
                        process_incoming_otp(num, text, str(m.get("source", "Unknown")), sig=sig, traffic=True)
                    first_run = False
                    if len(seen) > 3000: seen = set(list(seen)[-1500:])
                elif err and "Rate limit" in err:
                    wait = 60
            except Exception as e:
                print(f"[AugesTel] listener error: {e}")
        time.sleep(wait)

# ==========================================
# LAMIX SMS REST API (messages = OTP source, numbers = manual pool source)
# Auth: Authorization: Bearer <token> | Times: UTC ISO 8601 | Limit: 1/sec & 40/min PER ENDPOINT
# ==========================================
def lamix_iso(ts):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))

def lamix_request(path, params=None):
    """Returns (json, error_text). Waits 1.1s between calls to the same endpoint and
    reports 429 with the Retry-After value (error text starts with 'Rate limit')."""
    if not lamix_key: return None, "API key not set"
    with lamix_call_lock:
        gap = time.monotonic() - lamix_last_call.get(path, 0)
        if gap < 1.1: time.sleep(1.1 - gap)
        lamix_last_call[path] = time.monotonic()
    headers = {"Authorization": f"Bearer {lamix_key}", "Accept": "application/json"}
    try:
        res = requests.get(f"{LAMIX_BASE}/api/v1/{path}", headers=headers, params=params, timeout=20)
        if res.status_code == 200: return res.json(), None
        if res.status_code == 429:
            retry = res.headers.get("Retry-After")
            if not retry:
                try: retry = res.json().get("retryAfterSeconds")
                except Exception: retry = None
            return None, f"Rate limit - retry after {retry or 30}s"
        try: code = res.json().get("error", res.text[:120])
        except Exception: code = res.text[:120]
        return None, f"HTTP {res.status_code}: {code}"
    except Exception as e:
        return None, str(e)

def lamix_retry_after(err, default=30):
    m = re.search(r"retry after (\d+)s", str(err or ""))
    return int(m.group(1)) if m else default

def lamix_fetch_numbers(force=False, max_pages=40):
    """All numbers on the account (/numbers, keyset paginated: after=nextCursor, limit 500, cached 2 min).
    Returns (list_of_{number,range_name}, error_or_None)."""
    if not force and lamix_cache["numbers"] and time.time() - lamix_cache["t"] < 120:
        return lamix_cache["numbers"], None
    out, after, err, pages = [], None, None, 0
    while pages < max_pages:
        params = {"limit": 500}
        if after: params["after"] = after
        d, err = lamix_request("numbers", params)
        if err or not isinstance(d, dict):
            err = err or "bad response"
            if "Rate limit" in err:                      # wait once and continue the same page
                time.sleep(min(lamix_retry_after(err), 60))
                d, err = lamix_request("numbers", params)
                if err or not isinstance(d, dict): break
            else:
                break
        for n in d.get("records") or []:
            num = normalize_number(n.get("number"))
            if num: out.append({"number": num, "range_name": str(n.get("range") or "Unknown")})
        pages += 1
        after = d.get("nextCursor")
        if not after: err = None; break                  # null nextCursor = last page
    if out:
        lamix_cache["numbers"], lamix_cache["t"] = out, time.time()
        return out, (err if err else None)
    return lamix_cache["numbers"], err

def lamix_groups(numbers):
    g = {}
    for n in numbers: g.setdefault(n["range_name"], []).append(n["number"])
    return g

def lamix_sync_ranges(groups):
    """Push ON ranges into the manual pool (under their service), pull OFF/unassigned ranges out.
    Numbers already given to users (manual_used) are never added again."""
    with manual_lock:
        for rname, nums in groups.items():
            meta = lamix_range_meta.get(rname)
            nset = set(nums)
            for svc, countries in manual_stock.items():
                for c in countries.values():
                    c["numbers"] = [x for x in c["numbers"] if x not in nset]
            if not meta or not meta.get("enabled") or not meta.get("service"): continue
            svc = meta["service"]
            for num in nums:
                if num in manual_used: continue
                code, cname = get_country_info(num)
                c = manual_stock.setdefault(svc, {}).setdefault(code, {"name": cname, "numbers": []})
                c["numbers"].append(num)
        save_manual_data()

def lamix_range_sync_loop():
    """Every 10 min pick up newly added numbers of ON ranges."""
    while True:
        time.sleep(600)
        try:
            if lamix_enabled and lamix_key and any(m.get("enabled") for m in lamix_range_meta.values()):
                nums, err = lamix_fetch_numbers(force=True)
                if nums: lamix_sync_ranges(lamix_groups(nums))
        except Exception as e:
            print(f"[LAMIX] range sync error: {e}")

def lamix_sms_listener():
    """Poll /messages every 6s (10/min, far below 40/min). Each OTP is forwarded to the OTP groups
    and to the bot user who currently holds that number (process_incoming_otp does both)."""
    seen = set()
    first_run = True
    while True:
        wait = 6
        if lamix_enabled and lamix_key:
            try:
                params = {"from": lamix_iso(time.time() - 900), "limit": 200}
                data, err = lamix_request("messages", params)
                if isinstance(data, dict):
                    for m in reversed(data.get("records") or []):           # API is newest-first
                        num = str(m.get("number", ""))
                        text = str(m.get("content", ""))
                        sig = f"lx_{num}_{m.get('time', '')}_{text}"
                        if sig in seen: continue
                        seen.add(sig)
                        if first_run: continue                              # old messages at startup: only mark as seen
                        if extract_otp_code(text) == "COPY": continue       # skip promo SMS without a code
                        process_incoming_otp(num, text, str(m.get("cli", "Unknown")), sig=sig, traffic=True)
                    first_run = False
                    if len(seen) > 3000: seen = set(list(seen)[-1500:])
                elif err:
                    if "Rate limit" in err: wait = lamix_retry_after(err)
                    elif "401" in err or "403" in err: wait = 60            # bad token / Extended API off
                    else: wait = 15
            except Exception as e:
                print(f"[LAMIX] listener error: {e}")
        time.sleep(wait)

# ==========================================
# 📬 TEMP MAIL  (mail.tm - free, no API key, unlimited inboxes)
# ==========================================
TM_BASE = "https://api.mail.tm"
TM_FILE = "temp_mail.json"
TM_MAIL_TTL = 24 * 3600          # a mailbox is dropped from polling after 24h
TM_POLL_SECONDS = 7              # background inbox check interval (5-10s)
tm_lock = threading.Lock()
tm_active = {}       # {uid(str): {"address","password","token","account_id","created","seen":[ids]}}
tm_users = {}        # {uid(str): {"count": n, "locked_until": ts}}   (cooldown state)
tm_states = {}       # {uid: {"domain": str, "msg_id": int}}  waiting for a custom username
tm_domain_cache = {"domains": [], "ts": 0}   # mail.tm domain list (shared, no key needed)
tm_last_refresh = {} # {uid: ts} (anti-spam for the Refresh button)

def tm_save():
    try:
        with tm_lock:
            data = {"active": tm_active, "users": tm_users}
            with open(TM_FILE, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        print(f"[TempMail] save error: {e}")

def tm_load():
    global tm_active, tm_users
    if not os.path.exists(TM_FILE): return
    try:
        with open(TM_FILE, "r", encoding="utf-8") as f: d = json.load(f)
        raw = d.get("active", {}); tm_users = d.get("users", {})
        tm_active = {u: r for u, r in raw.items() if isinstance(r, dict) and r.get("provider") == "mailtm" and r.get("account_id")}
        dropped = len(raw) - len(tm_active)
        if dropped: print(f"[TempMail] dropped {dropped} stale mailbox record(s) from the old provider")
    except Exception as e:
        print(f"[TempMail] load error: {e}")

def tm_ready():
    return bool(bot_settings.get("tm_enabled", True))   # mail.tm needs no API key

def tm_request(method, path, headers=None, params=None, body=None):
    """Plain call to api.mail.tm. Returns (json, error_text)."""
    hdrs = {"Content-Type": "application/json", "Accept": "application/ld+json"}
    if headers: hdrs.update(headers)
    try:
        res = requests.request(method, f"{TM_BASE}{path}", headers=hdrs, params=params, json=body, timeout=20)
        try: d = res.json()
        except Exception: d = None
        print(f"[TempMail] {method} {path} -> {res.status_code} {str(d)[:200]}")   # 🔎 remove once confirmed working
        if res.status_code == 429: return None, f"Rate limit - retry after {res.headers.get('Retry-After', '?')}s"
        if res.status_code >= 400:
            msg = ""
            if isinstance(d, dict): msg = d.get("message") or d.get("detail") or d.get("hydra:description") or ""
            return None, f"HTTP {res.status_code}: {msg or (res.text[:150] if res.text else 'error')}"
        return d, None
    except Exception as e:
        return None, str(e)

# ---------- cooldown: "batch" mails, then "cooldown_min" minutes wait, then again ----------
def tm_check_limit(uid):
    """Returns (ok, wait_seconds). Does not change anything except resetting an expired round."""
    batch = max(1, int(bot_settings.get("tm_batch", 4)))
    cd = max(0, float(bot_settings.get("tm_cooldown_min", 5))) * 60
    now = time.time()
    with tm_lock:
        rec = tm_users.setdefault(str(uid), {"count": 0, "locked_until": 0})
        if rec["locked_until"] and rec["locked_until"] <= now:
            rec["count"] = 0; rec["locked_until"] = 0                    # cooldown over -> new round
        if rec["count"] >= batch and not rec["locked_until"]:            # admin lowered the batch size
            rec["locked_until"] = now + cd
        if rec["locked_until"] > now: return False, int(rec["locked_until"] - now) + 1
    return True, 0

def tm_register_use(uid):
    batch = max(1, int(bot_settings.get("tm_batch", 4)))
    cd = max(0, float(bot_settings.get("tm_cooldown_min", 5))) * 60
    with tm_lock:
        rec = tm_users.setdefault(str(uid), {"count": 0, "locked_until": 0})
        rec["count"] += 1
        if rec["count"] >= batch: rec["locked_until"] = time.time() + cd
    tm_save()

def tm_left(uid):
    batch = max(1, int(bot_settings.get("tm_batch", 4)))
    with tm_lock:
        rec = tm_users.get(str(uid), {"count": 0, "locked_until": 0})
        if rec.get("locked_until", 0) > time.time(): return 0
        return max(0, batch - (rec.get("count", 0) if not rec.get("locked_until") else 0))

def tm_fmt_wait(sec):
    sec = int(sec); m, s = divmod(sec, 60)
    return f"{m}m {s:02d}s" if m else f"{s}s"

# ---------- mail.tm wrappers ----------
def tm_get_domains(force=False):
    """mail.tm domains are public (no key). Cached for 10 minutes."""
    if not force and tm_domain_cache["domains"] and time.time() - tm_domain_cache["ts"] < 600:
        return tm_domain_cache["domains"], None
    d, err = tm_request("GET", "/domains", params={"page": 1})
    if err: return [], err
    items = d.get("hydra:member") if isinstance(d, dict) else (d if isinstance(d, list) else None)
    out = []
    for it in items or []:
        if isinstance(it, dict) and it.get("isActive", True) and not it.get("isPrivate", False):
            dm = it.get("domain")
            if dm: out.append(dm)
        elif isinstance(it, str):
            out.append(it)
    if out:
        tm_domain_cache["domains"] = out; tm_domain_cache["ts"] = time.time()
    return out, (None if out else "No domains available")

def tm_random_username():
    return "u" + "".join(random.choices(string.ascii_lowercase + string.digits, k=10))

def tm_create(uid, username=None, domain=None):
    """Create a mail.tm account + login token for a user. Returns (True, rec) or (False, error_html)."""
    ok, wait = tm_check_limit(uid)
    if not ok:
        return False, f"⏳ <b>Limit reached.</b>\nTry again in <b>{tm_fmt_wait(wait)}</b>."
    domains, derr = tm_get_domains()
    if not domains:
        return False, f"❌ <b>Could not reach mail.tm.</b>\n<i>{html.escape(str(derr or 'no domains'))}</i>"
    dm = domain if (domain and domain in domains) else domains[0]
    uname = (username or tm_random_username()).strip().lower()
    address = f"{uname}@{dm}"
    password = "Pw" + "".join(random.choices(string.ascii_letters + string.digits, k=12)) + "!1"

    d, err = tm_request("POST", "/accounts", body={"address": address, "password": password})
    if err:
        if "exist" in err.lower() or "already" in err.lower() or "HTTP 422" in err:
            return False, "❌ <b>That username is taken, try another one.</b>"
        return False, f"❌ <b>Could not create mail.</b>\n<i>{html.escape(str(err))}</i>"

    t, terr = tm_request("POST", "/token", body={"address": address, "password": password})
    if terr or not isinstance(t, dict) or not t.get("token"):
        return False, f"❌ <b>Account created but login failed.</b>\n<i>{html.escape(str(terr or 'no token'))}</i>"

    # verify the fresh token really works before we hand this mailbox to the user
    me, merr = tm_request("GET", "/me", headers={"Authorization": f"Bearer {t['token']}"})
    if merr:
        return False, f"❌ <b>Mail created but token check failed.</b>\n<i>{html.escape(str(merr))}</i>\n<code>{html.escape(address)}</code>"
    print(f"[TempMail] OK new mailbox {address} id={t.get('id')} verified")
    rec = {"address": address, "password": password, "token": t["token"], "account_id": t.get("id", ""),
           "created": int(time.time()), "seen": [], "provider": "mailtm"}
    with tm_lock: prev = tm_active.get(str(uid)); tm_active[str(uid)] = rec
    if prev: tm_delete_account(prev)
    tm_register_use(uid)                      # only successful creations count
    tm_save()
    return True, rec

def tm_delete_account(rec):
    """DELETE /accounts/{id} so the mailbox really disappears at mail.tm (best effort)."""
    if not rec or not rec.get("account_id") or not rec.get("token"): return
    tm_request("DELETE", f"/accounts/{rec['account_id']}", headers={"Authorization": f"Bearer {rec['token']}"})

def tm_relogin(rec):
    """Token expired (401): log in again with the stored password.
    Returns "ok", "dead" (account does not exist / wrong credentials) or "error" (network etc.)."""
    t, err = tm_request("POST", "/token", body={"address": rec["address"], "password": rec.get("password", "")})
    if err:
        return "dead" if ("HTTP 401" in err or "HTTP 404" in err) else "error"
    if not isinstance(t, dict) or not t.get("token"): return "error"
    rec["token"] = t["token"]; tm_save()
    return "ok"

# ---------- message parsing / formatting ----------
def tm_pick(d, keys):
    for k in keys:
        v = d.get(k)
        if v not in (None, "", [], {}): return v
    return ""

def tm_clean_text(v):
    if isinstance(v, (list, tuple)): v = "\n".join(str(x) for x in v)
    v = str(v or "")
    v = re.sub(r"(?is)<(style|script).*?>.*?</\1>", " ", v)
    v = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>|</h\d>", "\n", v)
    v = re.sub(r"<[^>]+>", " ", v)
    v = html.unescape(v)
    v = re.sub(r"[ \t\r\f\v]+", " ", v)
    v = re.sub(r"\n\s*\n+", "\n\n", v)
    return v.strip()

def tm_sender(m):
    v = m.get("from")
    if isinstance(v, dict):
        addr = v.get("address") or ""
        name = v.get("name") or ""
        return f"{name} <{addr}>".strip() if name and addr else (addr or name or "Unknown")
    return str(v or "Unknown")

def tm_find_otp(*parts):
    """Prefer a number next to words like code/otp/verify; fall back to any 4-8 digit number (not a year)."""
    text = re.sub(r"https?://\S+", " ", " ".join(str(p or "") for p in parts))
    m = re.search(r"(?i)(?:code|otp|pin|passcode|verification|verify|confirm\w*)\D{0,25}?\b(\d{4,8})\b", text)
    if m: return m.group(1)
    m = re.search(r"(?i)\b(\d{4,8})\b\D{0,25}?(?:is your|is the)", text)
    if m: return m.group(1)
    for n in re.findall(r"\b\d{4,8}\b", text):
        if len(n) == 4 and re.fullmatch(r"(19|20)\d\d", n): continue     # looks like a year
        return n
    return None

def tm_format_message(m):
    sender = tm_sender(m)
    subject = str(tm_pick(m, ["subject"]) or "(no subject)")
    body = tm_clean_text(tm_pick(m, ["text", "html", "intro"]))
    otp = tm_find_otp(subject, body)
    shown = body if len(body) <= 2000 else body[:2000] + "…"
    txt = (f"📩 <b>New Email</b>\n━━━━━━━━━━━━━━━━━\n"
           f"👤 <b>From:</b> <code>{html.escape(sender)}</code>\n"
           f"📌 <b>Subject:</b> <code>{html.escape(subject[:200])}</code>\n\n"
           f"📄 {html.escape(shown) if shown else '<i>(empty message)</i>'}")
    markup = None
    if otp:
        txt += f"\n\n🔑 <b>OTP:</b> <code>{otp}</code>"
        markup = {"inline_keyboard": [[{"text": f"📋 Copy {otp}", "copy_text": {"text": otp}, "style": "success"}]]}
    return txt, markup, str(m.get("id") or "")

def tm_check_inbox(uid, rec, dead_after=3):
    """Fetch the inbox once and deliver every message not seen before. Returns (new_count, total, error)."""
    d, err = tm_request("GET", "/messages", headers={"Authorization": f"Bearer {rec['token']}"}, params={"page": 1})
    if err and "HTTP 401" in err:
        st = tm_relogin(rec)
        if st == "dead":
            rec["dead"] = int(rec.get("dead", 0)) + 1
            if rec["dead"] >= dead_after: return 0, 0, "DEAD"
            return 0, 0, "mail.tm login failed, will retry"
        if st == "ok":
            d, err = tm_request("GET", "/messages", headers={"Authorization": f"Bearer {rec['token']}"}, params={"page": 1})
    if err or not isinstance(d, dict): return 0, 0, err or "bad response"
    rec["dead"] = 0
    msgs = d.get("hydra:member")
    if not isinstance(msgs, list): msgs = d.get("messages") if isinstance(d.get("messages"), list) else []
    new = 0
    for m in msgs:
        if not isinstance(m, dict): continue
        # list items only have "intro", not full "text"/"html" - fetch the full message for a proper body
        mid = str(m.get("id") or "")
        with tm_lock:
            if not mid or mid in rec["seen"]: continue
            rec["seen"].append(mid)
            if len(rec["seen"]) > 300: del rec["seen"][:100]
        full, ferr = tm_request("GET", f"/messages/{mid}", headers={"Authorization": f"Bearer {rec['token']}"})
        txt, markup, _ = tm_format_message(full if isinstance(full, dict) and not ferr else m)
        send_message(int(uid), txt, reply_markup=markup)
        new += 1
    if new: tm_save()
    return new, len(msgs), None

def tm_poll_loop():
    """Background task: every few seconds check each active mailbox."""
    while True:
        try:
            if tm_ready():
                with tm_lock: items = list(tm_active.items())
                now = time.time()
                for uid, rec in items:
                    if now - rec.get("created", now) > TM_MAIL_TTL:
                        with tm_lock: tm_active.pop(uid, None)
                        tm_save()
                        tm_delete_account(rec)
                        send_message(int(uid), f"⌛ <b>Your temp mail expired:</b> <code>{html.escape(rec['address'])}</code>")
                        continue
                    _, _, err = tm_check_inbox(uid, rec)
                    if err == "DEAD":
                        with tm_lock: tm_active.pop(uid, None)
                        tm_save()
                        send_message(int(uid), f"⚠️ <b>Your temp mail stopped working:</b> <code>{html.escape(rec['address'])}</code>\nThe mail provider removed this mailbox. Please create a new one from 📬 Get Temp Mail.")
                        continue
                    if err and "Rate limit" in err: time.sleep(10)
                    time.sleep(0.4)                     # be gentle with the API
        except Exception as e:
            print(f"[TempMail] poll error: {e}")
        time.sleep(TM_POLL_SECONDS)

# ---------- views ----------
def tm_menu_view_for(uid, note=""):
    left = tm_left(uid)
    ok, wait = tm_check_limit(uid)
    status = f"<b>{left}</b> / {int(bot_settings.get('tm_batch', 4))}" if ok else f"⏳ next in <b>{tm_fmt_wait(wait)}</b>"
    txt = (f"{note}📬 <b>TEMP MAIL</b>\n━━━━━━━━━━━━━━━━━\n"
           f"Get a temporary email address. Incoming emails and OTP codes are delivered here automatically.\n\n"
           f"🎟 Mails left: {status}")
    kb = {"inline_keyboard": [
        [{"text": "🎲 Random Mail", "callback_data": "tm_rand", "style": "success"},
         {"text": "✏️ Custom Mail", "callback_data": "tm_cust", "style": "primary"}],
        [{"text": "❌ Close", "callback_data": "close_panel", "style": "danger"}]]}
    return txt, kb

def tm_mail_view(uid, note=""):
    rec = tm_active.get(str(uid))
    if not rec: return tm_menu_view_for(uid, note)
    txt = (f"{note}📬 <b>YOUR TEMP MAIL</b>\n━━━━━━━━━━━━━━━━━\n"
           f"<code>{html.escape(rec['address'])}</code>\n\n"
           f"<i>Tap the address to copy. New emails arrive here automatically.</i>\n"
           f"📥 Received: <b>{len(rec.get('seen', []))}</b>")
    kb = {"inline_keyboard": [
        [{"text": "📋 Copy Address", "copy_text": {"text": rec["address"]}, "style": "success"}],
        [{"text": "🔄 Refresh Inbox", "callback_data": "tm_ref", "style": "primary"}],
        [{"text": "❌ Delete / Change Mail", "callback_data": "tm_del", "style": "danger"}]]}
    return txt, kb

def tm_domains_view(domains):
    txt = "✏️ <b>CUSTOM MAIL</b>\nChoose a domain:"
    kb = {"inline_keyboard": []}
    row = []
    for i, dm in enumerate(domains[:30]):
        row.append({"text": f"@{dm}", "callback_data": f"tm_dom_{i}", "style": "primary"})
        if len(row) == 2: kb["inline_keyboard"].append(row); row = []
    if row: kb["inline_keyboard"].append(row)
    kb["inline_keyboard"].append([{"text": "◀️ Back", "callback_data": "tm_menu", "style": "danger"}])
    return txt, kb

def tm_admin_view(note=""):
    en = bot_settings.get("tm_enabled", True)
    txt = (f"{note}📬 <b>TEMP MAIL SETTINGS</b>\n━━━━━━━━━━━━━━━━━\n"
           f"Provider: <b>mail.tm</b> (free, unlimited, no API key)\n"
           f"Status: <b>{'ON ✅' if en else 'OFF ❌'}</b>\n"
           f"Limit: <b>{int(bot_settings.get('tm_batch', 4))}</b> mails per round, then wait "
           f"<b>{bot_settings.get('tm_cooldown_min', 5)}</b> min\n"
           f"Active mailboxes: <b>{len(tm_active)}</b>")
    kb = {"inline_keyboard": [
        [{"text": "TEMP MAIL: ON" if en else "TEMP MAIL: OFF", "callback_data": "tma_tog", "style": "success" if en else "danger"}],
        [{"text": f"📦 Mails per round: {int(bot_settings.get('tm_batch', 4))}", "callback_data": "tma_batch", "style": "primary"},
         {"text": f"⏱ Cooldown: {bot_settings.get('tm_cooldown_min', 5)} min", "callback_data": "tma_cd", "style": "primary"}],
        [{"text": "📜 Active Mailboxes", "callback_data": "tma_hist", "style": "primary"}],
        [{"text": "Back", "callback_data": "back_to_admin", "style": "danger"}]]}
    return txt, kb

def tm_history_view():
    back = {"inline_keyboard": [[{"text": "Back", "callback_data": "tma_home", "style": "danger"}]]}
    lines = ["📜 <b>ACTIVE MAILBOXES</b> (latest 15)"]
    items = sorted(tm_active.items(), key=lambda kv: -kv[1].get("created", 0))[:15]
    for uid, rec in items:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(rec.get("created", 0)))
        lines.append(f"<code>{html.escape(rec['address'])}</code> (user {uid}) — {when}")
    if len(lines) == 1: lines.append("<i>No active mailboxes.</i>")
    return "\n".join(lines), back


# ==========================================
# Hybrid Database Initialization
# ==========================================
def init_sqlite():
    conn = sqlite3.connect("bot_database.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, first_name TEXT DEFAULT 'User', balance REAL DEFAULT 0.0, total_invites INTEGER DEFAULT 0)")
    try: cursor.execute("ALTER TABLE users ADD COLUMN first_name TEXT DEFAULT 'User'")
    except sqlite3.OperationalError: pass
    try: cursor.execute("ALTER TABLE users ADD COLUMN total_otps INTEGER DEFAULT 0")
    except sqlite3.OperationalError: pass
    conn.commit()
    conn.close()

def migrate_sqlite_to_firebase():
    global db_firebase, user_cache
    if not db_firebase: return
    try:
        conn = sqlite3.connect("bot_database.db")
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, first_name, balance, total_invites FROM users")
        rows = cursor.fetchall()
        if not rows: return conn.close()
        
        count = 0
        batch = db_firebase.batch()
        for row in rows:
            uid, fname, bal, inv = row
            doc_ref = db_firebase.collection('users').document(str(uid))
            batch.set(doc_ref, {"user_id": uid, "first_name": fname, "balance": firestore.Increment(bal), "total_invites": firestore.Increment(inv)}, merge=True)
            count += 1
            if count % 400 == 0:
                batch.commit()
                batch = db_firebase.batch()
        if count % 400 != 0: batch.commit()
        cursor.execute("DELETE FROM users")
        conn.commit()
        conn.close()
        user_cache.clear()
    except Exception as e: print(f"Migration Error: {e}")

def init_firebase_from_file():
    global voltx_enabled, zenex_keys, zenex_enabled
    global current_db_mode, db_firebase, bot_settings, force_join_status, force_join_channels, otp_forward_groups, otp_button_link, voltx_keys, voltx_auto_mode
    if os.path.exists("temp_firebase.json"):
        try:
            if not firebase_admin._apps: 
                firebase_admin.initialize_app(credentials.Certificate("temp_firebase.json"))
            db_firebase = firestore.client()
            current_db_mode = "firebase"
            print("✅ Firebase Auto-Connected on Startup!")
            
            doc = db_firebase.collection('settings').document('bot_config').get()
            if doc.exists:
                data = doc.to_dict()
                if "bot_settings" in data: bot_settings.update(data["bot_settings"])
                if "force_join_status" in data: force_join_status = data["force_join_status"]
                if "force_join_channels" in data: force_join_channels = data["force_join_channels"]
                if "otp_forward_groups" in data: otp_forward_groups = data["otp_forward_groups"]
                if "otp_button_link" in data: otp_button_link = data["otp_button_link"]
                if "voltx_keys" in data: voltx_keys = data["voltx_keys"]
                if "voltx_auto_mode" in data: voltx_auto_mode = data["voltx_auto_mode"]
                if "voltx_enabled" in data: voltx_enabled = data["voltx_enabled"]
                if "zenex_keys" in data: zenex_keys = data["zenex_keys"]
                if "zenex_enabled" in data: zenex_enabled = data["zenex_enabled"]
                print("✅ Settings synced from Firebase!")

            # 🌟 One-Time Sync on Startup (বট চালু হওয়ার সময় অটো সিঙ্ক)
            try:
                local_users = set()
                if os.path.exists(USERS_LIST_FILE):
                    with open(USERS_LIST_FILE, "r") as f:
                        local_users = set(json.load(f))
                
                docs = db_firebase.collection('users').select([]).stream()
                fb_users = set(int(doc.id) for doc in docs)
                
                combined_users = local_users.union(fb_users)
                if len(combined_users) > len(local_users):
                    with open(USERS_LIST_FILE, "w") as f:
                        json.dump(list(combined_users), f)
                    print(f"✅ Auto-Synced {len(fb_users)} users on Startup!")
            except Exception as e:
                print(f"Startup Sync Error: {e}")

        except Exception as e:
            print(f"❌ Firebase Auto-Connect Error: {e}")

def get_user(user_id):
    global current_db_mode, db_firebase, user_cache
    if user_id in user_cache: return user_cache[user_id]
    if current_db_mode == "firebase" and db_firebase:
        doc = db_firebase.collection('users').document(str(user_id)).get()
        if doc.exists:
            user_data = doc.to_dict()
            user_cache[user_id] = user_data 
            return user_data
        return None
    else: 
        conn = sqlite3.connect("bot_database.db")
        cursor = conn.cursor()
        cursor.execute("SELECT first_name, balance, total_invites FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        if row: 
            user_data = {"user_id": user_id, "first_name": row[0], "balance": row[1], "total_invites": row[2]}
            user_cache[user_id] = user_data 
            return user_data
        return None

def add_user(user_id, first_name="User"):
    global current_db_mode, db_firebase, user_cache
    add_to_broadcast_list(user_id) 
    if user_id in user_cache and user_cache[user_id]["first_name"] == first_name: return 
    
    if current_db_mode == "firebase" and db_firebase:
        doc_ref = db_firebase.collection('users').document(str(user_id))
        if not doc_ref.get().exists:
            new_data = {"user_id": user_id, "first_name": first_name, "balance": 0.0, "total_invites": 0}
            doc_ref.set(new_data)
            user_cache[user_id] = new_data
        else: 
            doc_ref.update({"first_name": first_name})
            if user_id in user_cache: user_cache[user_id]["first_name"] = first_name
    else: 
        conn = sqlite3.connect("bot_database.db")
        cursor = conn.cursor()
        cursor.execute("INSERT OR IGNORE INTO users (user_id, first_name, balance, total_invites) VALUES (?, ?, 0.0, 0)", (user_id, first_name))
        cursor.execute("UPDATE users SET first_name = ? WHERE user_id = ?", (first_name, user_id))
        conn.commit()
        conn.close()
        if user_id not in user_cache: user_cache[user_id] = {"user_id": user_id, "first_name": first_name, "balance": 0.0, "total_invites": 0}
        else: user_cache[user_id]["first_name"] = first_name

def update_user_stats(user_id, balance_add, invite_add):
    global current_db_mode, db_firebase, user_cache
    bal_add = float(balance_add)
    inv_add = int(invite_add)
    
    if user_id not in user_cache:
        get_user(user_id) # Ensure user is loaded
        
    if user_id in user_cache:
        user_cache[user_id]["balance"] = round(user_cache[user_id]["balance"] + bal_add, 2) # 🌟 Fix: Round balance
        user_cache[user_id]["total_invites"] += inv_add
        
    if current_db_mode == "firebase" and db_firebase:
        db_firebase.collection('users').document(str(user_id)).update({"balance": firestore.Increment(bal_add), "total_invites": firestore.Increment(inv_add)})
    else: 
        conn = sqlite3.connect("bot_database.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET balance = balance + ?, total_invites = total_invites + ? WHERE user_id = ?", (bal_add, inv_add, user_id))
        conn.commit()
        conn.close()

def get_total_users(): return len(get_all_user_ids()) 

def get_top_users(limit=5):
    global current_db_mode, db_firebase
    if current_db_mode == "firebase" and db_firebase:
        docs = db_firebase.collection('users').order_by('balance', direction=firestore.Query.DESCENDING).limit(limit).stream()
        return [(doc.to_dict().get("user_id"), doc.to_dict().get("first_name", "User"), doc.to_dict().get("balance")) for doc in docs]
    else:
        conn = sqlite3.connect("bot_database.db")
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, first_name, balance FROM users ORDER BY balance DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        conn.close()
        return rows

# ==========================================
# Sub-Menu Builders
# ==========================================
def get_otp_group_keyboard():
    kb = {"inline_keyboard": []}
    
    link_display = otp_button_link if otp_button_link else "Not Set"
    if len(link_display) > 25: link_display = link_display[:25] + "..."
    kb["inline_keyboard"].append([{"text": f"Link: {link_display}", "callback_data": "edit_otp_link", "icon_custom_emoji_id": "5420517437885943844", "style": "primary"}])
    
    mc_link = bot_settings.get("main_channel_link", "")
    mc_display = mc_link if mc_link else "Not Set"
    if len(mc_display) > 25: mc_display = mc_display[:25] + "..."
    kb["inline_keyboard"].append([{"text": f"Main Channel: {mc_display}", "callback_data": "edit_main_channel", "icon_custom_emoji_id": "5429353834881261942", "style": "primary"}])
    
    if otp_forward_groups:
        grp = otp_forward_groups[0]
        kb["inline_keyboard"].append([{"text": f"Delete Group: {grp}", "callback_data": "del_otp_group_0", "icon_custom_emoji_id": "5422557736330106570", "style": "danger"}])
        
    fmt_big = bot_settings.get("otp_format", "mini") == "big"
    kb["inline_keyboard"].append([{"text": "OTP FORMAT: BIG" if fmt_big else "OTP FORMAT: MINI", "callback_data": "toggle_otp_format", "icon_custom_emoji_id": "5352694861990501856" if fmt_big else "5420130255174145507", "style": "primary" if fmt_big else "danger"}])
    kb["inline_keyboard"].append([{"text": "SEND FAKE OTP", "callback_data": "send_fake_otp", "icon_custom_emoji_id": "5429167978761461870", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "Set Forward Group", "callback_data": "add_otp_group", "icon_custom_emoji_id": "5429501315468270290", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "BACK", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5267490665117275176", "style": "danger"}])
    return kb

def get_force_join_keyboard():
    kb = {"inline_keyboard": []}
    status_text = "STATUS: ON" if force_join_status else "STATUS: OFF"
    status_icon = "5352694861990501856" if force_join_status else "5420130255174145507"
    
    kb["inline_keyboard"].append([{"text": status_text, "callback_data": "toggle_fj", "icon_custom_emoji_id": status_icon, "style": "primary" if force_join_status else "danger"}])
    
    for idx, ch in enumerate(force_join_channels):
        name = ch.get("username", ch.get("title", f"Channel {idx}"))
        kb["inline_keyboard"].append([{"text": f"Delete: {name}", "callback_data": f"del_fj_{idx}", "icon_custom_emoji_id": "5438178416421544431", "style": "danger"}])
        
    kb["inline_keyboard"].append([{"text": "Add Channel", "callback_data": "add_fj", "icon_custom_emoji_id": "5429501315468270290", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "Back", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5438541186539232243", "style": "primary"}])
    return kb

def get_force_join_alert_keyboard():
    kb = {"inline_keyboard": []}
    for ch in force_join_channels:
        name = ch.get("title", ch.get("username", "Our Channel"))
        url = ch.get("invite_link", "")
        if not url and ch.get("username"): url = f"https://t.me/{ch['username'].replace('@', '')}"
        # 🌟 Join বাটনে প্রিমিয়াম লিংক ইমোজি
        kb["inline_keyboard"].append([{"text": f"JOIN {name}", "url": url, "icon_custom_emoji_id": "5420517437885943844", "style": "danger"}])
    
    # 🌟 Verify বাটনে প্রিমিয়াম টিকমার্ক ইমোজি
    kb["inline_keyboard"].append([{"text": "VERIFY", "callback_data": "check_fj_joined", "icon_custom_emoji_id": "5352694861990501856", "style": "success"}])
    return kb

def get_voltx_keys_keyboard():
    kb = {"inline_keyboard": []}
    status_text = "VOLTX AUTO: ON" if voltx_auto_mode else "VOLTX AUTO: OFF"
    status_icon = "5352694861990501856" if voltx_auto_mode else "5420130255174145507"
    
    kb["inline_keyboard"].append([{"text": status_text, "callback_data": "toggle_vk", "icon_custom_emoji_id": status_icon, "style": "primary" if voltx_auto_mode else "danger"}])
    
    kb["inline_keyboard"].append([{"text": "VOLTX PANEL: ON" if voltx_enabled else "VOLTX PANEL: OFF", "callback_data": "toggle_vx_enabled", "icon_custom_emoji_id": "5352694861990501856" if voltx_enabled else "5420130255174145507", "style": "primary" if voltx_enabled else "danger"}])

    for idx, key in enumerate(voltx_keys):
        masked_key = f"{key[:4]}...{key[-4:]}" if len(key) > 8 else key
        kb["inline_keyboard"].append([{"text": f"Delete: {masked_key}", "callback_data": f"del_vk_{idx}", "icon_custom_emoji_id": "5438178416421544431", "style": "danger"}])
        
    kb["inline_keyboard"].append([{"text": "Add Voltx Key", "callback_data": "add_vk", "icon_custom_emoji_id": "5429501315468270290", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "Back", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5438541186539232243", "style": "primary"}])
    return kb

def get_zenex_keys_keyboard():
    kb = {"inline_keyboard": []}
    on = zenex_enabled
    kb["inline_keyboard"].append([{"text": "ZENEX: ON" if on else "ZENEX: OFF", "callback_data": "toggle_zx", "icon_custom_emoji_id": "5352694861990501856" if on else "5420130255174145507", "style": "primary" if on else "danger"}])
    for idx, key in enumerate(zenex_keys):
        masked_key = f"{key[:4]}...{key[-4:]}" if len(key) > 8 else key
        kb["inline_keyboard"].append([{"text": f"Delete: {masked_key}", "callback_data": f"del_zk_{idx}", "icon_custom_emoji_id": "5438178416421544431", "style": "danger"}])
    kb["inline_keyboard"].append([{"text": "Add Zenex Key", "callback_data": "add_zk", "icon_custom_emoji_id": "5429501315468270290", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "Back", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5438541186539232243", "style": "primary"}])
    return kb

def _b(text, cb, style="primary"):
    return {"text": text, "callback_data": cb, "style": style}

def mn_home_view():
    txt = (f"📦 <b>MANUAL NUMBERS</b>\nServices: <b>{len(manual_stock)}</b> | In stock: <b>{manual_total_numbers()}</b>\n"
           f"AugesTel API: <b>{'ON ✅' if (augestel_enabled and augestel_key) else ('NO KEY ⚠️' if not augestel_key else 'OFF ❌')}</b>\n"
           f"LAMIX API: <b>{'ON ✅' if (lamix_enabled and lamix_key) else ('NO KEY ⚠️' if not lamix_key else 'OFF ❌')}</b>")
    kb = {"inline_keyboard": []}
    for i, (svc, countries) in enumerate(manual_stock.items()):
        n = sum(len(c["numbers"]) for c in countries.values())
        kb["inline_keyboard"].append([_b(f"{svc} ({n})", f"mn_s_{i}")])
    kb["inline_keyboard"].append([_b("➕ Add Service", "mn_adds", "success")])
    kb["inline_keyboard"].append([_b("🔌 AugesTel API", "mn_api", "primary")])
    kb["inline_keyboard"].append([_b("🛰 AugesTel Ranges", "mn_rgl", "success")])
    kb["inline_keyboard"].append([_b("🔌 LAMIX API", "lx_api", "primary")])
    kb["inline_keyboard"].append([_b("🛰 LAMIX Ranges", "lx_rgl", "success")])
    kb["inline_keyboard"].append([_b("Back", "back_to_admin", "danger")])
    return txt, kb

def mn_service_view(si):
    names = list(manual_stock.keys())
    if si >= len(names): return mn_home_view()
    svc = names[si]
    txt = f"📦 <b>{html.escape(svc)}</b>\nSelect a country or add a new one:"
    kb = {"inline_keyboard": []}
    for ci, (code, c) in enumerate(manual_stock[svc].items()):
        kb["inline_keyboard"].append([_b(f"{c['name']} +{code} ({len(c['numbers'])})", f"mn_c_{si}_{ci}")])
    kb["inline_keyboard"].append([_b("➕ Add Country", f"mn_addc_{si}", "success")])
    kb["inline_keyboard"].append([_b("🗑 Delete Service", f"mn_dels_{si}", "danger")])
    kb["inline_keyboard"].append([_b("Back", "mn_home", "primary")])
    return txt, kb

def mn_country_view(si, ci, note=""):
    names = list(manual_stock.keys())
    if si >= len(names): return mn_home_view()
    svc = names[si]
    codes = list(manual_stock[svc].keys())
    if ci >= len(codes): return mn_service_view(si)
    code = codes[ci]; c = manual_stock[svc][code]
    txt = (f"{note}📦 <b>{html.escape(svc)}</b> ➜ {html.escape(c['name'])} (+{code})\n"
           f"Numbers in stock: <b>{len(c['numbers'])}</b>")
    kb = {"inline_keyboard": [
        [_b("📥 Upload Numbers (.txt)", f"mn_up_{si}_{ci}", "success")],
        [_b("🧹 Clear Numbers", f"mn_clr_{si}_{ci}", "danger"), _b("🗑 Delete Country", f"mn_delc_{si}_{ci}", "danger")],
        [_b("Back", f"mn_s_{si}", "primary")]]}
    return txt, kb

def mn_api_view(note=""):
    masked = (augestel_key[:4] + "..." + augestel_key[-4:]) if len(augestel_key) > 8 else (augestel_key or "not set")
    txt = f"{note}🔌 <b>AUGESTEL API</b>\nKey: <code>{html.escape(masked)}</code>\nStatus: <b>{'ON ✅' if augestel_enabled else 'OFF ❌'}</b>\n<i>Limit: 5 requests/min - OTP polling uses 3/min.</i>"
    kb = {"inline_keyboard": [
        [_b("AUGESTEL: ON" if augestel_enabled else "AUGESTEL: OFF", "mn_tog", "primary" if augestel_enabled else "danger")],
        [_b("🔑 Set API Key", "mn_key", "success")],
        [_b("🛰 Ranges (assign / ON-OFF / .txt)", "mn_rgl", "success")],
        [_b("📱 My Numbers", "mn_nums"), _b("📊 Statistics", "mn_stats")],
        [_b("💬 Recent Messages", "mn_msgs")],
        [_b("Back", "mn_home", "danger")]]}
    return txt, kb

AG_SERVICES = [k for k in PREMIUM_APPS if k != "Other"]

def mn_ranges_view(note="", force=False):
    back = {"inline_keyboard": [[_b("Back", "mn_api", "danger")]]}
    nums, err = augestel_fetch_numbers(force=force)
    if not nums: return f"❌ <b>{html.escape(err or 'No numbers found on this account')}</b>", back
    groups = augestel_groups(nums)
    augestel_range_index[:] = sorted(groups.keys())
    augestel_sync_ranges(groups)
    txt = f"{note}🛰 <b>AUGESTEL RANGES</b>\nRanges: <b>{len(groups)}</b> | Numbers: <b>{len(nums)}</b>\nTap a range to assign a service / ON-OFF / export."
    if err: txt += f"\n<i>⚠️ Partial list: {html.escape(err)}</i>"
    kb = {"inline_keyboard": []}
    for i, r in enumerate(augestel_range_index):
        m = augestel_range_meta.get(r, {})
        state = (f"{m.get('service')} {'ON ✅' if m.get('enabled') else 'OFF ❌'}" if m.get("service") else "no service")
        kb["inline_keyboard"].append([_b(f"{r} ({len(groups[r])}) • {state}", f"mn_rg_{i}", "success" if m.get("enabled") else "primary")])
    kb["inline_keyboard"].append([_b("🔄 Refresh", "mn_rgr", "primary")])
    kb["inline_keyboard"].append([_b("Back", "mn_api", "danger")])
    return txt, kb

def mn_range_view(i, note=""):
    if i >= len(augestel_range_index): return mn_ranges_view()
    r = augestel_range_index[i]
    nums = augestel_groups(augestel_cache["numbers"]).get(r, [])
    m = augestel_range_meta.get(r, {})
    svc = m.get("service")
    in_pool = 0
    if svc:
        nset = set(nums)
        in_pool = sum(1 for c in manual_stock.get(svc, {}).values() for x in c["numbers"] if x in nset)
    txt = (f"{note}🛰 <b>{html.escape(r)}</b>\nNumbers: <b>{len(nums)}</b>\n"
           f"Service: <b>{html.escape(svc) if svc else 'not assigned'}</b>\n"
           f"Status: <b>{'ON ✅' if m.get('enabled') else 'OFF ❌'}</b> | Available to users: <b>{in_pool}</b>")
    kb = {"inline_keyboard": [
        [_b("📲 Assign / Change Service", f"mn_rgs_{i}", "success")],
        [_b("RANGE: ON" if m.get("enabled") else "RANGE: OFF", f"mn_rgt_{i}", "primary" if m.get("enabled") else "danger")],
        [_b("📄 Export .txt", f"mn_rgx_{i}", "primary")],
        [_b("Back", "mn_rgl", "danger")]]}
    return txt, kb

def mn_range_service_view(i):
    r = augestel_range_index[i] if i < len(augestel_range_index) else "?"
    kb = {"inline_keyboard": []}
    row = []
    for j, s in enumerate(AG_SERVICES):
        row.append(_b(s, f"mn_rgset_{i}_{j}"))
        if len(row) == 2: kb["inline_keyboard"].append(row); row = []
    if row: kb["inline_keyboard"].append(row)
    kb["inline_keyboard"].append([_b("Back", f"mn_rg_{i}", "danger")])
    return f"📲 <b>Select service for</b> {html.escape(r)}", kb

def mn_info_view(kind):
    back = {"inline_keyboard": [[_b("Back", "mn_api", "danger")]]}
    e = lambda v: html.escape(str(v))
    if kind == "nums":
        d, err = augestel_request("numbers", {"page": 1, "per_page": 10})
        if err or not d.get("success"): return f"❌ <b>{e(err or d)}</b>", back
        pg = d.get("pagination", {})
        lines = [f"📱 <b>MY NUMBERS</b> (total {e(pg.get('total', '?'))})"]
        for n in d.get("data", [])[:10]:
            lines.append(f"<code>{e(n.get('number'))}</code> | {e(n.get('range_name'))} | rate {e(n.get('a2p_rate'))} | last: {e(n.get('last_message_at') or '-')}")
        return "\n".join(lines), back
    if kind == "stats":
        d, err = augestel_request("statistics")
        if err or not d.get("success"): return f"❌ <b>{e(err or d)}</b>", back
        s = d.get("summary", {})
        lines = ["📊 <b>STATISTICS</b>",
                 f"Messages: <b>{e(s.get('total_messages'))}</b> (delivered {e(s.get('delivered'))}, failed {e(s.get('failed'))})",
                 f"A2P: {e(s.get('total_a2p_messages'))} | P2P: {e(s.get('total_p2p_messages'))}",
                 f"Earnings: <b>{e(s.get('total_earnings'))} {e(s.get('currency', ''))}</b> (A2P {e(s.get('a2p_earnings'))}, P2P {e(s.get('p2p_earnings'))})"]
        tops = d.get("top_numbers", [])[:5]
        if tops:
            lines.append("\n<b>Top numbers:</b>")
            for t in tops: lines.append(f"<code>{e(t.get('number'))}</code> | {e(t.get('messages'))} msgs | {e(t.get('earnings'))}")
        return "\n".join(lines), back
    d, err = augestel_request("messages", {"per_page": 10, "page": 1})
    if err or not d.get("success"): return f"❌ <b>{e(err or d)}</b>", back
    lines = ["💬 <b>RECENT MESSAGES</b>"]
    for m in d.get("data", [])[:10]:
        lines.append(f"<code>{e(m.get('number'))}</code> ← {e(m.get('source'))}\n{e(str(m.get('message'))[:80])}")
    return "\n".join(lines), back

def lx_api_view(note=""):
    masked = (lamix_key[:4] + "..." + lamix_key[-4:]) if len(lamix_key) > 8 else (lamix_key or "not set")
    txt = (f"{note}🔌 <b>LAMIX API</b>\nPanel: <code>{html.escape(LAMIX_BASE)}</code>\nToken: <code>{html.escape(masked)}</code>\n"
           f"Status: <b>{'ON ✅' if lamix_enabled else 'OFF ❌'}</b>\n"
           f"<i>Limit: 1 req/sec, 40/min per endpoint - OTP polling uses 10/min.</i>")
    kb = {"inline_keyboard": [
        [_b("LAMIX: ON" if lamix_enabled else "LAMIX: OFF", "lx_tog", "primary" if lamix_enabled else "danger")],
        [_b("🔑 Set API Token", "lx_key", "success")],
        [_b("🛰 Ranges (assign / ON-OFF / .txt)", "lx_rgl", "success")],
        [_b("📱 My Numbers", "lx_np_0"), _b("💬 Recent Messages", "lx_msgs")],
        [_b("Back", "mn_home", "danger")]]}
    return txt, kb

def lx_ranges_view(note="", force=False):
    back = {"inline_keyboard": [[_b("Back", "lx_api", "danger")]]}
    nums, err = lamix_fetch_numbers(force=force)
    if not nums: return f"❌ <b>{html.escape(err or 'No numbers found on this account')}</b>", back
    groups = lamix_groups(nums)
    lamix_range_index[:] = sorted(groups.keys())
    lamix_sync_ranges(groups)
    txt = f"{note}🛰 <b>LAMIX RANGES</b>\nRanges: <b>{len(groups)}</b> | Numbers: <b>{len(nums)}</b>\nTap a range to assign a service / ON-OFF / export."
    if err: txt += f"\n<i>⚠️ Partial list: {html.escape(err)}</i>"
    kb = {"inline_keyboard": []}
    for i, r in enumerate(lamix_range_index):
        m = lamix_range_meta.get(r, {})
        state = (f"{m.get('service')} {'ON ✅' if m.get('enabled') else 'OFF ❌'}" if m.get("service") else "no service")
        kb["inline_keyboard"].append([_b(f"{r} ({len(groups[r])}) • {state}", f"lx_rg_{i}", "success" if m.get("enabled") else "primary")])
    kb["inline_keyboard"].append([_b("🔄 Refresh", "lx_rgr", "primary")])
    kb["inline_keyboard"].append([_b("Back", "lx_api", "danger")])
    return txt, kb

def lx_range_view(i, note=""):
    if i >= len(lamix_range_index): return lx_ranges_view()
    r = lamix_range_index[i]
    nums = lamix_groups(lamix_cache["numbers"]).get(r, [])
    m = lamix_range_meta.get(r, {})
    svc = m.get("service")
    in_pool = 0
    if svc:
        nset = set(nums)
        in_pool = sum(1 for c in manual_stock.get(svc, {}).values() for x in c["numbers"] if x in nset)
    txt = (f"{note}🛰 <b>{html.escape(r)}</b>\nNumbers: <b>{len(nums)}</b>\n"
           f"Service: <b>{html.escape(svc) if svc else 'not assigned'}</b>\n"
           f"Status: <b>{'ON ✅' if m.get('enabled') else 'OFF ❌'}</b> | Available to users: <b>{in_pool}</b>")
    kb = {"inline_keyboard": [
        [_b("📲 Assign / Change Service", f"lx_rgs_{i}", "success")],
        [_b("RANGE: ON" if m.get("enabled") else "RANGE: OFF", f"lx_rgt_{i}", "primary" if m.get("enabled") else "danger")],
        [_b("📄 Export .txt", f"lx_rgx_{i}", "primary")],
        [_b("Back", "lx_rgl", "danger")]]}
    return txt, kb

def lx_range_service_view(i):
    r = lamix_range_index[i] if i < len(lamix_range_index) else "?"
    kb = {"inline_keyboard": []}
    row = []
    for j, s in enumerate(AG_SERVICES):
        row.append(_b(s, f"lx_rgset_{i}_{j}"))
        if len(row) == 2: kb["inline_keyboard"].append(row); row = []
    if row: kb["inline_keyboard"].append(row)
    kb["inline_keyboard"].append([_b("Back", f"lx_rg_{i}", "danger")])
    return f"📲 <b>Select service for</b> {html.escape(r)}", kb

def lx_numbers_view(page=0):
    """My Numbers: 10 per page, keyset pagination (after = previous nextCursor)."""
    back = {"inline_keyboard": [[_b("Back", "lx_api", "danger")]]}
    e = lambda v: html.escape(str(v))
    if page not in lamix_page_cursors: page = 0
    params = {"limit": 10}
    if lamix_page_cursors.get(page): params["after"] = lamix_page_cursors[page]
    d, err = lamix_request("numbers", params)
    if err or not isinstance(d, dict): return f"❌ <b>{e(err or 'bad response')}</b>", back
    lines = [f"📱 <b>MY NUMBERS</b> (page {page + 1})"]
    for n in d.get("records", []):
        lines.append(f"<code>{e(n.get('number'))}</code> | {e(n.get('range'))} | {e(n.get('status'))} | rate {e(n.get('payoutRate'))}")
    if len(lines) == 1: lines.append("<i>No numbers on this page.</i>")
    nxt = d.get("nextCursor")
    nav = []
    if page > 0: nav.append(_b("⬅️ Prev", f"lx_np_{page - 1}"))
    if nxt:
        lamix_page_cursors[page + 1] = nxt
        nav.append(_b("Next ➡️", f"lx_np_{page + 1}"))
    kb = {"inline_keyboard": ([nav] if nav else []) + back["inline_keyboard"]}
    return "\n".join(lines), kb

def lx_messages_view():
    back = {"inline_keyboard": [[_b("Back", "lx_api", "danger")]]}
    e = lambda v: html.escape(str(v))
    d, err = lamix_request("messages", {"limit": 10})
    if err or not isinstance(d, dict): return f"❌ <b>{e(err or 'bad response')}</b>", back
    lines = ["💬 <b>RECENT MESSAGES</b>"]
    for m in d.get("records", [])[:10]:
        lines.append(f"<code>{e(m.get('number'))}</code> ← {e(m.get('cli'))} ({e(m.get('status'))})\n{e(str(m.get('content'))[:80])}")
    return "\n".join(lines), back

def get_zenex_panel_text():
    status = "ACTIVE ✅" if zenex_active() else ("NO KEY ⚠️" if not zenex_keys else "OFF ❌")
    return f"🔑 <b>ZENEX KEY SYSTEM</b>\nStatus: <b>{status}</b>\nManage API Keys below:"

# ==========================================
# 🔐 2FA ONLINE SYSTEM (TOTP - stdlib only, no extra install needed)
# ==========================================
LINE_2FA = "━━━━━━━━━━━━━━━"
tool_states = {}   # {user_id: "2fa_key"}
twofa_keys = {}    # {user_id: secret}  (memory only, never saved to disk)

def parse_2fa_secret(raw):
    raw = str(raw or "").strip()
    m = re.search(r'secret=([A-Za-z2-7=\s-]+)', raw)   # otpauth:// link support
    if m: raw = m.group(1)
    return re.sub(r'[\s\-]', '', raw).upper()

def totp_now(secret, digits=6, period=30):
    s = parse_2fa_secret(secret)
    if not s: raise ValueError("empty key")
    s += "=" * (-len(s) % 8)
    key = base64.b32decode(s, casefold=True)
    now = time.time()
    counter = int(now // period)
    h = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    code = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return f"{code:0{digits}d}", period - int(now) % period

def twofa_menu_view():
    txt = (f"{LINE_2FA}\n《 🔐 <b>2FA ONLINE</b> 》\n{LINE_2FA}\n"
           f"<i>Generate your 2FA security code instantly using your secret key.</i>\n{LINE_2FA}")
    kb = {"inline_keyboard": [
        [{"text": "🛡 Generate 2fa code", "callback_data": "tfa_start", "style": "success"}],
        [{"text": "❌ Close", "callback_data": "close_panel", "style": "danger"}]
    ]}
    return txt, kb

def twofa_enter_key_view(error=""):
    txt = (f"{LINE_2FA}\n《 🔑 <b>ENTER 2FA KEY</b> 》\n{LINE_2FA}\n"
           f"📝 <b>SEND YOUR 2FA SECRET KEY</b>\n{LINE_2FA}")
    if error: txt += f"\n{error}"
    kb = {"inline_keyboard": [[{"text": "◀️ Cancel", "callback_data": "tfa_cancel", "style": "danger"}]]}
    return txt, kb

def twofa_code_view(secret):
    code, left = totp_now(secret)
    txt = (f"{LINE_2FA}\n《 🔐 <b>2FA CODE</b> 》\n{LINE_2FA}\n"
           f"🔐 <b>CODE:</b> <code>{code}</code>\n{LINE_2FA}\n"
           f"🕓 <b>EXPIRES IN:</b> {left}s\n{LINE_2FA}")
    kb = {"inline_keyboard": [
        [{"text": f"🛡 📋 Click to copy {code}", "copy_text": {"text": code}, "style": "success"}],
        [{"text": "⚙️ Refresh", "callback_data": "tfa_refresh", "style": "primary"},
         {"text": "👑 New Code", "callback_data": "tfa_new", "style": "danger"}],
        [{"text": "❌ Close", "callback_data": "close_panel", "style": "danger"}]
    ]}
    return txt, kb

def handle_2fa_key_input(chat_id, user_id, message_id, text):
    try:
        secret = parse_2fa_secret(text)
        totp_now(secret)
    except Exception:
        txt, kb = twofa_enter_key_view("⚠️ <b>Invalid key! Send a valid Base32 secret key.</b>")
        send_message(chat_id, txt, reply_markup=kb)
        return
    twofa_keys[user_id] = secret
    tool_states.pop(user_id, None)
    delete_message(chat_id, message_id)
    txt, kb = twofa_code_view(secret)
    send_message(chat_id, txt, reply_markup=kb)


def get_main_keyboard(user_id):
    keyboard_layout = [
        [
            {"text": "Get Number", "icon_custom_emoji_id": "5456259593082522998", "style": "danger"},
            {"text": "LIVE TRAFFIC", "icon_custom_emoji_id": "5429571662737611814", "style": "primary"}
        ],
        [
            {"text": "INVITE FRIEND", "icon_custom_emoji_id": "5384394344859974865", "style": "success"},
            {"text": "WALLET", "icon_custom_emoji_id": "5429105001655999635", "style": "danger"}
        ],
        [
            {"text": "LEADERBOARD", "icon_custom_emoji_id": "5240021484516185513", "style": "primary"}
        ],
        [
            {"text": "📬 Get Temp Mail", "style": "success"},
            {"text": "🔐 2FA Online", "style": "primary"}
        ]
    ]
    if user_id == ADMIN_ID:
        keyboard_layout.append([{"text": "OWNER PANEL", "icon_custom_emoji_id": "5429427051188756948", "style": "success"}])
    return {"keyboard": keyboard_layout, "resize_keyboard": True}

# ==========================================
# WELCOME MESSAGES (3 slots - admin panel theke set kora jay)
# ==========================================
def wm_slots():
    ws = bot_settings.get("welcome_msgs")
    if not isinstance(ws, list): ws = []
    ws = [dict(w) if isinstance(w, dict) else {} for w in ws][:3]
    while len(ws) < 3: ws.append({})
    for w in ws:
        w.setdefault("text", ""); w.setdefault("buttons", [])
    return ws

def build_welcome(slot, name):
    raw = str(slot.get("text", "")).strip() or DEFAULT_WELCOME_TEXT
    text = html.escape(raw).replace("{name}", html.escape(str(name)))
    rows = [[{"text": b["text"], "url": b["url"], "style": "primary"}] for b in slot.get("buttons", [])[:6]]
    return text, ({"inline_keyboard": rows} if rows else None)

def send_welcome(chat_id, user_id, first_name):
    ready = [s for s in wm_slots() if str(s.get("text", "")).strip()]
    slot = random.choice(ready) if ready else {"text": "", "buttons": []}
    text, inline = build_welcome(slot, first_name)
    if inline:
        send_message(chat_id, text, reply_markup=inline)
        send_message(chat_id, "👇 Use the menu below", reply_markup=get_main_keyboard(user_id))
    else:
        send_message(chat_id, text, reply_markup=get_main_keyboard(user_id))

def wm_menu_view():
    txt = ("👋 <b>WELCOME MESSAGES</b>\nSet up to 3 messages. /start sends one of them at random.\n"
           "Use <code>{name}</code> for the user's name.")
    kb = {"inline_keyboard": []}
    for i, w in enumerate(wm_slots(), 1):
        ok = bool(str(w["text"]).strip())
        kb["inline_keyboard"].append([{"text": f"Message {i}: " + ("✅ SET" if ok else "➖ EMPTY"), "callback_data": f"wm_slot_{i}", "style": "success" if ok else "primary"}])
    kb["inline_keyboard"].append([{"text": "BACK", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5267490665117275176", "style": "danger"}])
    return txt, kb

def wm_slot_view(n):
    w = wm_slots()[n - 1]
    body = html.escape(str(w["text"])[:600]) if str(w["text"]).strip() else "<i>Empty</i>"
    btns = "\n".join(f"• {html.escape(b['text'])} → {html.escape(b['url'])}" for b in w["buttons"]) or "None"
    txt = f"👋 <b>WELCOME MESSAGE {n}</b>\n━━━━━━━━━━━━━━━\n{body}\n━━━━━━━━━━━━━━━\n🔘 <b>Buttons:</b>\n{btns}"
    kb = {"inline_keyboard": [
        [{"text": "Edit Text", "callback_data": f"wm_text_{n}", "style": "primary"},
         {"text": "Add Buttons", "callback_data": f"wm_btn_{n}", "style": "success"}],
        [{"text": "Clear Buttons", "callback_data": f"wm_clr_{n}", "style": "danger"},
         {"text": "Delete Message", "callback_data": f"wm_del_{n}", "style": "danger"}],
        [{"text": "Preview", "callback_data": f"wm_prev_{n}", "style": "primary"}],
        [{"text": "BACK", "callback_data": "wm_menu", "icon_custom_emoji_id": "5267490665117275176", "style": "danger"}]
    ]}
    return txt, kb

def get_admin_inline_keyboard():
    global current_db_mode
    db_status = "SQLITE ACTIVE" if current_db_mode == "sqlite" else "FIREBASE ACTIVE"
    
    return {
        "inline_keyboard": [
            [
                {
                    "text": "VOLTX SETTINGS", 
                    "callback_data": "manage_voltx", 
                    "icon_custom_emoji_id": "5240122519326860770", 
                    "style": "danger"
                },
                {
                    "text": "ZENEX SETTINGS", 
                    "callback_data": "manage_zenex", 
                    "icon_custom_emoji_id": "5240122519326860770", 
                    "style": "success"
                }
            ],
            [
                {
                    "text": "📦 MANUAL NUMBERS", 
                    "callback_data": "mn_home", 
                    "style": "primary"
                }
            ],
            [
                {"text": "WELCOME MESSAGE", "callback_data": "wm_menu", "style": "success"}
            ],
            [
                {"text": "📬 TEMP MAIL", "callback_data": "tma_home", "style": "primary"}
            ],
            *emj_owner_rows(),
            [
                {
                    "text": "PREMIUM EMOJI: ON" if bot_settings.get("premium_emoji", False) else "PREMIUM EMOJI: OFF", 
                    "callback_data": "toggle_premium", 
                    "icon_custom_emoji_id": "5352694861990501856" if bot_settings.get("premium_emoji", False) else "5420130255174145507", 
                    "style": "success" if bot_settings.get("premium_emoji", False) else "danger"
                }
            ],
            [
                {
                    "text": "BROADCAST", 
                    "callback_data": "broadcast_menu", 
                    "icon_custom_emoji_id": "5296633779157243809", 
                    "style": "primary"
                },
                {
                    "text": "FORCE JOIN", 
                    "callback_data": "manage_fj", 
                    "icon_custom_emoji_id": "5429353834881261942", 
                    "style": "success"
                }
            ],
            [
                {
                    "text": "OTP GROUP", 
                    "callback_data": "manage_otp_group", 
                    "icon_custom_emoji_id": "5429208347159077664", 
                    "style": "danger"
                },
                {
                    "text": "USER CONTROL", 
                    "callback_data": "user_control", 
                    "icon_custom_emoji_id": "5429274992166609833", 
                    "style": "primary"
                }
            ],
            [
                {
                    "text": "DXA CONTROL", 
                    "callback_data": "dxa_control", 
                    "icon_custom_emoji_id": "5240451569656308978", 
                    "style": "danger"
                }
            ],
            [
                {
                    "text": "UPLOAD FIREBASE", 
                    "callback_data": "upload_firebase", 
                    "icon_custom_emoji_id": "5429362935916962442", 
                    "style": "primary"
                }
            ],
            [
                {
                    "text": db_status, 
                    "callback_data": "db_status", 
                    "icon_custom_emoji_id": "5429591316507963112", 
                    "style": "success"
                }
            ],
            [
                {
                    "text": "CLOSE", 
                    "callback_data": "close_panel", 
                    "icon_custom_emoji_id": "5438541186539232243", 
                    "style": "danger"
                }
            ]
        ]
    }

# ==========================================
# Withdraw helpers + Payment PROOF post (public proof group/channel)
# ==========================================
def is_usdt_method(method):
    return "usdt" in str(method or "").lower()

def valid_usdt_address(addr):
    return bool(re.fullmatch(r"0x[0-9a-fA-F]{40}", str(addr or "").strip()))

def mask_account(acc):
    """Number -> 9396ARD988 style, wallet address -> 0xjheuhe..............kdjjee8 style.
    The full value is never shown in the proof."""
    acc = str(acc or "").strip()
    if len(acc) >= 20:
        return f"{acc[:8]}{'.' * 14}{acc[-7:]}"
    if len(acc) >= 8: return f"{acc[:4]}ARD{acc[-3:]}"
    if len(acc) >= 5: return f"{acc[:2]}ARD{acc[-2:]}"
    return f"{acc[:1]}ARD"

def wd_amount_text(method, amount_bdt):
    if is_usdt_method(method):
        rate = float(bot_settings.get("usdt_rate", 120.0)) or 120.0
        return f"${amount_bdt / rate:.2f} USDT"
    return f"{amount_bdt:.2f} BDT"

def wd_method_label(method):
    return re.sub(r"[()]", "", str(method or "")).strip()      # "USDT (BEP20)" -> "USDT BEP20"

def wd_admin_text(wid, p, title="NEW WITHDRAW REQUEST"):
    """Admin payment group message - shows the FULL number/address (admin needs it to pay)."""
    usdt = is_usdt_method(p["method"])
    amt = f"{p['amount']:.2f} BDT" + (f" (≈ {wd_amount_text(p['method'], p['amount'])})" if usdt else "")
    return (
        f"<tg-emoji emoji-id=\"5420396762189831222\">🆕</tg-emoji> <b>{title}</b> <code>#{wid}</code>\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>User:</b> <a href='tg://user?id={p['uid']}'>{html.escape(str(p['name']))}</a>\n"
        f"— — — — — — — — — —\n"
        f"<tg-emoji emoji-id=\"5226929552319594190\">🆔</tg-emoji> <b>ID:</b> <code>{p['uid']}</code>\n"
        f"— — — — — — — — — —\n"
        f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>Amount:</b> <b>{amt}</b>\n"
        f"— — — — — — — — — —\n"
        f"<tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>Method:</b> {html.escape(str(p['method']))}\n"
        f"— — — — — — — — — —\n"
        f"<tg-emoji emoji-id=\"5337132498965010628\">📞</tg-emoji> <b>{'Address' if usdt else 'Number'}:</b> <code>{html.escape(str(p['account']))}</code>\n"
        f"━━━━━━━━━━━━━━━━━"
    )

def build_proof_text(wid, p):
    date_txt = time.strftime("%Y-%m-%d %I:%M %p", time.gmtime(time.time() + PROOF_UTC_OFFSET * 3600))
    uname = BOT_USERNAME.lstrip("@") if BOT_USERNAME else ""
    lines = [
        f"<b>{html.escape(PROOF_BRAND)} Pay Proof</b>",
        f"#{wid} {html.escape(PROOF_BRAND)} Payment Completed",
        "━━━━━━━━━━━━━━━━━━━━",
        f"👤 User Name: {html.escape(str(p['name']))}",
        f"💰 Amount: {html.escape(wd_amount_text(p['method'], p['amount']))}",
        f"🗂 Withdraw: {html.escape(wd_method_label(p['method']))}",
    ]
    if PROOF_SHOW_ACCOUNT:
        lines.append(f"🏦 {'Address' if is_usdt_method(p['method']) else 'Number'}: <code>{html.escape(mask_account(p['account']))}</code>")
    lines += [f"🕐 Date: {date_txt}", "━━━━━━━━━━━━━━━━━━━━", f"➡️ Invite & Earn @{uname}"]
    return "\n".join(lines)

def post_withdraw_proof(wid, p, link):
    """Send the proof to the proof group/channel with a 'Check Transactions' button -> admin's link."""
    grp = bot_settings.get("proof_group", "")
    if not grp: return False, "Proof group is not set (DXA Control > PROOF GROUP)"
    markup = {"inline_keyboard": [[{"text": "🔍 Check Transactions", "url": link}]]}
    res = send_message(grp, build_proof_text(wid, p), reply_markup=markup)
    if res and res.get("ok"): return True, ""
    return False, str((res or {}).get("description", "send failed"))

def dxa_control_keyboard():
    grp = bot_settings.get("w_group", "")
    grp_status = grp if grp else "NOT SET"
    return {"inline_keyboard": [
        [{"text": f"MIN WITHDRAW: {bot_settings['min_withdraw']}", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "dxa_min_w", "style": "success"},
         {"text": "OTP CONTROL", "icon_custom_emoji_id": "5190576863226933563", "callback_data": "dxa_otp_control", "style": "primary"}],
        [{"text": f"REFER REWARD: {bot_settings.get('refer_reward', 0.2)}", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "dxa_ref_r", "style": "success"},
         {"text": f"COOLDOWN: {bot_settings['cooldown']}s", "icon_custom_emoji_id": "5337172996211648018", "callback_data": "dxa_cool", "style": "primary"}],
        [{"text": f"NUM/REQ: {bot_settings['num_req']}", "icon_custom_emoji_id": "5337132498965010628", "callback_data": "dxa_num_req", "style": "success"},
         {"text": "W. METHODS", "icon_custom_emoji_id": "5190899075968441286", "callback_data": "manage_w_methods", "style": "primary"}],
        [{"text": f"W. GROUP: {grp_status}", "icon_custom_emoji_id": "5420517437885943844", "callback_data": "dxa_w_group", "style": "success"}],
        [{"text": f"PROOF GROUP: {bot_settings.get('proof_group') or 'NOT SET'}", "icon_custom_emoji_id": "5420517437885943844", "callback_data": "dxa_proof_group", "style": "success"}],
        [{"text": f"USDT RATE: {bot_settings.get('usdt_rate', 120.0)} BDT", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "dxa_usdt_rate", "style": "primary"}],
        [{"text": "BACK", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]
    ]}

def dxa_otp_control_keyboard():
    kb = {"inline_keyboard": [
        [{"text": f"Default Rate: {bot_settings['otp_default_rate']}", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "dxa_def_rate", "style": "primary"}],
        [{"text": "Set Service Rate", "icon_custom_emoji_id": "5395444784611480792", "callback_data": "dxa_srv_rate", "style": "success"}]
    ]}
    
    # অ্যাড করা স্পেসিফিক সার্ভিস রেটগুলো ডায়নামিক ইনলাইন বাটন হিসেবে দেখানোর জন্য
    for srv_name, rate in bot_settings.get("otp_service_rates", {}).items():
        app_info = PREMIUM_APPS.get(srv_name, PREMIUM_APPS["Other"])
        kb["inline_keyboard"].append([{"text": f"Delete: {srv_name} ({rate})", "icon_custom_emoji_id": app_info["id"], "callback_data": f"del_srv_rate_{srv_name}", "style": "danger"}])
        
    kb["inline_keyboard"].append([{"text": "BACK", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "dxa_control", "style": "danger"}])
    return kb
    
def dxa_manage_w_methods_keyboard():
    kb = {"inline_keyboard": []}
    for idx, method in enumerate(bot_settings.get("w_methods", [])):
        kb["inline_keyboard"].append([{"text": f"Delete: {method}", "callback_data": f"del_w_method_{idx}", "style": "danger"}])
    kb["inline_keyboard"].append([{"text": "Add Method", "callback_data": "add_w_method", "style": "success"}])
    kb["inline_keyboard"].append([{"text": "BACK", "callback_data": "dxa_control", "style": "primary"}])
    return kb

def get_user_control_keyboard():
    return {
        "inline_keyboard": [
            [{"text": "USER PROFILE", "icon_custom_emoji_id": "5352861489541714456", "callback_data": "uc_profile", "style": "primary"}],
            [{"text": "BACK", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]
        ]
    }

def get_user_profile_keyboard(target_uid):
    return {
        "inline_keyboard": [
            [{"text": "BALANCE", "icon_custom_emoji_id": "5429612421977253466", "callback_data": f"uc_balance_{target_uid}", "style": "success"}],
            [{"text": "BACK", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "user_control", "style": "danger"}]
        ]
    }

def get_upload_firebase_keyboard():
    return {"inline_keyboard": [[{"text": "CANCEL", "callback_data": "back_to_admin", "icon_custom_emoji_id": "5420130255174145507", "style": "danger"}]]}

def get_back_only_keyboard():
    return {"inline_keyboard": [[{"text": "BACK", "callback_data": "user_cancel", "icon_custom_emoji_id": "5438541186539232243", "style": "danger"}]]}

def get_leaderboard_keyboard():
    return {"inline_keyboard": [[{"text": "REFRESH", "callback_data": "refresh_leaderboard", "icon_custom_emoji_id": "5229111790842952353", "style": "success"}]]}

def get_owner_panel_text():
    today = time.strftime("%Y-%m-%d")
    if daily_stats.get("date") != today:
        daily_stats["date"] = today
        daily_stats["numbers"] = 0
        daily_stats["otps"] = 0
        
    return (
        "<b>📊 OWNER ZONE 📊</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "<b>📊 DATABASE OVERVIEW</b>\n"
        "— — — — — — — — — —\n"
        f"<blockquote><b>👤 TOTAL USER         » {get_total_users()}</b></blockquote>\n"
        f"<blockquote><b>📱 TODAY NUMBER  » {daily_stats['numbers']}</b></blockquote>\n"
        f"<blockquote><b>💬 TODAY OTP           » {daily_stats['otps']}</b></blockquote>\n"
        "━━━━━━━━━━━━━━━━━━"
    )

def get_leaderboard_text():
    global cached_leaderboard_text
    if cached_leaderboard_text:
        return cached_leaderboard_text
    return "⏳ <b>Loading leaderboard, please wait...</b>"

def get_live_traffic_content():
    global recent_traffic, zenex_traffic, manual_traffic
    hits_to_show = list(recent_traffic) + (list(zenex_traffic) if zenex_active() else []) + list(manual_traffic)
    markup = {"inline_keyboard": [[{"text": "REFRESH", "callback_data": "refresh_traffic", "icon_custom_emoji_id": "5229111790842952353", "style": "primary"}]]}
    head = "╔═════════════════╗\n║  <tg-emoji emoji-id=\"5352877703043258544\">📈</tg-emoji> <b>NETWORK TRAFFIC</b>\n╚═════════════════╝\n"
    if not hits_to_show:
        return head + "<i>No traffic data available.</i>\n━━━━━━━━━━━━━━━━━━━", markup

    # service -> country name -> success count
    services = {}
    for h in hits_to_show:
        sid = detect_service(h.get("message") or "", h.get("sid") or "Unknown")
        info = PREMIUM_APPS.get(sid, PREMIUM_APPS["Other"])
        svc = services.setdefault(sid, {"emoji_id": info["id"], "emoji": info["emoji"], "total": 0, "countries": {}})
        _code, cname = get_country_info(h.get("range"))
        svc["countries"][cname] = svc["countries"].get(cname, 0) + 1
        svc["total"] += 1

    msg = head
    for sid, svc in sorted(services.items(), key=lambda x: x[1]["total"], reverse=True)[:8]:
        msg += f"\n[ <tg-emoji emoji-id=\"{svc['emoji_id']}\">{svc['emoji']}</tg-emoji> <b>{html.escape(str(sid))}</b> ]\n│\n"
        top = sorted(svc["countries"].items(), key=lambda x: x[1], reverse=True)[:6]
        for i, (cname, cnt) in enumerate(top):
            iso = flag_to_iso(cname.split(" ")[0])
            label = html.escape(cname) + (f" ({iso})" if iso else "")
            msg += f"├ {label}\n│ ╰ Success: <b>{cnt}</b>\n"
    msg += "\n━━━━━━━━━━━━━━━━━━━"
    return msg[:4000], markup

def get_services_content():
    global cached_services_kb
    if cached_services_kb:
        return "✅ <b>Select Service:</b>", cached_services_kb
    # Cache not ready yet (e.g. no traffic hit Voltx yet since restart) -> ask the panel directly
    if voltx_active():
        try:
            services_data = fetch_live_access()
        except Exception:
            services_data = []
        if services_data:
            kb = {"inline_keyboard": []}
            row = []
            for s in services_data[:30]:
                sid_val = s.get("sid") or "Unknown"
                safe_sid = html.escape(str(sid_val))
                app_info = PREMIUM_APPS.get(sid_val, PREMIUM_APPS["Other"])
                row.append({"text": safe_sid, "callback_data": f"srv_{safe_sid[:15]}", "style": "primary", "icon_custom_emoji_id": app_info["id"]})
                if len(row) == 2:
                    kb["inline_keyboard"].append(row); row = []
            if row: kb["inline_keyboard"].append(row)
            if kb["inline_keyboard"]:
                return "✅ <b>Select Service:</b>", kb
    return "⏳ <b>Loading services, please try again in a few seconds...</b>", None

def get_countries_content(sid_short):
    global cached_countries_kb
    if sid_short in cached_countries_kb:
        return f"<b>{sid_short} — Select Country:</b>", cached_countries_kb[sid_short], None
    # Cache not ready yet -> fall back to asking the Voltx panel directly for this service's ranges
    if voltx_active():
        try:
            services_data = fetch_live_access()
        except Exception:
            services_data = []
        for s in services_data:
            sid_val = s.get("sid") or ""
            if sid_val.lower().startswith(sid_short.lower()):
                country_map = {}
                for r in s.get("ranges", []):
                    clean_r = str(r).replace("X", "")
                    if not re.match(r"^\d+$", clean_r): continue
                    c_code, c_name = get_country_info(clean_r)
                    if c_code not in country_map: country_map[c_code] = {"name": c_name, "hits": 0}
                    country_map[c_code]["hits"] += 1
                if country_map:
                    top_countries = sorted(country_map.items(), key=lambda x: x[1]["hits"], reverse=True)[:15]
                    cnt_kb = build_country_keyboard(sid_short, sid_val, top_countries)
                    return f"<b>{sid_short} — Select Country:</b>", cnt_kb, None
                break
    return None, None, "❌ <b>No active countries for this service. (Out of Stock)</b>"

def render_allocation(user_id, sid_short, c_code, full_sid, numbers):
    """Allocated-number screen (reference style) with Remove/Add Country Code toggle."""
    no_cc = user_id in bot_settings.get("no_cc_users", [])
    flag = str(get_country_info(c_code)[1]).split(" ", 1)[0]
    iso = flag_to_iso(flag) or f"+{c_code}"
    std = detect_service("", full_sid)
    app_info = PREMIUM_APPS.get(std, PREMIUM_APPS["Other"])
    price_txt = PRICE_FMT.format(rate=float(get_otp_reward(std)))
    first = re.sub(r"\D", "", str(numbers[0])) if numbers else ""
    prefix = (first[:6] + "XXX") if first else ""
    msg = (
        f"{flag} <b>{html.escape(iso)}</b> Allocated <tg-emoji emoji-id=\"{app_info['id']}\">{app_info['emoji']}</tg-emoji> <b>{html.escape(str(full_sid))}</b>\n"
        f"Otp Rate : {html.escape(price_txt)}\n"
        f"🕓 Waiting for OTP..... ⬇️\n"
        f"🔗 Prefix: <code>{prefix}</code>"
    )
    kb = {"inline_keyboard": []}
    for num in numbers:
        d = re.sub(r"\D", "", str(num))
        if no_cc:
            code = get_country_info(d)[0]
            shown = d[len(code):] if code and d.startswith(code) else d
        else:
            shown = "+" + d
        kb["inline_keyboard"].append([{"text": f"{flag} 📋 {shown}", "copy_text": {"text": shown}, "style": "primary"}])
    if str(otp_button_link).startswith("http"):
        kb["inline_keyboard"].append([{"text": "OTP Group", "icon_custom_emoji_id": "5314366268898300483", "url": otp_button_link, "style": "success"}])
    kb["inline_keyboard"].append([{"text": "➕ Add Country Code" if no_cc else "❌ Remove Country Code", "callback_data": "tgl_cc", "style": "primary"}])
    kb["inline_keyboard"].append([
        {"text": "Country", "callback_data": f"srv_{sid_short}", "style": "primary"},
        {"text": "Change", "callback_data": f"cc_{sid_short}_{c_code}", "style": "primary"}
    ])
    return msg, kb

def get_number_allocation_content(sid_short, c_code, user_id=None):
    global voltx_auto_mode, voltx_dynamic_data, user_active_sessions, bot_settings, otp_button_link
    full_sid = sid_short
    panels = get_active_panels()
    back_kb = {"inline_keyboard": [[{"text": "BACK", "callback_data": f"srv_{sid_short}", "icon_custom_emoji_id": "5438541186539232243", "style": "danger"}]]}

    if not panels:
        return "❌ <b>No number panel is active right now. Please contact admin.</b>", back_kb

    # ranges per panel: {"voltx": [(range, hits)], "zenex": [(range, hits)]}
    panel_ranges = {"voltx": [], "zenex": [], "manual": []}

    merged = get_merged_dynamic_data()
    for sid, data in merged.items():
        if sid.lower().startswith(sid_short.lower()):
            full_sid = sid
            for r, r_data in data["ranges"].items():
                if c_code.startswith(r) or r.startswith(c_code):
                    for p in r_data.get("panels", []):
                        panel_ranges[p].append((r, r_data["hits"]))
            break

    # Voltx with AUTO off -> use its live access list (old behaviour)
    if voltx_active() and not voltx_auto_mode:
        services_data = fetch_live_access()
        for s in services_data:
            sid_val = s.get('sid') or ""
            if sid_val.lower().startswith(sid_short.lower()):
                full_sid = sid_val
                for r in s.get('ranges', []):
                    clean_r = str(r).replace("X", "")
                    if c_code.startswith(clean_r) or clean_r.startswith(c_code):
                        if clean_r not in [x[0] for x in panel_ranges["voltx"]]:
                            panel_ranges["voltx"].append((clean_r, 1))
                break

    def best_ranges_for(panel):
        ranked = sorted(panel_ranges[panel], key=lambda x: x[1], reverse=True)
        best = [x[0] for x in ranked[:3]]
        # range not in any API list -> still request directly with the link's range
        return best if best else [c_code]

    req_count = bot_settings.get("num_req", 1)
    fetched_numbers = []

    for _ in range(req_count):
        order = [p for p in panels if p != "manual"]
        random.shuffle(order)          # spread load between Voltx and Zenex
        if panel_ranges["manual"]:
            order.insert(0, "manual")  # admin-uploaded numbers are used first
        num_data = None
        for panel in order:            # if one panel is out of stock, fall back to the next
            if panel == "manual":
                for rid, _h in sorted(panel_ranges["manual"], key=lambda x: x[1], reverse=True):
                    num_data = fetch_manual_number(full_sid, rid)
                    if num_data: break
            else:
                num_data = fetch_number_from_panel(panel, random.choice(best_ranges_for(panel)))
            if num_data: break
        if num_data:
            full_number = html.escape(str(num_data.get("full_number", "")))
            country = html.escape(str(num_data.get("country", "Unknown")))
            operator = html.escape(str(num_data.get("operator", "Unknown")))
            fetched_numbers.append((full_number, country, operator))

            if user_id and full_number:
                user_active_sessions[str(full_number).lstrip("+")] = user_id

    if fetched_numbers:
        update_daily_stat("numbers", len(fetched_numbers))
        save_local_data()
        
        nums_only = [n[0] for n in fetched_numbers]
        if user_id is not None:
            last_alloc[user_id] = {"sid": sid_short, "c_code": c_code, "full_sid": full_sid, "numbers": nums_only}
        return render_allocation(user_id, sid_short, c_code, full_sid, nums_only)
    else:
        return f"❌ <b>Out of stock in these ranges. Please try again.</b>", {"inline_keyboard": [[{"text": "BACK", "callback_data": f"srv_{sid_short}", "icon_custom_emoji_id": "5438541186539232243", "style": "danger"}]]}

# ==========================================
# Background Broadcaster Tool 
# ==========================================
# ==========================================
# FAKE OTP (admin test) + BROADCAST -> OTP GROUP (+ auto pin)
# ==========================================
FAKE_MSGS = {
    "English": ["Your {svc} code is {code}. Do not share this code with anyone.", "{code} is your {svc} verification code."],
    "French": ["Votre code {svc} est {code}. Ne le partagez avec personne.", "{code} est votre code de vérification {svc}."],
    "Spanish": ["Tu código de {svc} es {code}. No lo compartas con nadie.", "{code} es tu código de verificación de {svc}."],
    "Portuguese": ["Seu código do {svc} é {code}. Não compartilhe com ninguém.", "{code} é o seu código de verificação do {svc}."],
    "Arabic": ["رمز {svc} الخاص بك هو {code}. لا تشاركه مع أي شخص.", "{code} هو رمز التحقق الخاص بك في {svc}."],
    "Russian": ["Ваш код {svc}: {code}. Никому не сообщайте его.", "{code} — ваш код подтверждения {svc}."],
    "Turkish": ["{svc} doğrulama kodunuz: {code}. Kimseyle paylaşmayın.", "{code} sizin {svc} kodunuzdur."],
    "Indonesian": ["Kode {svc} Anda adalah {code}. Jangan bagikan kode ini kepada siapa pun.", "{code} adalah kode verifikasi {svc} Anda."],
    "Bengali": ["আপনার {svc} কোড: {code}। এটি কাউকে দেবেন না।", "{code} আপনার {svc} ভেরিফিকেশন কোড।"],
    "Hindi": ["आपका {svc} कोड {code} है। इसे किसी के साथ साझा न करें।", "{code} आपका {svc} सत्यापन कोड है।"],
}

def send_fake_otp():
    """Random service + random country + random number + random message + random code -> OTP group.
    Goes only to the group (no user credit, no balance, no stats)."""
    svc = random.choice([s for s in PREMIUM_APPS.keys() if s != "Other"])
    cc = random.choice(list(COUNTRY_CODES.keys()))
    total = random.randint(10, 12)
    rest = max(6, total - len(cc))
    number = cc + str(random.randint(1, 9)) + "".join(random.choice("0123456789") for _ in range(rest - 1))
    if svc == "WhatsApp":
        code = f"{random.randint(100, 999)}-{random.randint(100, 999)}"
    else:
        code = "".join(random.choice("0123456789") for _ in range(random.choice([5, 6, 6, 6])))
    lang = detect_sms_language(cc, "")
    msg = random.choice(FAKE_MSGS.get(lang, FAKE_MSGS["English"])).format(svc=svc, code=code)
    if svc == "WhatsApp": msg = "<#> " + msg
    text, markup = generate_otp_display(svc, number, msg)
    return send_otp_to_groups(text, markup)

def pin_message(chat_id, message_id):
    try:
        return requests.post(BASE_URL + "pinChatMessage", json={"chat_id": chat_id, "message_id": message_id, "disable_notification": False}).json()
    except Exception:
        return None

def get_broadcast_text():
    pin_on = bot_settings.get("broadcast_pin", False)
    return ("📣 <b>BROADCAST SYSTEM</b>\n\nSend any text, photo, video, or audio message you want to broadcast to all users.\n\n"
            "📢 It will also be sent to the <b>OTP group</b>.\n"
            f"📌 Auto pin in OTP group: <b>{'ON' if pin_on else 'OFF'}</b>")

def get_broadcast_keyboard():
    pin_on = bot_settings.get("broadcast_pin", False)
    return {"inline_keyboard": [
        [{"text": "AUTO PIN: ON" if pin_on else "AUTO PIN: OFF", "callback_data": "toggle_bc_pin",
          "icon_custom_emoji_id": "5352694861990501856" if pin_on else "5420130255174145507", "style": "primary" if pin_on else "danger"}],
        [{"text": "BACK", "callback_data": "user_cancel", "icon_custom_emoji_id": "5438541186539232243", "style": "danger"}]
    ]}

def broadcast_worker(from_chat_id, message_id, target_msg_id):
    users = get_all_user_ids() 
    success_count = 0
    group_note = ""
    if otp_forward_groups:
        g_ok = 0; pinned = 0; pin_fail = False
        want_pin = bot_settings.get("broadcast_pin", False)
        for gid in list(otp_forward_groups):
            try:
                gres = copy_message(gid, from_chat_id, message_id)
                if gres and gres.get("ok"):
                    g_ok += 1
                    if want_pin:
                        pres = pin_message(gid, gres["result"]["message_id"])
                        if pres and pres.get("ok"): pinned += 1
                        else: pin_fail = True
            except Exception: pass
        group_note = f"\n📢 OTP Group: sent {g_ok}/{len(otp_forward_groups)}"
        if want_pin:
            group_note += f" | 📌 pinned {pinned}"
            if pin_fail: group_note += "\n⚠️ Pin failed: make the bot admin in the group with 'Pin Messages' permission."
    for uid in users:
        try:
            res = copy_message(uid, from_chat_id, message_id)
            if res and res.get("ok"): success_count += 1
            time.sleep(0.05) 
        except: pass
        
    send_message(from_chat_id, f"✅ <b>Broadcast Completed!</b>\nSuccessfully sent to {success_count} users out of {len(users)}." + group_note)
    
    if target_msg_id:
        edit_message(from_chat_id, target_msg_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())

# ==========================================
# Message Handlers
# ==========================================
def handle_message(message):
    global voltx_enabled, zenex_keys, zenex_enabled
    global waiting_for_firebase, current_db_mode, db_firebase, user_states, voltx_keys, force_join_channels, otp_forward_groups, otp_button_link, bot_settings
    global augestel_key, augestel_enabled, lamix_key, lamix_enabled
    
    # 🌟 বট শুধুমাত্র ইনবক্সের মেসেজে রিপ্লাই দিবে (গ্রুপ ইগনোর করবে)
    if message.get("chat", {}).get("type") != "private":
        return
        
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    _raw_text = message.get("text", "")
    text = normalize_button_text(_KB_UNMAP.get(_raw_text, _raw_text))
    message_id = message["message_id"]
    first_name = message["from"].get("first_name", "User")

    if text in ("/panel", "/admin") and user_id == ADMIN_ID:
        if WEBAPP_URL.startswith("https://"):
            send_message(chat_id, "🌐 <b>WEB ADMIN PANEL</b>", reply_markup={"inline_keyboard": [[{"text": "🌐 OPEN PANEL", "web_app": {"url": WEBAPP_URL}, "style": "success"}]]})
        else:
            send_message(chat_id, "⚠️ Set the <code>WEBAPP_URL</code> environment variable (public https link of this bot's server) and restart.")
        return

    if text == "🔙 BACK" and user_id == ADMIN_ID:
        send_message(chat_id, "❌ <b>Action Cancelled!</b>", reply_markup=get_main_keyboard(user_id)) 
        if user_id in user_states: del user_states[user_id]
        send_message(chat_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())
        return

    # Native Chat Selection Listener
    if "chat_shared" in message:
        shared_chat_id = message["chat_shared"]["chat_id"]
        if user_id == ADMIN_ID and user_id in user_states:
            state_data = user_states[user_id]
            state = state_data.get("state")
            target_msg_id = state_data.get("msg_id")
            
            send_message(chat_id, "✅ <b>Successfully Selected!</b>", reply_markup=get_main_keyboard(user_id)) 
            
            if state == "waiting_otp_group":
                otp_forward_groups.clear() 
                otp_forward_groups.append(str(shared_chat_id))
                
                inv_res = requests.post(BASE_URL + "exportChatInviteLink", json={"chat_id": shared_chat_id}).json()
                if inv_res.get("ok"):
                    otp_button_link = inv_res["result"]
                
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
                del user_states[user_id]
                return
                
            elif state == "waiting_dxa_proof_group":
                bot_settings["proof_group"] = str(shared_chat_id)
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
                del user_states[user_id]
                return

            elif state == "waiting_dxa_w_group":
                bot_settings["w_group"] = str(shared_chat_id)
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
                del user_states[user_id]
                return
                
            elif state == "waiting_fj_channel":
                chat_details = get_chat_details(str(shared_chat_id))
                if chat_details:
                    force_join_channels.append(chat_details)
                    save_local_data()
                    if target_msg_id: edit_message(chat_id, target_msg_id, "🔗 <b>FORCE JOIN SYSTEM</b>\nManage channels below:", reply_markup=get_force_join_keyboard())
                else:
                    if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Failed to verify channel! Make sure bot is admin.</b>", reply_markup=get_back_only_keyboard())
                del user_states[user_id]
                return

    if not is_user_joined(user_id):
        fj_msg = (
            "<b>════《 <tg-emoji emoji-id=\"5337267511261960341\">🔥</tg-emoji> ACCESS REQUIRED 》════</b>\n\n"
            "<b><tg-emoji emoji-id=\"5420517437885943844\">🔗</tg-emoji> JOIN ALL CHANNELS BELOW TO USE THIS BOT.</b>\n\n"
            "<b><tg-emoji emoji-id=\"5352694861990501856\">✅</tg-emoji> JOIN ALL CHANNELS, THEN CLICK VERIFY.</b>"
        )
        send_message(chat_id, fj_msg, reply_markup=get_force_join_alert_keyboard())
        return

    # Handle Admin & User Input States
    if user_id in user_states:
        state_data = user_states[user_id]
        if isinstance(state_data, dict):
            state = state_data.get("state")
            target_msg_id = state_data.get("msg_id")
        else:
            state = state_data
            target_msg_id = None
            
        if state == "waiting_wd_link" and user_id == ADMIN_ID:
            link = text.strip()
            wid = str(state_data.get("wid"))
            p = bot_settings["pending_withdrawals"].get(wid)
            if not re.fullmatch(r"https?://\S+", link):
                send_message(chat_id, "❌ <b>Send a valid link</b> (must start with http:// or https://)", reply_markup=get_back_only_keyboard())
                return
            if not p:
                send_message(chat_id, "⚠️ This request was already processed.", reply_markup=get_main_keyboard(user_id))
                del user_states[user_id]
                return
            bot_settings["pending_withdrawals"].pop(wid, None)
            save_local_data()
            # 1) admin payment group message -> APPROVED
            if state_data.get("gchat") and state_data.get("gmsg"):
                edit_message(state_data["gchat"], state_data["gmsg"], wd_admin_text(wid, p, "WITHDRAW APPROVED"),
                             reply_markup={"inline_keyboard": [[{"text": "APPROVED BY ADMIN", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "ignore_action", "style": "success"}]]})
            # 2) tell the user (number/address masked)
            send_message(p["uid"], f"<tg-emoji emoji-id=\"5420396762189831222\">🎉</tg-emoji> <b>Withdrawal Approved!</b>\n"
                                   f"#{wid} | {html.escape(wd_amount_text(p['method'], p['amount']))} sent to <code>{html.escape(mask_account(p['account']))}</code>.",
                         reply_markup={"inline_keyboard": [[{"text": "🔍 Check Transactions", "url": link}]]})
            # 3) proof -> proof group / channel
            ok, err = post_withdraw_proof(wid, p, link)
            result = "✅ Approved & proof posted." if ok else f"✅ Approved, but proof NOT posted: {html.escape(err)}"
            send_message(chat_id, f"{result}\n<code>#{wid}</code>", reply_markup=get_main_keyboard(user_id))
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        if state in ("waiting_tma_batch", "waiting_tma_cd") and user_id == ADMIN_ID:
            val = text.strip()
            note = ""
            if True:
                try:
                    num = float(val)
                    if state == "waiting_tma_batch":
                        if num < 1: raise ValueError
                        bot_settings["tm_batch"] = int(num)
                    else:
                        if num < 0: raise ValueError
                        bot_settings["tm_cooldown_min"] = int(num) if num == int(num) else num
                    note = "✅ Saved\n\n"
                except ValueError:
                    note = "❌ Invalid number\n\n"
            save_local_data()
            view = tm_admin_view(note=note)
            if target_msg_id: edit_message(chat_id, target_msg_id, view[0], reply_markup=view[1])
            del user_states[user_id]
            delete_message(chat_id, message_id)      # removes the message that may contain the API key
            return

        if state in ("waiting_emj_add", "waiting_emj_del") and user_id == ADMIN_ID:
            raw_in = message.get("text") or ""
            if state == "waiting_emj_del":
                report = emj_apply_input("\n".join("-" + t for t in raw_in.split()))
            else:
                report = emj_apply_input(raw_in, message.get("entities"))
            view = emj_home_view("\n".join(report) + "\n\n")
            if target_msg_id: edit_message(chat_id, target_msg_id, view[0], reply_markup=view[1])
            else: send_message(chat_id, view[0], reply_markup=view[1])
            del user_states[user_id]
            return

        if state == "waiting_lx_key" and user_id == ADMIN_ID:
            lamix_key = text.strip()
            lamix_cache["t"] = 0; lamix_cache["numbers"] = []
            save_manual_data()
            view = lx_api_view(note="✅ Token saved\n\n")
            if target_msg_id: edit_message(chat_id, target_msg_id, view[0], reply_markup=view[1])
            del user_states[user_id]
            delete_message(chat_id, message_id)     # remove the message that contains the token
            return

        if state in ("waiting_mn_service", "waiting_mn_country", "waiting_mn_numbers", "waiting_mn_key") and user_id == ADMIN_ID:
            si = state_data.get("si", 0); ci = state_data.get("ci", 0)
            names = list(manual_stock.keys())
            view = None
            if state == "waiting_mn_service":
                key = manual_service_key(text)
                if key and key not in manual_stock:
                    with manual_lock: manual_stock[key] = {}
                    save_manual_data()
                    view = mn_service_view(list(manual_stock.keys()).index(key))
                else:
                    view = mn_home_view()
            elif state == "waiting_mn_country" and si < len(names):
                digits = re.sub(r"\D", "", text)
                if digits:
                    code, cname = get_country_info(digits)
                    with manual_lock:
                        manual_stock[names[si]].setdefault(code, {"name": cname, "numbers": []})
                    save_manual_data()
                    view = mn_country_view(si, list(manual_stock[names[si]].keys()).index(code))
                else:
                    view = mn_service_view(si)
            elif state == "waiting_mn_numbers" and si < len(names):
                raw = text
                if "document" in message:
                    try:
                        fid = message["document"]["file_id"]
                        fpath = requests.get(BASE_URL + f"getFile?file_id={fid}").json()["result"]["file_path"]
                        raw = requests.get(f"https://api.telegram.org/file/bot{BOT_TOKEN}/{fpath}", timeout=30).content.decode("utf-8", errors="ignore")
                    except Exception:
                        raw = ""
                codes = list(manual_stock[names[si]].keys())
                if ci < len(codes):
                    added = dup = bad = 0
                    with manual_lock:
                        pool = manual_stock[names[si]][codes[ci]]["numbers"]
                        existing = set(pool)
                        for tok in re.split(r"[\s,;]+", raw):
                            if not tok: continue
                            n = normalize_number(tok)
                            if not n: bad += 1
                            elif n in existing or n in manual_used: dup += 1
                            else: pool.append(n); existing.add(n); added += 1
                    save_manual_data()
                    web_sync.on_numbers_added(names[si], codes[ci], manual_stock[names[si]][codes[ci]].get("name", ""), added)
                    view = mn_country_view(si, ci, note=f"✅ Added <b>{added}</b> | Duplicate/used <b>{dup}</b> | Invalid <b>{bad}</b>\n\n")
                else:
                    view = mn_service_view(si)
            elif state == "waiting_mn_key":
                augestel_key = text.strip()
                save_manual_data()
                view = mn_api_view(note="✅ Key saved\n\n")
            if view is None: view = mn_home_view()
            if target_msg_id: edit_message(chat_id, target_msg_id, view[0], reply_markup=view[1])
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        if state == "waiting_zk_key" and user_id == ADMIN_ID:
            new_key = text.strip()
            if new_key and new_key not in zenex_keys: zenex_keys.append(new_key)
            save_local_data()
            if target_msg_id: edit_message(chat_id, target_msg_id, get_zenex_panel_text(), reply_markup=get_zenex_keys_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        if state == "waiting_vk_key":
            voltx_keys.append(text.strip())
            save_local_data()
            if target_msg_id: edit_message(chat_id, target_msg_id, "🔑 <b>VOLTX KEY SYSTEM</b>\nManage API Keys below:", reply_markup=get_voltx_keys_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_otp_link":
            if text.startswith("http"):
                otp_button_link = text.strip()
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
            else:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid URL format. Must start with http/https.</b>", reply_markup=get_back_only_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state == "waiting_main_channel_link":
            if text.startswith("http"):
                bot_settings["main_channel_link"] = text.strip()
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
            else:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid URL format. Must start with http/https.</b>", reply_markup=get_back_only_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state in ("waiting_wm_text", "waiting_wm_button") and user_id == ADMIN_ID:
            n = int(state_data.get("slot", 1))
            ws = wm_slots()
            err = ""
            if not text:
                err = "❌ <b>Please send text only.</b>"
            elif state == "waiting_wm_text":
                ws[n - 1]["text"] = text.strip()[:1500]
            else:
                added = 0
                for line in text.splitlines():
                    if "|" not in line: continue
                    label, url = line.split("|", 1)
                    label, url = label.strip()[:40], url.strip()
                    if label and url.startswith(("http://", "https://", "tg://")) and len(ws[n - 1]["buttons"]) < 6:
                        ws[n - 1]["buttons"].append({"text": label, "url": url}); added += 1
                if not added: err = "❌ <b>Invalid format.</b> Use: <code>Button Text | https://link</code>"
            if err:
                if target_msg_id: edit_message(chat_id, target_msg_id, err, reply_markup=get_back_only_keyboard())
            else:
                bot_settings["welcome_msgs"] = ws
                save_local_data()
                if target_msg_id:
                    txt, kb = wm_slot_view(n)
                    edit_message(chat_id, target_msg_id, txt, reply_markup=kb)
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state == "waiting_broadcast":
            if target_msg_id: edit_message(chat_id, target_msg_id, "⏳ <b>Broadcasting message to all users...</b>")
            threading.Thread(target=broadcast_worker, args=(chat_id, message_id, target_msg_id), daemon=True).start()
            del user_states[user_id]
            return
            
        elif state == "waiting_firebase":
            try:
                # 🌟 ফাইল আপলোড সাপোর্ট অ্যাড করা হলো
                if "document" in message:
                    file_id = message["document"]["file_id"]
                    file_info = requests.get(BASE_URL + f"getFile?file_id={file_id}").json()
                    file_path = file_info["result"]["file_path"]
                    file_url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"
                    text = requests.get(file_url).text
                
                # 🌟 স্মার্ট কোট (Smart Quotes) বা ভুল টেক্সট ফিক্স
                text = text.replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")

                firebase_cred = json.loads(text)
                with open("temp_firebase.json", "w") as f: json.dump(firebase_cred, f)
                try:
                    if not firebase_admin._apps: firebase_admin.initialize_app(credentials.Certificate("temp_firebase.json"))
                    db_firebase = firestore.client()
                    current_db_mode = "firebase"
                    waiting_for_firebase = False
                    
                    # 🌟 One-Time Sync: Firebase থেকে সব ইউজার ID লোকালে সেভ করা (লিমিট বাঁচাতে)
                    try:
                        local_users = set()
                        if os.path.exists(USERS_LIST_FILE):
                            with open(USERS_LIST_FILE, "r") as f:
                                local_users = set(json.load(f))
                        
                        # শুধুমাত্র ID গুলো আনা হচ্ছে, পুরো ডাটা নয় (এতে ব্যান্ডউইথ ও লিমিট বাঁচবে)
                        docs = db_firebase.collection('users').select([]).stream()
                        fb_users = set(int(doc.id) for doc in docs)
                        
                        combined_users = local_users.union(fb_users)
                        if len(combined_users) > len(local_users):
                            with open(USERS_LIST_FILE, "w") as f:
                                json.dump(list(combined_users), f)
                            print(f"✅ Synced {len(fb_users)} users from Firebase to Local List!")
                    except Exception as e:
                        print(f"User Sync Error: {e}")

                    # 🌟 Firebase এ সেটিংস চেক এবং সেভ/সিঙ্ক করার লজিক
                    try:
                        config_ref = db_firebase.collection('settings').document('bot_config')
                        doc = config_ref.get()
                        if not doc.exists:
                            config_data = {
                                "bot_settings": bot_settings,
                                "force_join_status": force_join_status,
                                "force_join_channels": force_join_channels,
                                "otp_forward_groups": otp_forward_groups,
                                "otp_button_link": otp_button_link,
                                "voltx_keys": voltx_keys,
                                "voltx_auto_mode": voltx_auto_mode,
                                "voltx_enabled": voltx_enabled,
                                "zenex_keys": zenex_keys,
                                "zenex_enabled": zenex_enabled
                            }
                            config_ref.set(config_data)
                        else:
                            data = doc.to_dict()
                            if "bot_settings" in data: bot_settings.update(data["bot_settings"])
                            if "force_join_status" in data: force_join_status = data["force_join_status"]
                            if "force_join_channels" in data: force_join_channels = data["force_join_channels"]
                            if "otp_forward_groups" in data: otp_forward_groups = data["otp_forward_groups"]
                            if "otp_button_link" in data: otp_button_link = data["otp_button_link"]
                            if "voltx_keys" in data: voltx_keys = data["voltx_keys"]
                            if "voltx_auto_mode" in data: voltx_auto_mode = data["voltx_auto_mode"]
                            if "voltx_enabled" in data: voltx_enabled = data["voltx_enabled"]
                            if "zenex_keys" in data: zenex_keys = data["zenex_keys"]
                            if "zenex_enabled" in data: zenex_enabled = data["zenex_enabled"]
                            save_local_data()
                    except Exception as e:
                        pass
                    
                    if target_msg_id: edit_message(chat_id, target_msg_id, "⏳ <b>Syncing SQLite data to Firebase... Please wait.</b>")
                    migrate_sqlite_to_firebase()
                    
                    if target_msg_id: edit_message(chat_id, target_msg_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())
                    send_message(chat_id, "✅ <b>Firebase successfully connected & Synced!</b>")
                except Exception as e:
                    if target_msg_id: edit_message(chat_id, target_msg_id, f"❌ <b>Failed to connect to Firebase:</b>\n<code>{html.escape(str(e))}</code>", reply_markup=get_back_only_keyboard())
            except Exception:
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚠️ <b>Invalid JSON format. Please upload the .json file directly.</b>", reply_markup=get_back_only_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif isinstance(state, str) and state.startswith("waiting_withdraw_amount_"):
            method = state[24:]
            user_data = get_user(user_id)
            bal = user_data.get("balance", 0)
            min_w = bot_settings.get("min_withdraw", 10.0)
            
            try:
                amount = float(text.strip())
                if amount < min_w:
                    if target_msg_id: edit_message(chat_id, target_msg_id, f"❌ <b>Minimum withdraw is {min_w} BDT.</b>\nTry again:", reply_markup=get_back_only_keyboard())
                elif amount > bal:
                    if target_msg_id: edit_message(chat_id, target_msg_id, f"❌ <b>Insufficient balance! You only have {bal:.2f} BDT.</b>\nTry again:", reply_markup=get_back_only_keyboard())
                else:
                    user_states[user_id] = {"state": f"waiting_withdraw_number_{method}_{amount}", "msg_id": target_msg_id}
                    if target_msg_id: edit_message(chat_id, target_msg_id, f"✅ <b>Amount Set: {amount:.2f} BDT</b>\n\n💳 <b>Method:</b> {method}\n💬 <b>{'Now send your USDT BEP20 wallet address (starts with 0x):' if is_usdt_method(method) else f'Now send your {method} account number:'}</b>", reply_markup=get_back_only_keyboard())
            except ValueError:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid amount. Send numbers only.</b>\nTry again:", reply_markup=get_back_only_keyboard())
            delete_message(chat_id, message_id)
            return

        elif isinstance(state, str) and state.startswith("waiting_withdraw_number_"):
            parts = state.split("_")
            method = parts[3]
            amount = float(parts[4])
            
            user_data = get_user(user_id)
            bal = user_data.get("balance", 0)
            
            if bal < amount:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Insufficient balance!</b>", reply_markup=get_main_keyboard(user_id))
            else:
                account_number = text.strip()
                if is_usdt_method(method) and not valid_usdt_address(account_number):
                    if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid BEP20 address.</b>\nIt must start with <code>0x</code> and be 42 characters long.\nSend again:", reply_markup=get_back_only_keyboard())
                    delete_message(chat_id, message_id)
                    return
                update_user_stats(user_id, -amount, 0)

                bot_settings["wd_counter"] = int(bot_settings.get("wd_counter", 100000)) + 1
                wid = str(bot_settings["wd_counter"])
                w_req = {"uid": user_id, "name": first_name, "amount": amount, "method": method,
                         "account": account_number, "ts": int(time.time())}
                bot_settings["pending_withdrawals"][wid] = w_req
                save_local_data()

                w_group = bot_settings.get("w_group", "")
                if w_group:
                    w_msg = wd_admin_text(wid, w_req)
                    _old_unused = (
                        f"<tg-emoji emoji-id=\"5420396762189831222\">🆕</tg-emoji> <b>NEW WITHDRAW REQUEST</b>\n"
                        f"━━━━━━━━━━━━━━━━━\n"
                        f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>User:</b> <a href='tg://user?id={user_id}'>{html.escape(first_name)}</a>\n"
                        f"— — — — — — — — — —\n"
                        f"<tg-emoji emoji-id=\"5226929552319594190\">🆔</tg-emoji> <b>ID:</b> <code>{user_id}</code>\n"
                        f"— — — — — — — — — —\n"
                        f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>Amount:</b> <b>{amount:.2f} BDT</b>\n"
                        f"— — — — — — — — — —\n"
                        f"<tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>Method:</b> {method}\n"
                        f"— — — — — — — — — —\n"
                        f"<tg-emoji emoji-id=\"5337132498965010628\">📞</tg-emoji> <b>Number:</b> <code>{account_number}</code>\n"
                        f"━━━━━━━━━━━━━━━━━"
                    )
                    
                    w_markup = {
                        "inline_keyboard": [
                            [
                                {"text": "APPROVE", "icon_custom_emoji_id": "5352694861990501856", "callback_data": f"admin_w_approve_{wid}", "style": "success"},
                                {"text": "REJECT", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"admin_w_reject_{wid}", "style": "danger"}
                            ]
                        ]
                    }
                    res_w = send_message(w_group, w_msg, reply_markup=w_markup)
                    try:
                        if res_w and res_w.get("ok"):
                            bot_settings["pending_withdrawals"][wid]["gchat"] = res_w["result"]["chat"]["id"]
                            bot_settings["pending_withdrawals"][wid]["gmsg"] = res_w["result"]["message_id"]
                            save_local_data()
                    except Exception: pass
                
                success_msg = (
                    f"━━━━━━━━━━━━━━━━━\n"
                    f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>Amount:</b> {amount:.2f} BDT\n"
                    f"— — — — — — — — — —\n"
                    f"<tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>Method:</b> {method}\n"
                    f"— — — — — — — — — —\n"
                    f"<tg-emoji emoji-id=\"5337132498965010628\">📞</tg-emoji> <b>Number:</b> <code>{account_number}</code>\n"
                    f"━━━━━━━━━━━━━━━━━"
                )
                if target_msg_id:
                    delete_message(chat_id, target_msg_id)
                send_message(chat_id, success_msg, reply_markup=get_main_keyboard(user_id))
                    
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state == "waiting_dxa_ref_r":
            try:
                bot_settings["refer_reward"] = float(text.strip())
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state == "waiting_dxa_usdt_rate":
            try:
                rate = float(text.strip())
                if rate > 0:
                    bot_settings["usdt_rate"] = rate
                    save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

        elif state == "waiting_dxa_min_w":
            try:
                bot_settings["min_withdraw"] = float(text.strip())
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_dxa_cool":
            try:
                bot_settings["cooldown"] = int(text.strip())
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_dxa_num_req":
            try:
                bot_settings["num_req"] = int(text.strip())
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_w_method":
            bot_settings["w_methods"].append(text.strip())
            save_local_data()
            if target_msg_id: edit_message(chat_id, target_msg_id, "💳 <b>WITHDRAW METHODS</b>\nManage methods below:", reply_markup=dxa_manage_w_methods_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_dxa_def_rate":
            try:
                bot_settings["otp_default_rate"] = float(text.strip())
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "💰 <b>OTP REWARD CONTROL</b>\nManage rates below:", reply_markup=dxa_otp_control_keyboard())
            except ValueError: pass
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_dxa_srv_rate":
            try:
                parts = text.split("-")
                srv_name = parts[0].strip()
                srv_rate = float(parts[1].strip())
                bot_settings["otp_service_rates"][srv_name] = srv_rate
                save_local_data()
                if target_msg_id: edit_message(chat_id, target_msg_id, "💰 <b>OTP REWARD CONTROL</b>\nManage rates below:", reply_markup=dxa_otp_control_keyboard())
            except Exception:
                send_message(chat_id, "❌ Invalid format. Use: ServiceName - Rate (e.g. Telegram - 5.0)")
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif state == "waiting_uc_id":
            try:
                target_uid = int(text.strip())
                target_data = get_user(target_uid)
                
                if target_data:
                    safe_name = html.escape(str(target_data.get('first_name', 'User')))
                    total_otps = target_data.get('total_otps', 0)
                    msg = (
                        f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>USER PROFILE</b>\n"
                        f"━━━━━━━━━━━━━━━━━\n"
                        f"<b>Name:</b> {safe_name}\n"
                        f"<b>ID:</b> <code>{target_uid}</code>\n"
                        f"<b>Balance:</b> {target_data.get('balance', 0):.2f} BDT\n"
                        f"<b>Total OTPs:</b> {total_otps}\n"
                        f"<b>Total Invites:</b> {target_data.get('total_invites', 0)}\n"
                        f"━━━━━━━━━━━━━━━━━"
                    )
                    if target_msg_id: edit_message(chat_id, target_msg_id, msg, reply_markup=get_user_profile_keyboard(target_uid))
                else:
                    if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>User not found in database!</b>", reply_markup=get_user_control_keyboard())
            except ValueError:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid User ID format!</b>", reply_markup=get_user_control_keyboard())
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return
            
        elif isinstance(state, str) and state.startswith("waiting_uc_balance_"):
            target_uid = int(state[19:])
            try:
                amount_to_add = float(text.strip())
                update_user_stats(target_uid, amount_to_add, 0)
                
                target_data = get_user(target_uid)
                msg = (
                    f"✅ <b>Balance Updated Successfully!</b>\n\n"
                    f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>Name:</b> {html.escape(target_data['first_name'])}\n"
                    f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>New Balance:</b> {target_data['balance']:.2f} BDT"
                )
                if target_msg_id: edit_message(chat_id, target_msg_id, msg, reply_markup=get_user_profile_keyboard(target_uid))
            except ValueError:
                if target_msg_id: edit_message(chat_id, target_msg_id, "❌ <b>Invalid amount format! Use numbers (e.g. 50 or -10).</b>", reply_markup=get_user_profile_keyboard(target_uid))
            del user_states[user_id]
            delete_message(chat_id, message_id)
            return

    if user_id in tm_states and text not in MAIN_BUTTON_LABELS and not text.startswith("/") and message.get("text"):
        st = tm_states.pop(user_id)
        uname = text.strip().lower()
        delete_message(chat_id, message_id)
        if not re.fullmatch(r"[a-z0-9._-]{3,30}", uname):
            tm_states[user_id] = st
            send_message(chat_id, "⚠️ <b>Invalid username.</b>\nUse 3-30 characters: a-z, 0-9, dot, dash, underscore.\nSend again:",
                         reply_markup={"inline_keyboard": [[{"text": "◀️ Cancel", "callback_data": "tm_cancel", "style": "danger"}]]})
            return
        ok, res = tm_create(user_id, uname, st["domain"])
        if ok: view = tm_mail_view(user_id, note="✅ <b>Mail created!</b>\n\n")
        else: view = tm_menu_view_for(user_id, note=res + "\n\n")
        if st.get("msg_id"): edit_message(chat_id, st["msg_id"], view[0], reply_markup=view[1])
        else: send_message(chat_id, view[0], reply_markup=view[1])
        return

    if user_id in tool_states and text not in MAIN_BUTTON_LABELS and not text.startswith("/") and message.get("text"):
        handle_2fa_key_input(chat_id, user_id, message_id, text)
        return

    if text in MAIN_BUTTON_LABELS:
        tool_states.pop(user_id, None)
        tm_states.pop(user_id, None)
        if user_id in user_states: del user_states[user_id]

    # 🌟 চেক করা হচ্ছে ইউজার আগে থেকেই ডাটাবেসে আছে কি না
    is_new_user = (get_user(user_id) is None)

    add_user(user_id, first_name)
    user_data = get_user(user_id)

    if text.startswith("/start"):
        parts = text.split()
        if len(parts) > 1:
            param = parts[1]
            if param.startswith("alloc_"):
                try:
                    _, req_range, req_sid = param.split("_", 2)
                    
                    last_req = user_cooldowns.get(user_id, 0)
                    now = time.time()
                    if now - last_req < bot_settings.get("cooldown", 0):
                        send_message(chat_id, f"⌛ <b>Please wait {int(bot_settings['cooldown'] - (now - last_req))} seconds before requesting again.</b>")
                        return
                    user_cooldowns[user_id] = now
                    
                    # 🌟 মেসেজ পাঠিয়ে মেসেজ আইডি ক্যাচ করা
                    wait_msg = send_message(chat_id, f"⏳ <b>Fetching number for {req_sid.title().replace('_', ' ')}...</b>")
                    
                    msg, markup = get_number_allocation_content(req_sid, req_range, user_id=user_id)
                    
                    # 🌟 নতুন মেসেজ না দিয়ে আগেরটাতেই এডিট করা
                    if wait_msg and "result" in wait_msg:
                        edit_message(chat_id, wait_msg["result"]["message_id"], msg, reply_markup=markup)
                    else:
                        send_message(chat_id, msg, reply_markup=markup)
                    return
                except Exception:
                    pass
            else:
                try:
                    inviter_id = int(param)
                    # 🌟 শুধুমাত্র নতুন ইউজার হলেই রেফারেল কাউন্ট হবে!
                    if is_new_user and inviter_id != user_id and get_user(inviter_id):
                        ref_amount = bot_settings.get("refer_reward", 0.2)
                        update_user_stats(inviter_id, ref_amount, 1)
                        send_message(inviter_id, f"🎉 <b>New Referral!</b>\nSomeone joined using your link. You received {ref_amount} BDT.")
                except ValueError: pass
        send_welcome(chat_id, user_id, first_name)

    elif text.startswith("/prf"):
        web_sync.handle_prf(chat_id, user_id, text)
        
    elif text == "Get Number":
        msg, markup = get_services_content()
        if markup:
            send_message(chat_id, msg, reply_markup=markup)
        else:
            send_message(chat_id, msg)
        
    elif text in ("LIVE TRAFFIC", "/traffic"):
        msg, markup = get_live_traffic_content()
        send_message(chat_id, msg, reply_markup=markup)

    elif text.split("@")[0] == "/help":
        link = str(bot_settings.get("support_link") or "").strip()
        if link.startswith("@"): link = "https://t.me/" + link[1:]
        elif link and not link.startswith(("http://", "https://", "tg://")): link = "https://" + link
        if link:
            send_message(chat_id, "💬 <b>Contact us for any help:</b>", reply_markup={"inline_keyboard": [[{"text": "Support", "url": link, "style": "primary"}]]})
        else:
            send_message(chat_id, "💬 <b>Support is not available right now.</b>")
            
    elif text == "INVITE FRIEND":
        invite_link = f"https://t.me/{BOT_USERNAME}?start={user_id}"
        ref_reward = bot_settings.get("refer_reward", 0.2)
        msg = (
            f"━━━━━━━━━━━━━━━━━\n"
            f"<tg-emoji emoji-id=\"5420145051336485498\">👥</tg-emoji> <b>Referral Program</b>\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"<tg-emoji emoji-id=\"5420517437885943844\">🔗</tg-emoji> <b>Your Invite Link:</b>\n"
            f"<code>{invite_link}</code>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5420396762189831222\">🎁</tg-emoji> <b>PER INVITE : {ref_reward} TK</b>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5353032893096567467\">📊</tg-emoji> <b>Total Invites:</b> {user_data['total_invites']}\n"
            f"━━━━━━━━━━━━━━━━━"
        )
        send_message(chat_id, msg, reply_markup={"inline_keyboard": [[{"text": "COPY LINK", "icon_custom_emoji_id": "5379889727325350343", "copy_text": {"text": invite_link}, "style": "success"}]]})
        
    elif text == "WALLET":
        wallet_txt = (
            f"<tg-emoji emoji-id=\"5429105001655999635\">💰</tg-emoji> <b>YOUR WALLET</b>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>NAME :</b> {html.escape(str(first_name))}\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5226929552319594190\">🆔</tg-emoji> <b>ID :</b> <code>{user_id}</code>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>BALANCE : {user_data['balance']:.2f} BDT</b>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>WITHDRAWAL METHODS :</b>"
        )
        kb = {"inline_keyboard": []}
        for method in bot_settings.get("w_methods", []):
            kb["inline_keyboard"].append([{"text": method, "icon_custom_emoji_id": "5431783519355444455", "callback_data": f"user_withdraw_{method}", "style": "primary"}])
        send_message(chat_id, wallet_txt, reply_markup=kb)
        
    elif text == "LEADERBOARD":
        send_message(chat_id, get_leaderboard_text(), reply_markup=get_leaderboard_keyboard())

    elif text == "OWNER PANEL":
        if user_id == ADMIN_ID:
            send_message(chat_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())
        else:
            send_message(chat_id, "⚠️ <b>Access Denied!</b>\nThis menu is restricted to the admin.")

    elif text == "2FA Online":
        txt, kb = twofa_menu_view()
        send_message(chat_id, txt, reply_markup=kb)

    elif text == "Get Temp Mail":
        if not tm_ready():
            send_message(chat_id, "⚠️ <b>Temp Mail is not available right now.</b>")
        elif str(user_id) in tm_active:
            txt, kb = tm_mail_view(user_id)
            send_message(chat_id, txt, reply_markup=kb)
        else:
            txt, kb = tm_menu_view_for(user_id)
            send_message(chat_id, txt, reply_markup=kb)

def handle_callback(callback_query):
    global voltx_enabled, zenex_keys, zenex_enabled
    global augestel_key, augestel_enabled, lamix_key, lamix_enabled
    global user_states, voltx_auto_mode, current_db_mode, force_join_status, force_join_channels, voltx_keys, otp_forward_groups, bot_settings
    query_id = callback_query["id"]
    user_id = callback_query["from"]["id"]
    data = callback_query["data"]
    chat_id = callback_query["message"]["chat"]["id"]
    message_id = callback_query["message"]["message_id"]

    if data == "check_fj_joined":
        if is_user_joined(user_id):
            delete_message(chat_id, message_id)
            send_message(chat_id, "✅ <b>Thank you for joining! You can now use the bot.</b>", reply_markup=get_main_keyboard(user_id))
        else:
            answer_callback_query(query_id, "❌ You haven't joined all channels!", show_alert=True)
        return

    if not is_user_joined(user_id):
        answer_callback_query(query_id, "Join channels first!", show_alert=True)
        return

    # ===== TEMP MAIL callbacks (users) =====
    if data.startswith("tm_"):
        if not tm_ready():
            answer_callback_query(query_id, "Temp Mail is not available right now.", show_alert=True)
            return
        def tm_show(view, toast=""):
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
            answer_callback_query(query_id, toast)
        if data == "tm_menu":
            tm_states.pop(user_id, None)
            tm_show(tm_mail_view(user_id) if str(user_id) in tm_active else tm_menu_view_for(user_id))
        elif data == "tm_cancel":
            tm_states.pop(user_id, None)
            tm_show(tm_mail_view(user_id) if str(user_id) in tm_active else tm_menu_view_for(user_id), "Cancelled")
        elif data == "tm_rand":
            ok, wait = tm_check_limit(user_id)
            if not ok:
                answer_callback_query(query_id, f"Limit reached. Try again in {tm_fmt_wait(wait)}", show_alert=True)
                return
            answer_callback_query(query_id, "Creating...")
            ok, res = tm_create(user_id)
            view = tm_mail_view(user_id, note="✅ <b>Mail created!</b>\n\n") if ok else tm_menu_view_for(user_id, note=res + "\n\n")
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        elif data == "tm_cust":
            ok, wait = tm_check_limit(user_id)
            if not ok:
                answer_callback_query(query_id, f"Limit reached. Try again in {tm_fmt_wait(wait)}", show_alert=True)
                return
            answer_callback_query(query_id, "Loading domains...")
            domains, err = tm_get_domains()
            if not domains:
                view = tm_menu_view_for(user_id, note=f"❌ <b>{html.escape(str(err))}</b>\n\n")
                edit_message(chat_id, message_id, view[0], reply_markup=view[1])
            else:
                tm_domain_cache[user_id] = domains
                view = tm_domains_view(domains)
                edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        elif data.startswith("tm_dom_"):
            domains = tm_domain_cache.get(user_id) or []
            try: dm = domains[int(data.split("_")[2])]
            except Exception: dm = None
            if not dm:
                answer_callback_query(query_id, "Session expired - open Custom Mail again", show_alert=True)
                return
            tm_states[user_id] = {"domain": dm, "msg_id": message_id}
            if user_id in tool_states: tool_states.pop(user_id, None)
            edit_message(chat_id, message_id,
                         f"✏️ <b>CUSTOM MAIL</b>\nDomain: <code>@{html.escape(dm)}</code>\n\nSend the username you want (3-30 chars: a-z, 0-9, . _ -):",
                         reply_markup={"inline_keyboard": [[{"text": "◀️ Cancel", "callback_data": "tm_cancel", "style": "danger"}]]})
            answer_callback_query(query_id)
        elif data == "tm_ref":
            rec = tm_active.get(str(user_id))
            if not rec:
                tm_show(tm_menu_view_for(user_id), "No active mail")
                return
            if time.time() - tm_last_refresh.get(user_id, 0) < 3:
                answer_callback_query(query_id, "Please wait a moment...")
                return
            tm_last_refresh[user_id] = time.time()
            new, total, err = tm_check_inbox(str(user_id), rec, dead_after=1)
            if err == "DEAD":
                with tm_lock: tm_active.pop(str(user_id), None)
                tm_save()
                tm_show(tm_menu_view_for(user_id, note="⚠️ <b>That mail is no longer valid.</b> Please create a new one.\n\n"), "Mail expired")
            elif err:
                answer_callback_query(query_id, f"Error: {err[:150]}", show_alert=True)
            else:
                edit_message(chat_id, message_id, *tm_mail_view(user_id)[:1], reply_markup=tm_mail_view(user_id)[1])
                answer_callback_query(query_id, f"{new} new email(s)" if new else f"No new emails (inbox: {total})")
        elif data == "tm_del":
            with tm_lock: old_rec = tm_active.pop(str(user_id), None)
            tm_save()
            tm_delete_account(old_rec)
            tm_show(tm_menu_view_for(user_id, note="🗑 <b>Mail deleted.</b>\n\n"), "Deleted")
        else:
            answer_callback_query(query_id)
        return

    # ===== 2FA ONLINE callbacks =====
    if data == "tfa_start" or data == "tfa_new":
        tool_states[user_id] = "2fa_key"
        txt, kb = twofa_enter_key_view()
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id)
        return
    if data == "tfa_cancel":
        tool_states.pop(user_id, None)
        txt, kb = twofa_menu_view()
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id, "Cancelled")
        return
    if data == "tfa_refresh":
        secret = twofa_keys.get(user_id)
        if not secret:
            tool_states[user_id] = "2fa_key"
            txt, kb = twofa_enter_key_view()
            edit_message(chat_id, message_id, txt, reply_markup=kb)
            answer_callback_query(query_id, "Send your key again")
            return
        txt, kb = twofa_code_view(secret)
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id, "Refreshed!")
        return

    if data == "refresh_traffic":
        msg, markup = get_live_traffic_content()
        edit_message(chat_id, message_id, msg, reply_markup=markup)
        answer_callback_query(query_id, "Traffic Refreshed!")
        return

    if data == "back_to_services":
        msg, markup = get_services_content()
        edit_message(chat_id, message_id, msg, reply_markup=markup)
        answer_callback_query(query_id)
        return

    if data == "tgl_cc":
        la = last_alloc.get(user_id)
        if not la:
            answer_callback_query(query_id, "Session expired. Press Change.", show_alert=True)
            return
        lst = bot_settings.setdefault("no_cc_users", [])
        if user_id in lst: lst.remove(user_id)
        else: lst.append(user_id)
        save_local_data()
        msg, kb = render_allocation(user_id, la["sid"], la["c_code"], la["full_sid"], la["numbers"])
        edit_message(chat_id, message_id, msg, reply_markup=kb)
        answer_callback_query(query_id, "Country code removed" if user_id in lst else "Country code added")
        return

    if data.startswith("srv_"):
        sid_short = data[4:]
        msg, markup, err = get_countries_content(sid_short)
        if err: answer_callback_query(query_id, err, show_alert=True)
        else:
            edit_message(chat_id, message_id, msg, reply_markup=markup)
            answer_callback_query(query_id)
        return

    if data.startswith("cc_"):
        parts = data.split("_")
        sid_short = parts[1]
        c_code = parts[2]
        
        last_req = user_cooldowns.get(user_id, 0)
        now = time.time()
        if now - last_req < bot_settings.get("cooldown", 0):
            answer_callback_query(query_id, f"Please wait {int(bot_settings['cooldown'] - (now - last_req))} seconds.", show_alert=True)
            return
        user_cooldowns[user_id] = now
        
        answer_callback_query(query_id, "Allocating number...")
        edit_message(chat_id, message_id, f"⏳ <b>Fetching best top range and allocating number...</b>")
        
        msg, markup = get_number_allocation_content(sid_short, c_code, user_id=user_id)
        
        edit_message(chat_id, message_id, msg, reply_markup=markup)
        return

    if data == "refresh_leaderboard":
        edit_message(chat_id, message_id, get_leaderboard_text(), reply_markup=get_leaderboard_keyboard())
        answer_callback_query(query_id, "Leaderboard Refreshed!")
        return

    if data.startswith("user_withdraw_"):
        method = data[14:]
        user_data = get_user(user_id)
        bal = user_data.get("balance", 0)
        min_w = bot_settings.get("min_withdraw", 10.0)
        
        if bal < min_w:
            answer_callback_query(query_id, f"❌ Minimum withdraw is {min_w} BDT. You have {bal:.2f} BDT.", show_alert=True)
            return
            
        user_states[user_id] = {"state": f"waiting_withdraw_amount_{method}", "msg_id": message_id}
        edit_message(chat_id, message_id, f"💳 <b>Withdraw via {method}</b>\n\n💵 Your Balance: {bal:.2f} BDT\n💬 <b>Enter the amount you want to withdraw:</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
        return

    if data == "user_cancel":
        if user_id in user_states: del user_states[user_id]
        delete_message(chat_id, message_id)
        send_message(chat_id, "❌ Action Cancelled.", reply_markup=get_main_keyboard(user_id))
        answer_callback_query(query_id)
        return

    # Admin Operations Only
    if user_id != ADMIN_ID:
        answer_callback_query(query_id, "Access Denied!", show_alert=True)
        return
        
    if data.startswith("admin_w_approve_") or data.startswith("admin_w_reject_"):
        _p = data.split("_")
        if len(_p) == 4:                                   # new format: admin_w_<action>_<wid>
            action, wid = _p[2], _p[3]
            p = bot_settings["pending_withdrawals"].get(wid)
            if not p:
                answer_callback_query(query_id, "Request not found / already processed.", show_alert=True)
                return
            if action == "approve":
                user_states[user_id] = {"state": "waiting_wd_link", "wid": wid, "gchat": chat_id, "gmsg": message_id}
                send_message(ADMIN_ID, f"🔗 <b>Send the transaction link for</b> <code>#{wid}</code>\n"
                                       f"{html.escape(wd_amount_text(p['method'], p['amount']))} → {html.escape(wd_method_label(p['method']))}\n\n"
                                       f"<i>This link becomes the “Check Transactions” button in the proof post.</i>",
                             reply_markup=get_back_only_keyboard())
                answer_callback_query(query_id, "Link chaiche - bot inbox-e link pathan", show_alert=True)
            else:
                bot_settings["pending_withdrawals"].pop(wid, None)
                update_user_stats(p["uid"], p["amount"], 0)
                save_local_data()
                send_message(p["uid"], f"<tg-emoji emoji-id=\"5336944168944047463\">⚠️</tg-emoji> <b>Withdrawal Rejected!</b>\n"
                                       f"#{wid} | {p['amount']:.2f} BDT to <code>{html.escape(mask_account(p['account']))}</code> was rejected and refunded.")
                edit_message(chat_id, message_id, wd_admin_text(wid, p, "WITHDRAW REJECTED"),
                             reply_markup={"inline_keyboard": [[{"text": "REJECTED BY ADMIN", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "ignore_action", "style": "danger"}]]})
                answer_callback_query(query_id, "Request Rejected & refunded!")
            return

    if data.startswith("admin_w_approve_") or data.startswith("admin_w_reject_"):
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "⚠️ Access Denied! You cannot perform this action.", show_alert=True)
            return

        parts = data.split("_")
        action = parts[2]
        req_user_id = int(parts[3])
        amount = float(parts[4])
        acc_number = parts[5]
        
        masked_number = f"{acc_number[:3]}DXA{acc_number[-3:]}" if len(acc_number) >= 6 else acc_number
        
        msg_text = callback_query.get("message", {}).get("text", "")
        fname_match = re.search(r"User:\s*(.+)", msg_text)
        req_first_name = fname_match.group(1) if fname_match else "User"
        method_match = re.search(r"Method:\s*(.+)", msg_text)
        req_method = method_match.group(1) if method_match else "Unknown"
        
        if action == "approve":
            btn_text = "APPROVED BY ADMIN"
            btn_style = "success"
            btn_icon = "5352694861990501856"
            send_message(req_user_id, f"<tg-emoji emoji-id=\"5420396762189831222\">🎉</tg-emoji> <b>Withdrawal Approved!</b>\nYour request of {amount:.2f} BDT has been sent to <code>{masked_number}</code>.")
        else:
            btn_text = "REJECTED BY ADMIN"
            btn_style = "danger"
            btn_icon = "5420130255174145507"
            update_user_stats(req_user_id, amount, 0)
            send_message(req_user_id, f"<tg-emoji emoji-id=\"5336944168944047463\">⚠️</tg-emoji> <b>Withdrawal Rejected!</b>\nYour request of {amount:.2f} BDT to <code>{masked_number}</code> was rejected and refunded.")
            
        updated_msg = (
            f"<tg-emoji emoji-id=\"5420396762189831222\">🆕</tg-emoji> <b>WITHDRAW REQUEST PROCESSED</b>\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"<tg-emoji emoji-id=\"5352861489541714456\">👤</tg-emoji> <b>User:</b> <a href='tg://user?id={req_user_id}'>{html.escape(req_first_name)}</a>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5226929552319594190\">🆔</tg-emoji> <b>ID:</b> <code>{req_user_id}</code>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5429612421977253466\">💵</tg-emoji> <b>Amount:</b> <b>{amount:.2f} BDT</b>\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5190899075968441286\">💳</tg-emoji> <b>Method:</b> {req_method}\n"
            f"— — — — — — — — — —\n"
            f"<tg-emoji emoji-id=\"5431783519355444455\">📞</tg-emoji> <b>Number:</b> <code>{masked_number}</code>\n"
            f"━━━━━━━━━━━━━━━━━"
        )
        
        updated_markup = {
            "inline_keyboard": [
                [{"text": btn_text, "icon_custom_emoji_id": btn_icon, "callback_data": "ignore_action", "style": btn_style}]
            ]
        }
        
        edit_message(chat_id, message_id, updated_msg, reply_markup=updated_markup)
        answer_callback_query(query_id, f"Request {action.title()}d!")
        return

    # ===== Voltx Key Manager =====
    if data == "manage_voltx":
        edit_message(chat_id, message_id, "🔑 <b>VOLTX KEY SYSTEM</b>\nManage API Keys below:", reply_markup=get_voltx_keys_keyboard())
        answer_callback_query(query_id)
    elif data == "toggle_vk":
        voltx_auto_mode = not voltx_auto_mode
        save_local_data()
        edit_message(chat_id, message_id, "🔑 <b>VOLTX KEY SYSTEM</b>\nManage API Keys below:", reply_markup=get_voltx_keys_keyboard())
        answer_callback_query(query_id, f"Voltx Mode: {'ON' if voltx_auto_mode else 'OFF'}")
    elif data == "add_vk":
        user_states[user_id] = {"state": "waiting_vk_key", "msg_id": message_id}
        edit_message(chat_id, message_id, "🔑 <b>Please reply to this message with the new Voltx API Key.</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data.startswith("del_vk_"):
        idx = int(data[7:])
        if idx < len(voltx_keys): 
            if len(voltx_keys) > 1:
                voltx_keys.pop(idx)
                save_local_data()
                edit_message(chat_id, message_id, "🔑 <b>VOLTX KEY SYSTEM</b>\nManage API Keys below:", reply_markup=get_voltx_keys_keyboard())
                answer_callback_query(query_id, "Key Deleted!")
            else:
                answer_callback_query(query_id, "Cannot delete the only key!", show_alert=True)

    # ===== Zenex Key Manager =====
    if data in ("manage_zenex", "toggle_zx", "add_zk", "toggle_vx_enabled") or data.startswith("del_zk_"):
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "Admin only!", show_alert=True)
            return

    if data == "manage_zenex":
        edit_message(chat_id, message_id, get_zenex_panel_text(), reply_markup=get_zenex_keys_keyboard())
        answer_callback_query(query_id)
    elif data == "toggle_zx":
        zenex_enabled = not zenex_enabled
        save_local_data()
        edit_message(chat_id, message_id, get_zenex_panel_text(), reply_markup=get_zenex_keys_keyboard())
        answer_callback_query(query_id, f"Zenex: {'ON' if zenex_enabled else 'OFF'}")
    elif data == "add_zk":
        user_states[user_id] = {"state": "waiting_zk_key", "msg_id": message_id}
        edit_message(chat_id, message_id, "🔑 <b>Please reply to this message with the new Zenex API Key.</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data.startswith("del_zk_"):
        idx = int(data[7:])
        if idx < len(zenex_keys):
            zenex_keys.pop(idx)
            save_local_data()
            edit_message(chat_id, message_id, get_zenex_panel_text(), reply_markup=get_zenex_keys_keyboard())
            answer_callback_query(query_id, "Key Deleted!")
    elif data == "toggle_vx_enabled":
        voltx_enabled = not voltx_enabled
        save_local_data()
        edit_message(chat_id, message_id, "🔑 <b>VOLTX KEY SYSTEM</b>\nManage API Keys below:", reply_markup=get_voltx_keys_keyboard())
        answer_callback_query(query_id, f"Voltx Panel: {'ON' if voltx_enabled else 'OFF'}")

    # ===== Premium emoji switch =====
    if data == "toggle_premium":
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "Admin only!", show_alert=True)
            return
        bot_settings["premium_emoji"] = not bot_settings.get("premium_emoji", False)
        save_local_data()
        edit_message(chat_id, message_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())
        answer_callback_query(query_id, f"Premium Emoji: {'ON' if bot_settings['premium_emoji'] else 'OFF'}")
        return

    # ===== Emoji editor (admin) =====
    if data.startswith("emj_"):
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "Admin only!", show_alert=True)
            return
        act = data[4:]
        if act == "home":
            if user_id in user_states: del user_states[user_id]
            v = emj_home_view(); edit_message(chat_id, message_id, v[0], reply_markup=v[1])
        elif act == "add":
            user_states[user_id] = {"state": "waiting_emj_add", "msg_id": message_id}
            edit_message(chat_id, message_id, "➕ <b>ADD / CHANGE EMOJI</b>\n\n" + EMJ_HELP, reply_markup=emj_cancel_kb())
        elif act == "del":
            user_states[user_id] = {"state": "waiting_emj_del", "msg_id": message_id}
            edit_message(chat_id, message_id, "🗑 <b>REMOVE EMOJI</b>\n\nSend the emoji(s) to remove, e.g. <code>💌 ❤️</code>", reply_markup=emj_cancel_kb())
        elif act == "list":
            v = emj_list_view(); edit_message(chat_id, message_id, v[0], reply_markup=v[1])
        answer_callback_query(query_id)
        return

    # ===== TEMP MAIL settings (admin) =====
    if data.startswith("tma_"):
        def tma_show(view, toast=""):
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
            answer_callback_query(query_id, toast)
        if data == "tma_home": tma_show(tm_admin_view())
        elif data == "tma_tog":
            bot_settings["tm_enabled"] = not bot_settings.get("tm_enabled", True)
            save_local_data(); tma_show(tm_admin_view(), f"Temp Mail: {'ON' if bot_settings['tm_enabled'] else 'OFF'}")
        elif data == "tma_batch":
            user_states[user_id] = {"state": "waiting_tma_batch", "msg_id": message_id}
            edit_message(chat_id, message_id, "📦 <b>How many mails can a user create per round?</b> (e.g. 4)", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif data == "tma_cd":
            user_states[user_id] = {"state": "waiting_tma_cd", "msg_id": message_id}
            edit_message(chat_id, message_id, "⏱ <b>Cooldown in minutes after a round is used up?</b> (e.g. 5)", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif data == "tma_hist":
            answer_callback_query(query_id, "Loading...")
            view = tm_history_view()
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        else:
            answer_callback_query(query_id)
        return

    # ===== LAMIX panel (admin) =====
    if data.startswith("lx_"):
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "Admin only!", show_alert=True)
            return
        def lx_show(view, toast=""):
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
            answer_callback_query(query_id, toast)
        parts = data.split("_")          # e.g. lx_rgset_0_3
        act = parts[1]
        idx = [int(p) for p in parts[2:] if p.isdigit()]
        if act == "api": lx_show(lx_api_view())
        elif act == "tog":
            lamix_enabled = not lamix_enabled
            save_manual_data(); lx_show(lx_api_view(), f"LAMIX: {'ON' if lamix_enabled else 'OFF'}")
        elif act == "key":
            user_states[user_id] = {"state": "waiting_lx_key", "msg_id": message_id}
            edit_message(chat_id, message_id, "🔑 <b>Send the LAMIX API token.</b>", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif act in ("rgl", "rgr"):
            answer_callback_query(query_id, "Loading...")
            edit_message(chat_id, message_id, "⏳ <b>Loading ranges from LAMIX...</b>")
            view = lx_ranges_view(force=(act == "rgr"))
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        elif act == "rg" and idx: lx_show(lx_range_view(idx[0]))
        elif act == "rgs" and idx: lx_show(lx_range_service_view(idx[0]))
        elif act == "rgset" and len(idx) == 2 and idx[0] < len(lamix_range_index) and idx[1] < len(AG_SERVICES):
            r = lamix_range_index[idx[0]]
            lamix_range_meta[r] = {"service": AG_SERVICES[idx[1]], "enabled": True}
            lamix_sync_ranges(lamix_groups(lamix_cache["numbers"]))
            lx_show(lx_range_view(idx[0], note="✅ Service assigned, numbers added\n\n"), "Assigned & ON")
        elif act == "rgt" and idx and idx[0] < len(lamix_range_index):
            r = lamix_range_index[idx[0]]
            m = lamix_range_meta.get(r)
            if not m or not m.get("service"):
                answer_callback_query(query_id, "Assign a service first!", show_alert=True)
            else:
                m["enabled"] = not m.get("enabled")
                lamix_sync_ranges(lamix_groups(lamix_cache["numbers"]))
                lx_show(lx_range_view(idx[0]), f"Range {'ON' if m['enabled'] else 'OFF'}")
        elif act == "rgx" and idx and idx[0] < len(lamix_range_index):
            r = lamix_range_index[idx[0]]
            nums = lamix_groups(lamix_cache["numbers"]).get(r, [])
            if not nums:
                answer_callback_query(query_id, "No numbers (refresh the list)", show_alert=True)
            else:
                fname = re.sub(r"[^A-Za-z0-9_-]+", "_", r).strip("_") or "range"
                send_document(chat_id, f"{fname}.txt", "\n".join(nums), caption=f"{r} - {len(nums)} numbers")
                answer_callback_query(query_id, "File sent")
        elif act == "np":
            answer_callback_query(query_id, "Loading...")
            edit_message(chat_id, message_id, "⏳ <b>Loading from LAMIX...</b>")
            view = lx_numbers_view(idx[0] if idx else 0)
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        elif act == "msgs":
            answer_callback_query(query_id, "Loading...")
            edit_message(chat_id, message_id, "⏳ <b>Loading from LAMIX...</b>")
            view = lx_messages_view()
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        else:
            answer_callback_query(query_id)
        return

    # ===== Manual Numbers (admin) =====
    if data.startswith("mn_"):
        if user_id != ADMIN_ID:
            answer_callback_query(query_id, "Admin only!", show_alert=True)
            return
        def show(view, toast=""):
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
            answer_callback_query(query_id, toast)
        parts = data.split("_")          # e.g. mn_c_0_1
        act = parts[1]
        idx = [int(p) for p in parts[2:] if p.isdigit()]
        names = list(manual_stock.keys())
        if data == "mn_home": show(mn_home_view())
        elif act == "adds":
            user_states[user_id] = {"state": "waiting_mn_service", "msg_id": message_id}
            edit_message(chat_id, message_id, "➕ <b>Send the service name</b> (e.g. Facebook, Telegram, Instagram)", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif act == "s" and idx: show(mn_service_view(idx[0]))
        elif act == "dels" and idx and idx[0] < len(names):
            with manual_lock: manual_stock.pop(names[idx[0]], None)
            save_manual_data(); show(mn_home_view(), "Service deleted")
        elif act == "addc" and idx:
            user_states[user_id] = {"state": "waiting_mn_country", "msg_id": message_id, "si": idx[0]}
            edit_message(chat_id, message_id, "🌍 <b>Send the country dial code</b> (e.g. 880, 44, 1, 91)", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif act == "c" and len(idx) == 2: show(mn_country_view(idx[0], idx[1]))
        elif act == "up" and len(idx) == 2:
            user_states[user_id] = {"state": "waiting_mn_numbers", "msg_id": message_id, "si": idx[0], "ci": idx[1]}
            edit_message(chat_id, message_id, "📥 <b>Send a .txt file</b> (or paste the numbers) - one number per line.", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif act == "clr" and len(idx) == 2 and idx[0] < len(names):
            codes = list(manual_stock[names[idx[0]]].keys())
            if idx[1] < len(codes):
                with manual_lock: manual_stock[names[idx[0]]][codes[idx[1]]]["numbers"] = []
                save_manual_data()
            show(mn_country_view(idx[0], idx[1]), "Cleared")
        elif act == "delc" and len(idx) == 2 and idx[0] < len(names):
            codes = list(manual_stock[names[idx[0]]].keys())
            if idx[1] < len(codes):
                with manual_lock: manual_stock[names[idx[0]]].pop(codes[idx[1]], None)
                save_manual_data()
            show(mn_service_view(idx[0]), "Country deleted")
        elif act in ("rgl", "rgr"):
            answer_callback_query(query_id, "Loading...")
            edit_message(chat_id, message_id, "⏳ <b>Loading ranges from AugesTel...</b>")
            view = mn_ranges_view(force=(act == "rgr"))
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        elif act == "rg" and idx: show(mn_range_view(idx[0]))
        elif act == "rgs" and idx: show(mn_range_service_view(idx[0]))
        elif act == "rgset" and len(idx) == 2 and idx[0] < len(augestel_range_index) and idx[1] < len(AG_SERVICES):
            r = augestel_range_index[idx[0]]
            augestel_range_meta[r] = {"service": AG_SERVICES[idx[1]], "enabled": True}
            augestel_sync_ranges(augestel_groups(augestel_cache["numbers"]))
            show(mn_range_view(idx[0], note="✅ Service assigned, numbers added\n\n"), "Assigned & ON")
        elif act == "rgt" and idx and idx[0] < len(augestel_range_index):
            r = augestel_range_index[idx[0]]
            m = augestel_range_meta.get(r)
            if not m or not m.get("service"):
                answer_callback_query(query_id, "Assign a service first!", show_alert=True)
            else:
                m["enabled"] = not m.get("enabled")
                augestel_sync_ranges(augestel_groups(augestel_cache["numbers"]))
                show(mn_range_view(idx[0]), f"Range {'ON' if m['enabled'] else 'OFF'}")
        elif act == "rgx" and idx and idx[0] < len(augestel_range_index):
            r = augestel_range_index[idx[0]]
            nums = augestel_groups(augestel_cache["numbers"]).get(r, [])
            if not nums:
                answer_callback_query(query_id, "No numbers (refresh the list)", show_alert=True)
            else:
                fname = re.sub(r"[^A-Za-z0-9_-]+", "_", r).strip("_") or "range"
                send_document(chat_id, f"{fname}.txt", "\n".join(nums), caption=f"{r} - {len(nums)} numbers")
                answer_callback_query(query_id, "File sent")
        elif data == "mn_api": show(mn_api_view())
        elif data == "mn_tog":
            augestel_enabled = not augestel_enabled
            save_manual_data(); show(mn_api_view(), f"AugesTel: {'ON' if augestel_enabled else 'OFF'}")
        elif data == "mn_key":
            user_states[user_id] = {"state": "waiting_mn_key", "msg_id": message_id}
            edit_message(chat_id, message_id, "🔑 <b>Send the AugesTel API key.</b>", reply_markup=get_back_only_keyboard())
            answer_callback_query(query_id)
        elif data in ("mn_nums", "mn_stats", "mn_msgs"):
            answer_callback_query(query_id, "Loading...")
            edit_message(chat_id, message_id, "⏳ <b>Loading from AugesTel...</b>")
            view = mn_info_view({"mn_nums": "nums", "mn_stats": "stats", "mn_msgs": "msgs"}[data])
            edit_message(chat_id, message_id, view[0], reply_markup=view[1])
        else:
            answer_callback_query(query_id)
        return

    # ===== Force Join Manager =====
    elif data == "manage_fj":
        edit_message(chat_id, message_id, "🔗 <b>FORCE JOIN SYSTEM</b>\nManage channels below:", reply_markup=get_force_join_keyboard())
        answer_callback_query(query_id)
    elif data == "toggle_fj":
        force_join_status = not force_join_status
        save_local_data()
        edit_message(chat_id, message_id, "🔗 <b>FORCE JOIN SYSTEM</b>\nManage channels below:", reply_markup=get_force_join_keyboard())
        answer_callback_query(query_id, f"Force Join: {'ON' if force_join_status else 'OFF'}")
    elif data == "add_fj":
        user_states[user_id] = {"state": "waiting_fj_channel", "msg_id": message_id}
        select_kb = {"keyboard": [[{"text": "Select Force Join Channel", "request_chat": {"request_id": 3, "chat_is_channel": True}}], [{"text": "🔙 BACK"}]], "resize_keyboard": True, "one_time_keyboard": True}
        send_message(chat_id, "👇 <b>Select Channel from below:</b>\n<i>(Make sure bot is an admin there)</i>", reply_markup=select_kb)
        answer_callback_query(query_id)
    elif data.startswith("del_fj_"):
        idx = int(data[7:])
        if idx < len(force_join_channels): force_join_channels.pop(idx)
        save_local_data()
        edit_message(chat_id, message_id, "🔗 <b>FORCE JOIN SYSTEM</b>\nManage channels below:", reply_markup=get_force_join_keyboard())
        answer_callback_query(query_id, "Channel Deleted!")

    # ===== OTP Group Manager =====
    elif data == "manage_otp_group":
        edit_message(chat_id, message_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
        answer_callback_query(query_id)
    elif data == "wm_menu":
        txt, kb = wm_menu_view()
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id)
    elif data.startswith("wm_slot_"):
        txt, kb = wm_slot_view(int(data[8:]))
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id)
    elif data.startswith("wm_text_"):
        n = int(data[8:])
        user_states[user_id] = {"state": "waiting_wm_text", "slot": n, "msg_id": message_id}
        edit_message(chat_id, message_id, f"✏️ <b>Send the text for Welcome Message {n}</b>\nUse <code>{{name}}</code> for the user's name.", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data.startswith("wm_btn_"):
        n = int(data[7:])
        user_states[user_id] = {"state": "waiting_wm_button", "slot": n, "msg_id": message_id}
        edit_message(chat_id, message_id, f"🔘 <b>Send buttons for Welcome Message {n}</b>\nOne per line:\n<code>Button Text | https://link</code>\n(max 6 buttons)", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data.startswith("wm_clr_"):
        n = int(data[7:])
        ws = wm_slots(); ws[n - 1]["buttons"] = []
        bot_settings["welcome_msgs"] = ws; save_local_data()
        txt, kb = wm_slot_view(n)
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id, "Buttons cleared")
    elif data.startswith("wm_del_"):
        n = int(data[7:])
        ws = wm_slots(); ws[n - 1] = {"text": "", "buttons": []}
        bot_settings["welcome_msgs"] = ws; save_local_data()
        txt, kb = wm_slot_view(n)
        edit_message(chat_id, message_id, txt, reply_markup=kb)
        answer_callback_query(query_id, "Message deleted")
    elif data.startswith("wm_prev_"):
        n = int(data[8:])
        txt, inline = build_welcome(wm_slots()[n - 1], "Admin")
        send_message(chat_id, txt, reply_markup=inline)
        answer_callback_query(query_id, "Preview sent")
    elif data == "toggle_otp_format":
        bot_settings["otp_format"] = "mini" if bot_settings.get("otp_format", "mini") == "big" else "big"
        save_local_data()
        edit_message(chat_id, message_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
        answer_callback_query(query_id, f"OTP Format: {bot_settings['otp_format'].upper()}")
    elif data == "send_fake_otp":
        if not otp_forward_groups:
            answer_callback_query(query_id, "Set an OTP group first!", show_alert=True)
        else:
            ok = send_fake_otp()
            answer_callback_query(query_id, "Fake OTP sent ✅" if ok else "Failed to send ❌ (is the bot admin in the group?)")
    elif data == "add_otp_group":
        user_states[user_id] = {"state": "waiting_otp_group", "msg_id": message_id}
        select_kb = {"keyboard": [[{"text": "Select OTP Group", "request_chat": {"request_id": 1, "chat_is_channel": False}}], [{"text": "🔙 BACK"}]], "resize_keyboard": True, "one_time_keyboard": True}
        send_message(chat_id, "👇 <b>Select OTP Group from below:</b>", reply_markup=select_kb)
        answer_callback_query(query_id)
    elif data.startswith("del_otp_group_"):
        idx = int(data[14:])
        if idx < len(otp_forward_groups): otp_forward_groups.pop(idx)
        save_local_data()
        edit_message(chat_id, message_id, "🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:", reply_markup=get_otp_group_keyboard())
        answer_callback_query(query_id, "Group Deleted!")
    elif data == "edit_otp_link":
        user_states[user_id] = {"state": "waiting_otp_link", "msg_id": message_id}
        edit_message(chat_id, message_id, "🔗 <b>Please send the new URL for the inline button attached to forwarded OTPs.</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "edit_main_channel":
        user_states[user_id] = {"state": "waiting_main_channel_link", "msg_id": message_id}
        edit_message(chat_id, message_id, "🔗 <b>Please send the URL for the MAIN CHANNEL inline button.</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)

    # ===== DXA Control Panel =====
    elif data == "dxa_control":
        edit_message(chat_id, message_id, "⚙️ <b>DXA CONTROL PANEL</b>\nManage core bot configurations:", reply_markup=dxa_control_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_min_w":
        user_states[user_id] = {"state": "waiting_dxa_min_w", "msg_id": message_id}
        edit_message(chat_id, message_id, "💸 <b>Enter new Minimum Withdraw Amount (e.g. 50):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_ref_r":
        user_states[user_id] = {"state": "waiting_dxa_ref_r", "msg_id": message_id}
        edit_message(chat_id, message_id, "💸 <b>Enter new Referral Reward Amount (e.g. 5.0):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_otp_control":
        edit_message(chat_id, message_id, "💰 <b>OTP REWARD CONTROL</b>\nManage rates below:", reply_markup=dxa_otp_control_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_def_rate":
        user_states[user_id] = {"state": "waiting_dxa_def_rate", "msg_id": message_id}
        edit_message(chat_id, message_id, "💰 <b>Enter new Default OTP Rate (e.g. 0.5):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
        
    elif data.startswith("del_srv_rate_"):
        srv_name = data[13:]
        if srv_name in bot_settings["otp_service_rates"]:
            del bot_settings["otp_service_rates"][srv_name]
            save_local_data()
        edit_message(chat_id, message_id, "💰 <b>OTP REWARD CONTROL</b>\nManage rates below:", reply_markup=dxa_otp_control_keyboard())
        answer_callback_query(query_id, f"Rate for {srv_name} deleted!")
    elif data == "dxa_srv_rate":
        user_states[user_id] = {"state": "waiting_dxa_srv_rate", "msg_id": message_id}
        edit_message(chat_id, message_id, "💰 <b>Enter Specific Service Rate.</b>\nFormat: <code>ServiceName - Rate</code>\nExample: <code>Telegram - 2.5</code>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_cool":
        user_states[user_id] = {"state": "waiting_dxa_cool", "msg_id": message_id}
        edit_message(chat_id, message_id, "⏳ <b>Enter new Cooldown time in seconds (e.g. 10):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_num_req":
        user_states[user_id] = {"state": "waiting_dxa_num_req", "msg_id": message_id}
        edit_message(chat_id, message_id, "📱 <b>Enter how many numbers a user gets per request (e.g. 3):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "manage_w_methods":
        edit_message(chat_id, message_id, "💳 <b>WITHDRAW METHODS</b>\nManage methods below:", reply_markup=dxa_manage_w_methods_keyboard())
        answer_callback_query(query_id)
    elif data == "add_w_method":
        user_states[user_id] = {"state": "waiting_w_method", "msg_id": message_id}
        edit_message(chat_id, message_id, "💳 <b>Enter new Withdraw Method Name (e.g. bKash):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data.startswith("del_w_method_"):
        idx = int(data[13:])
        if idx < len(bot_settings["w_methods"]): bot_settings["w_methods"].pop(idx)
        save_local_data()
        edit_message(chat_id, message_id, "💳 <b>WITHDRAW METHODS</b>\nManage methods below:", reply_markup=dxa_manage_w_methods_keyboard())
        answer_callback_query(query_id, "Method Deleted!")
    elif data == "dxa_proof_group":
        user_states[user_id] = {"state": "waiting_dxa_proof_group", "msg_id": message_id}
        select_kb = {"keyboard": [[{"text": "Select Proof Group", "request_chat": {"request_id": 3, "chat_is_channel": False}},
                                   {"text": "Select Proof Channel", "request_chat": {"request_id": 4, "chat_is_channel": True}}],
                                  [{"text": "🔙 BACK"}]], "resize_keyboard": True, "one_time_keyboard": True}
        send_message(chat_id, "👇 <b>Select the PAYMENT PROOF group/channel</b> (bot must be admin there):", reply_markup=select_kb)
        answer_callback_query(query_id)
    elif data == "dxa_usdt_rate":
        user_states[user_id] = {"state": "waiting_dxa_usdt_rate", "msg_id": message_id}
        edit_message(chat_id, message_id, "💱 <b>Enter how many BDT = 1 USDT (e.g. 120):</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
    elif data == "dxa_w_group":
        user_states[user_id] = {"state": "waiting_dxa_w_group", "msg_id": message_id}
        select_kb = {"keyboard": [[{"text": "Select Withdraw Group", "request_chat": {"request_id": 2, "chat_is_channel": False}}], [{"text": "🔙 BACK"}]], "resize_keyboard": True, "one_time_keyboard": True}
        send_message(chat_id, "👇 <b>Select Withdraw Group from below:</b>", reply_markup=select_kb)
        answer_callback_query(query_id)

    # ===== Broadcast System =====
    elif data == "broadcast_menu":
        user_states[user_id] = {"state": "waiting_broadcast", "msg_id": message_id}
        edit_message(chat_id, message_id, get_broadcast_text(), reply_markup=get_broadcast_keyboard())
        answer_callback_query(query_id)
    elif data == "toggle_bc_pin":
        bot_settings["broadcast_pin"] = not bot_settings.get("broadcast_pin", False)
        save_local_data()
        edit_message(chat_id, message_id, get_broadcast_text(), reply_markup=get_broadcast_keyboard())
        answer_callback_query(query_id, f"Auto Pin: {'ON' if bot_settings['broadcast_pin'] else 'OFF'}")

    elif data == "upload_firebase":
        user_states[user_id] = {"state": "waiting_firebase", "msg_id": message_id}
        edit_message(chat_id, message_id, "🔥 <b>FIREBASE SETUP</b>\n\nPlease reply with the <b>entire JSON content</b> of your Firebase Service Account file.", reply_markup=get_upload_firebase_keyboard())
        answer_callback_query(query_id, "Send JSON Now")

    # ===== User Control =====
    elif data == "user_control":
        msg = f"👥 <b>USER CONTROL</b>\n━━━━━━━━━━━━━━━━━\n📊 <b>Total Users:</b> {get_total_users()}\n\n👇 Manage users below:"
        edit_message(chat_id, message_id, msg, reply_markup=get_user_control_keyboard())
        answer_callback_query(query_id)
        
    elif data == "uc_profile":
        user_states[user_id] = {"state": "waiting_uc_id", "msg_id": message_id}
        edit_message(chat_id, message_id, "🆔 <b>Send the Telegram User ID to view profile:</b>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
        
    elif data.startswith("uc_balance_"):
        target_uid = int(data[11:])
        user_states[user_id] = {"state": f"waiting_uc_balance_{target_uid}", "msg_id": message_id}
        edit_message(chat_id, message_id, f"💵 <b>Send the amount to Add or Subtract.</b>\n<i>(Examples: To add use 50, to deduct use -10)</i>", reply_markup=get_back_only_keyboard())
        answer_callback_query(query_id)
        
    elif data == "back_to_admin":
        if user_id in user_states: del user_states[user_id]
        edit_message(chat_id, message_id, get_owner_panel_text(), reply_markup=get_admin_inline_keyboard())
        answer_callback_query(query_id)
        
    elif data == "db_status": 
        answer_callback_query(query_id, f"Current DB: {current_db_mode.upper()}", show_alert=True)
        
    elif data == "close_panel":
        answer_callback_query(query_id, "Closed")
        delete_message(chat_id, message_id)
        
    else:
        answer_callback_query(query_id, f"{data} clicked!", show_alert=True)

# ==========================================
# Main
# ==========================================
# ==========================================
# WEB ADMIN PANEL (Telegram Mini App) - open it from Owner Panel > WEB PANEL or /panel
# Needs a public HTTPS link: set env WEBAPP_URL (and PORT if your host gives one).
# ==========================================
WEBAPP_URL = (os.environ.get("WEBAPP_URL") or "https://frabjous-bavarois-49ed0a.netlify.app").strip().rstrip("/")
try: WEBAPP_PORT = int(os.environ.get("PORT") or os.environ.get("WEBAPP_PORT") or 8080)
except Exception: WEBAPP_PORT = 8080

_web_bc = {"running": False, "sent": 0, "fail": 0, "total": 0}

def webapp_validate(init_data, max_age=86400):
    """Check Telegram's signature on Mini App initData. Returns the user dict or None."""
    try:
        parsed = dict(urllib.parse.parse_qsl(str(init_data), keep_blank_values=True))
        got = parsed.pop("hash", "")
        if not got: return None
        check = "\n".join(f"{k}={parsed[k]}" for k in sorted(parsed))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc, got): return None
        if time.time() - int(parsed.get("auth_date", "0")) > max_age: return None
        return json.loads(parsed.get("user", "{}"))
    except Exception:
        return None

def web_state(b, u):
    same = daily_stats.get("date") == time.strftime("%Y-%m-%d")
    try: users = get_total_users()
    except Exception: users = 0
    return {
        "admin": u.get("first_name", "Admin"),
        "stats": {"users": users, "numbers": daily_stats.get("numbers", 0) if same else 0,
                  "otps": daily_stats.get("otps", 0) if same else 0,
                  "pending": len(bot_settings.get("pending_withdrawals") or {})},
        "flags": {"premium_emoji": premium_emoji_on(), "withdraw_on": bool(bot_settings.get("withdraw_on", True)),
                  "tm_enabled": bool(bot_settings.get("tm_enabled", True)),
                  "voltx_enabled": bool(voltx_enabled), "zenex_enabled": bool(zenex_enabled)},
        "nums": {"min_withdraw": bot_settings.get("min_withdraw", 0), "otp_default_rate": bot_settings.get("otp_default_rate", 0)},
        "emoji": emoji_snapshot(), "bc": dict(_web_bc)}

def web_toggle(b, u):
    global voltx_enabled, zenex_enabled
    k = b.get("key")
    if k == "voltx_enabled": voltx_enabled = not voltx_enabled
    elif k == "zenex_enabled": zenex_enabled = not zenex_enabled
    elif k in ("premium_emoji", "withdraw_on", "tm_enabled"):
        bot_settings[k] = not bot_settings.get(k, k != "premium_emoji")
    else: raise ValueError("Unknown switch")
    save_local_data()
    return web_state(b, u)

def web_setnum(b, u):
    k = b.get("key")
    if k not in ("min_withdraw", "otp_default_rate"): raise ValueError("Unknown field")
    v = float(b.get("value"))
    if v < 0 or v > 1000000: raise ValueError("Value out of range")
    bot_settings[k] = v; save_local_data()
    return web_state(b, u)

def web_emoji_add(b, u):
    rep = emj_apply_input(b.get("text", ""))
    return {"report": [re.sub(r"<[^>]+>", "", r) for r in rep], "emoji": emoji_snapshot()}

def web_emoji_del(b, u):
    ok, msg = emoji_remove(b.get("char", ""))
    return {"report": [re.sub(r"<[^>]+>", "", msg)], "emoji": emoji_snapshot()}

def _web_user_info(uid):
    d = get_user(uid)
    if not d: raise ValueError("User not found")
    return {"id": uid, "name": d.get("first_name", ""), "balance": round(float(d.get("balance", 0)), 2),
            "invites": int(d.get("total_invites", 0))}

def web_user_get(b, u):
    return _web_user_info(int(str(b.get("id", "")).strip()))

def web_user_balance(b, u):
    uid = int(str(b.get("id", "")).strip()); amt = float(b.get("amount"))
    if abs(amt) > 1000000 or amt == 0: raise ValueError("Amount must be non-zero and under 1,000,000")
    _web_user_info(uid)
    update_user_stats(uid, amt, 0)
    print(f"[WebPanel] balance {amt:+} for {uid} by admin {u.get('id')}")
    return _web_user_info(uid)

def web_broadcast(b, u):
    text = str(b.get("text", "")).strip()
    if not text: raise ValueError("Message is empty")
    if len(text) > 3500: raise ValueError("Message too long")
    if _web_bc["running"]: raise ValueError("A broadcast is already running")
    ids = list(get_all_user_ids())
    body = text if b.get("html") else html.escape(text)
    _web_bc.update(running=True, sent=0, fail=0, total=len(ids))
    def worker():
        try:
            for uid in ids:
                r = send_message(uid, body)
                if isinstance(r, dict) and r.get("ok"): _web_bc["sent"] += 1
                else: _web_bc["fail"] += 1
                time.sleep(0.05)
        finally: _web_bc["running"] = False
    threading.Thread(target=worker, daemon=True).start()
    return {"bc": dict(_web_bc)}

WEB_API = {"state": web_state, "toggle": web_toggle, "setnum": web_setnum, "emoji_add": web_emoji_add,
           "emoji_del": web_emoji_del, "user_get": web_user_get, "user_balance": web_user_balance,
           "broadcast": web_broadcast}

WEBAPP_HTML = r'''<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Bot Admin</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{--bg:var(--tg-theme-bg-color,#fff);--tx:var(--tg-theme-text-color,#111);--hint:var(--tg-theme-hint-color,#7a7a7a);--btn:var(--tg-theme-button-color,#2481cc);--btx:var(--tg-theme-button-text-color,#fff);--card:var(--tg-theme-secondary-bg-color,#f0f0f3);--bad:#d64545;--good:#2e9e5b}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.4 -apple-system,system-ui,"Segoe UI",Roboto,sans-serif;padding:env(safe-area-inset-top) 0 calc(env(safe-area-inset-bottom) + 16px)}
header{padding:14px 16px 6px}header h1{margin:0;font-size:18px}header small{color:var(--hint)}
nav{display:flex;gap:6px;padding:8px 12px;position:sticky;top:0;background:var(--bg);z-index:5}
nav button{flex:1;padding:9px 4px;border:0;border-radius:10px;background:var(--card);color:var(--tx);font-size:13px}
nav button.on{background:var(--btn);color:var(--btx)}
main{padding:4px 12px}
.card{background:var(--card);border-radius:14px;padding:12px;margin:10px 0}
.card h2{margin:0 0 8px;font-size:14px;color:var(--hint);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.stat{background:var(--bg);border-radius:10px;padding:10px}.stat b{display:block;font-size:20px}.stat span{color:var(--hint);font-size:12px}
.row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 0;border-top:1px solid rgba(128,128,128,.18)}
.row:first-of-type{border-top:0}
input,textarea{width:100%;padding:10px;border-radius:10px;border:1px solid rgba(128,128,128,.35);background:var(--bg);color:var(--tx);font:inherit}
textarea{min-height:90px;resize:vertical}
.btn{padding:10px 14px;border:0;border-radius:10px;background:var(--btn);color:var(--btx);font-size:14px;font-weight:600}
.btn.sm{padding:6px 10px;font-size:12px}.btn.bad{background:var(--bad);color:#fff}.btn.good{background:var(--good);color:#fff}
.sw{width:46px;height:26px;border-radius:13px;border:0;background:#999;position:relative;flex:none}
.sw::after{content:"";position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.15s}
.sw.on{background:var(--good)}.sw.on::after{left:23px}
.mt{margin-top:8px}.hint{color:var(--hint);font-size:12px}.big{font-size:22px}
#toast{position:fixed;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom) + 12px);padding:12px;border-radius:12px;background:#222;color:#fff;opacity:0;pointer-events:none;transition:.2s;z-index:9;white-space:pre-line}
#toast.show{opacity:1}#toast.bad{background:var(--bad)}
</style></head><body>
<header><h1>🛠 Bot Admin Panel</h1><small id="who"></small></header>
<nav id="nav"></nav><main id="main"><div class="card">Loading…</div></main><div id="toast"></div>
<script>
const tg=window.Telegram&&Telegram.WebApp;if(tg){tg.ready();tg.expand()}
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let S=null,tab='home',U=null,poll=null;
const TABS=[['home','Home'],['emoji','Emoji'],['users','Users'],['bc','Broadcast']];
const FLAGS=[['premium_emoji','Premium emoji'],['withdraw_on','Withdraw'],['tm_enabled','Temp Mail'],['voltx_enabled','Voltx panel'],['zenex_enabled','Zenex panel']];
async function api(n,b){const r=await fetch('/api/'+n,{method:'POST',headers:{'Content-Type':'application/json','X-Init-Data':(tg&&tg.initData)||''},body:JSON.stringify(b||{})});let j;try{j=await r.json()}catch(e){j={error:'Bad response'}}if(!r.ok||j.error)throw new Error(j.error||('HTTP '+r.status));return j}
function toast(m,bad){const t=$('#toast');t.textContent=m;t.className='show'+(bad?' bad':'');clearTimeout(toast.t);toast.t=setTimeout(()=>t.className='',3500)}
async function act(fn){try{await fn()}catch(e){toast(e.message,1)}}
async function load(){S=await api('state');$('#who').textContent='Signed in as '+S.admin;render()}
function setTab(t){tab=t;render()}
function render(){
 $('#nav').innerHTML=TABS.map(t=>`<button class="${t[0]===tab?'on':''}" onclick="setTab('${t[0]}')">${t[1]}</button>`).join('');
 clearTimeout(poll);const m=$('#main');
 if(tab==='home'){const s=S.stats;
  m.innerHTML=`<div class="card"><h2>Overview</h2><div class="grid">
  <div class="stat"><b>${s.users}</b><span>Users</span></div><div class="stat"><b>${s.pending}</b><span>Pending withdraws</span></div>
  <div class="stat"><b>${s.numbers}</b><span>Numbers today</span></div><div class="stat"><b>${s.otps}</b><span>OTPs today</span></div></div></div>
  <div class="card"><h2>Switches</h2>${FLAGS.map(f=>`<div class="row"><span>${f[1]}</span><button class="sw ${S.flags[f[0]]?'on':''}" data-k="${f[0]}" onclick="tog(this.dataset.k)"></button></div>`).join('')}</div>
  <div class="card"><h2>Rates</h2>
  <div class="row"><span>Min withdraw</span><input style="width:110px" id="n1" type="number" step="any" value="${esc(S.nums.min_withdraw)}"><button class="btn sm" onclick="setNum('min_withdraw','n1')">Save</button></div>
  <div class="row"><span>OTP default rate</span><input style="width:110px" id="n2" type="number" step="any" value="${esc(S.nums.otp_default_rate)}"><button class="btn sm" onclick="setNum('otp_default_rate','n2')">Save</button></div></div>`}
 else if(tab==='emoji'){const e=S.emoji;
  const pl=Object.entries(e.premium).map(([k,v])=>`<div class="row"><span><span class="big">${esc(k)}</span> <span class="hint">premium ${esc(v)}</span></span><button class="btn sm bad" data-k="${esc(k)}" onclick="delEm(this.dataset.k)">Delete</button></div>`).join('');
  const sl=Object.entries(e.swap).map(([k,v])=>`<div class="row"><span><span class="big">${esc(k)}</span> ➜ <span class="big">${esc(v)}</span></span><button class="btn sm bad" data-k="${esc(k)}" onclick="delEm(this.dataset.k)">Delete</button></div>`).join('');
  m.innerHTML=`<div class="card"><h2>Add / change</h2><textarea id="et" placeholder="💌{97279228637383828}&#10;💌=❤️&#10;-💌"></textarea>
  <div class="hint mt">One per line. <b>💌{ID}</b> = premium emoji · <b>💌=❤️</b> = swap normal emoji · <b>-💌</b> = remove. Premium mode must be ON (Home tab).</div>
  <button class="btn mt" onclick="addEm()">Apply</button></div>
  <div class="card"><h2>Premium (${Object.keys(e.premium).length})</h2>${pl||'<span class="hint">None yet</span>'}<div class="hint mt">${e.builtin} built-in emoji are already mapped.</div></div>
  <div class="card"><h2>Swaps (${Object.keys(e.swap).length})</h2>${sl||'<span class="hint">None yet</span>'}</div>`}
 else if(tab==='users'){
  m.innerHTML=`<div class="card"><h2>Find user</h2><input id="uid" inputmode="numeric" placeholder="Telegram user ID"><button class="btn mt" onclick="findU()">Find</button></div><div id="ures"></div>`;if(U)showU()}
 else{m.innerHTML=`<div class="card"><h2>Broadcast to all users</h2><textarea id="bt" placeholder="Message (plain text)"></textarea>
  <button class="btn mt" onclick="sendBc()">Send</button><div class="hint mt" id="bcs"></div></div>`;bcStat()}
}
function bcStat(){const b=S.bc,el=$('#bcs');if(!el)return;
 el.textContent=b.total?(b.running?'Sending… ':'Finished. ')+b.sent+' sent, '+b.fail+' failed of '+b.total:'';
 if(b.running){poll=setTimeout(()=>act(async()=>{S.bc=(await api('state')).bc;bcStat()}),2000)}}
const tog=k=>act(async()=>{S=await api('toggle',{key:k});render()});
const setNum=(k,id)=>act(async()=>{S=await api('setnum',{key:k,value:$('#'+id).value});render();toast('Saved')});
const addEm=()=>act(async()=>{const r=await api('emoji_add',{text:$('#et').value});S.emoji=r.emoji;render();toast(r.report.join('\n'))});
const delEm=k=>act(async()=>{const r=await api('emoji_del',{char:k});S.emoji=r.emoji;render();toast(r.report.join('\n'))});
const findU=()=>act(async()=>{U=await api('user_get',{id:$('#uid').value});showU()});
function showU(){$('#ures').innerHTML=`<div class="card"><h2>${esc(U.name)||'User'} · ${U.id}</h2><div class="grid"><div class="stat"><b>${U.balance}</b><span>Balance</span></div><div class="stat"><b>${U.invites}</b><span>Invites</span></div></div>
 <input class="mt" id="amt" type="number" step="any" placeholder="Amount"><div class="grid mt"><button class="btn good" onclick="bal(1)">Add</button><button class="btn bad" onclick="bal(-1)">Subtract</button></div></div>`}
const bal=sg=>act(async()=>{const a=Math.abs(parseFloat($('#amt').value));if(!a)throw new Error('Enter an amount');
 if(tg&&tg.showConfirm){const ok=await new Promise(r=>tg.showConfirm((sg>0?'Add ':'Subtract ')+a+' for '+U.id+'?',r));if(!ok)return}
 U=await api('user_balance',{id:U.id,amount:sg*a});showU();toast('Balance updated')});
const sendBc=()=>act(async()=>{const t=$('#bt').value.trim();if(!t)throw new Error('Write a message first');
 if(tg&&tg.showConfirm){const ok=await new Promise(r=>tg.showConfirm('Send this to ALL users?',r));if(!ok)return}
 const r=await api('broadcast',{text:t});S.bc=r.bc;$('#bt').value='';bcStat();toast('Broadcast started')});
act(load);
</script></body></html>
'''

class _WebHandler(BaseHTTPRequestHandler):
    server_version = "BotPanel/1.0"
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)): body = json.dumps(body, ensure_ascii=False)
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store"); self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        p = self.path.split("?")[0]
        if p in ("/", "/index.html"): self._send(200, WEBAPP_HTML, "text/html; charset=utf-8")
        elif p == "/health": self._send(200, "ok", "text/plain")
        else: self._send(404, {"error": "not found"})
    def do_POST(self):
        p = self.path.split("?")[0]
        if not p.startswith("/api/") or p[5:] not in WEB_API: return self._send(404, {"error": "not found"})
        user = webapp_validate(self.headers.get("X-Init-Data", ""))
        if not user or int(user.get("id", 0)) != ADMIN_ID:
            return self._send(403, {"error": "Admin only. Open this panel from the bot inside Telegram."})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n > 100000: return self._send(413, {"error": "too large"})
            body = json.loads(self.rfile.read(n) or b"{}")
            self._send(200, WEB_API[p[5:]](body, user))
        except Exception as e:
            self._send(400, {"error": str(e)[:200] or "error"})

def start_webapp():
    if os.environ.get("WEBAPP_ENABLED", "1") == "0": return
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", WEBAPP_PORT), _WebHandler)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        print(f"[WebPanel] listening on :{WEBAPP_PORT}  url={WEBAPP_URL or '(set WEBAPP_URL to enable the button)'}")
    except Exception as e:
        print(f"[WebPanel] could not start: {e}")

def main():
    global BOT_USERNAME
    
    load_local_data()
    emoji_changed()
    load_manual_data()
    tm_load()
    if not bot_settings.get("usdt_added"):
        if "USDT (BEP20)" not in bot_settings["w_methods"]: bot_settings["w_methods"].append("USDT (BEP20)")
        bot_settings["usdt_added"] = True
        save_local_data()
    init_sqlite()
    init_firebase_from_file()
    web_sync.init(globals()); web_sync.start()   # Web Admin Panel sync
    
    BOT_USERNAME = get_bot_info()
    set_bot_commands()
    
    threading.Thread(target=voltx_console_listener, daemon=True).start()
    threading.Thread(target=voltx_sms_listener, daemon=True).start()
    threading.Thread(target=zenex_ranges_listener, daemon=True).start()
    threading.Thread(target=zenex_console_listener, daemon=True).start()
    threading.Thread(target=zenex_sms_listener, daemon=True).start()
    threading.Thread(target=augestel_sms_listener, daemon=True).start()
    threading.Thread(target=augestel_range_sync_loop, daemon=True).start()
    threading.Thread(target=lamix_sms_listener, daemon=True).start()
    threading.Thread(target=tm_poll_loop, daemon=True).start()
    threading.Thread(target=lamix_range_sync_loop, daemon=True).start()
    threading.Thread(target=auto_cache_menu_thread, daemon=True).start()
    start_webapp()
    
    print(f"Bot @{BOT_USERNAME} is running with Voltx + Zenex + Manual (AugesTel + LAMIX), DXA Control & OTP Forwarding...")
    
    offset = None
    while True:
        try:
            url = BASE_URL + "getUpdates"
            res = requests.get(url, params={"timeout": 30, "offset": offset}).json()
            if res.get("ok"):
                for update in res["result"]:
                    offset = update["update_id"] + 1
                    if "message" in update: 
                        threading.Thread(target=handle_message, args=(update["message"],)).start()
                    elif "callback_query" in update: 
                        threading.Thread(target=handle_callback, args=(update["callback_query"],)).start()
        except Exception as e:
            time.sleep(3)

if __name__ == "__main__":
    main()